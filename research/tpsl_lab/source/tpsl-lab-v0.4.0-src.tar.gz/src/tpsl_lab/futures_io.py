"""Offline funding/tier loaders. Never contacts an API or sends orders."""
import json
from pathlib import Path
from .futures import FundingEvent, FundingTape, MarginTier


def read_binance_funding(path: str | Path, coverage_start: int, coverage_end: int,
                         expected_symbol: str | None = None) -> FundingTape:
    """Load Binance funding history using exact integer millisecond timestamps.

    The API's endTime is inclusive. Exactly-at-end records are excluded from
    our half-open backtest interval, but no other out-of-range record is
    silently discarded. Coverage is caller-declared, NOT independently proven.
    """
    records = json.loads(Path(path).read_text(encoding='utf-8'))
    if not isinstance(records, list):
        raise ValueError('funding JSON must be a list of fapi history records')
    events = []
    end_excluded = 0
    for row in records:
        raw = row['fundingTime']
        if type(raw) is int:
            ms = raw
        elif isinstance(raw, str) and raw.isdecimal():
            ms = int(raw)
        else:
            raise ValueError('fundingTime must be an integer millisecond timestamp')
        if expected_symbol and row.get('symbol') != expected_symbol:
            raise ValueError('unexpected funding symbol')
        if ms == coverage_end*1000:
            end_excluded += 1
            continue
        if not coverage_start*1000 <= ms < coverage_end*1000:
            raise ValueError('funding record outside requested range')
        events.append(FundingEvent(ms//1000, float(row['fundingRate']),
                                   float(row['markPrice']), ts_ms=ms))
    return FundingTape(tuple(events), coverage_start, coverage_end,
                       f'binance-fapi-funding-history:file={Path(path).name};'
                       f'end_boundary_excluded={end_excluded};unverified_completeness')


def read_tiers(path: str | Path) -> tuple[MarginTier, ...]:
    payload = json.loads(Path(path).read_text(encoding='utf-8'))
    if payload.get('mode') != 'scenario' or not isinstance(payload.get('tiers'), list):
        raise ValueError('tier file must explicitly declare mode=scenario')
    rows = payload['tiers']
    return tuple(MarginTier(float(r['floor']), float(r['cap']),
                            float(r['maintenance_rate']), float(r['maintenance_amount']),
                            float(r['max_leverage'])) for r in rows)
