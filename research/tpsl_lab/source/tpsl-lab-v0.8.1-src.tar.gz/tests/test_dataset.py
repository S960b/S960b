"""Local synthetic fixtures: no network, no exchange account and no API keys."""
import csv
import io
import json
import hashlib
import zipfile
from datetime import date, datetime, timezone
from pathlib import Path
import pytest
from tpsl_lab.dataset import read_daily, audit_days
from tpsl_lab.io import read_csv
from tpsl_lab import __version__

DAY=date(2024,6,1)
START=int(datetime(2024,6,1,tzinfo=timezone.utc).timestamp())


def make_csv(ts_unit='ms',missing=None,duplicate=False,one_ms=False):
    s=io.StringIO(newline='');w=csv.writer(s,lineterminator='\n')
    for i in range(1440):
        if i==missing:continue
        t=(START+i*60)*(1000000 if ts_unit=='us' else 1000)
        if one_ms and i==50:t+=1
        row=[t,100,101,99,100,2,0,0,0,0,0,0]
        w.writerow(row)
        if duplicate and i==50:w.writerow(row)
    return s.getvalue().encode()


def store(path,data,member=None):
    path.parent.mkdir(exist_ok=True,parents=True)
    if path.suffix=='.zip':
        with zipfile.ZipFile(path,'w',compression=zipfile.ZIP_DEFLATED) as z:
            z.writestr(member or path.stem+'.csv',data)
    else:path.write_bytes(data)
    return path


def test_version():
    assert __version__=='0.8.1'


@pytest.mark.parametrize('unit',['ms','us'])
def test_complete_day_with_ms_and_us(tmp_path,unit):
    p=store(tmp_path/'test.zip',make_csv(ts_unit=unit))
    got=read_daily(p,DAY)
    assert len(got.bars)==1440
    assert got.bars[0].ts==START and got.bars[-1].ts==START+1439*60
    assert got.raw_sha256==hashlib.sha256(p.read_bytes()).hexdigest()
    assert got.csv_sha256==hashlib.sha256(make_csv(ts_unit=unit)).hexdigest()


@pytest.mark.parametrize('kw', [{'missing':100},{'duplicate':True},{'one_ms':True}])
def test_reject_gaps_duplicates_and_subsecond_timestamp(tmp_path,kw):
    p=store(tmp_path/'t.csv',make_csv(**kw))
    with pytest.raises(ValueError):read_daily(p,DAY)


def test_wrong_day(tmp_path):
    p=store(tmp_path/'t.csv',make_csv())
    with pytest.raises(ValueError):read_daily(p,date(2024,6,2))


def test_zip_slip_and_extra_members(tmp_path):
    p=store(tmp_path/'t.zip',make_csv(),member='../evil.csv')
    with pytest.raises(ValueError,match='unsafe'):read_daily(p,DAY)
    with zipfile.ZipFile(p,'a') as z:z.writestr('extra.csv',b'')
    with pytest.raises(ValueError,match='exactly one'):read_daily(p,DAY)


def test_reject_wrong_column_count(tmp_path):
    p=store(tmp_path/'t.csv',b'1717200000000,1,2,0,1,3\n')
    with pytest.raises(ValueError,match='12'):read_daily(p,DAY)


def test_audit_one_day_funding_boundary_and_export(tmp_path):
    td=tmp_path/'trade';md=tmp_path/'mark'
    name='BTCUSDT-1m-2024-06-01.zip'
    store(td/name,make_csv());store(md/name,make_csv())
    funding=tmp_path/'fund.json'
    funding.write_text(json.dumps([
        {'symbol':'BTCUSDT','fundingTime':START*1000,'fundingRate':'0.0001','markPrice':'100'},
        {'symbol':'BTCUSDT','fundingTime':(START+16*3600)*1000+1,'fundingRate':'0.0001','markPrice':'100'},
        {'symbol':'BTCUSDT','fundingTime':(START+86400)*1000,'fundingRate':'0.0001','markPrice':'100'},
    ]))
    out=tmp_path/'replay'
    r=audit_days(td,md,'2024-06-01',1,'BTCUSDT',funding,out)
    assert r['total_bars']==1440
    assert r['funding']['event_count']==2
    assert r['funding']['timestamps_ms'][1]==(START+16*3600)*1000+1
    assert 'end_boundary_excluded=1' in r['funding']['source']
    assert len(read_csv(out/'trade_1m.csv'))==1440
    assert len(read_csv(out/'mark_1m.csv'))==1440
    with pytest.raises(ValueError,match='already exists'):
        audit_days(td,md,'2024-06-01',1,'BTCUSDT',funding,out)


def test_missing_mark_file_refuses(tmp_path):
    td=tmp_path/'trade';md=tmp_path/'mark';md.mkdir()
    store(td/'BTCUSDT-1m-2024-06-01.zip',make_csv())
    funding=tmp_path/'fund.json';funding.write_text('[]')
    with pytest.raises(ValueError,match='exactly one'):
        audit_days(td,md,'2024-06-01',1,'BTCUSDT',funding)


def test_wrong_symbol_in_funding(tmp_path):
    td=tmp_path/'trade';md=tmp_path/'mark'
    name='BTCUSDT-1m-2024-06-01.zip'
    store(td/name,make_csv());store(md/name,make_csv())
    funding=tmp_path/'fund.json'
    funding.write_text(json.dumps([{'symbol':'ETHUSDT','fundingTime':START*1000,
                                    'fundingRate':'0.0001','markPrice':'100'}]))
    with pytest.raises(ValueError,match='symbol'):
        audit_days(td,md,'2024-06-01',1,'BTCUSDT',funding)


def test_double_file_rejected(tmp_path):
    td=tmp_path/'trade';md=tmp_path/'mark';name='BTCUSDT-1m-2024-06-01'
    store(td/(name+'.zip'),make_csv());store(td/(name+'.csv'),make_csv())
    store(md/(name+'.zip'),make_csv())
    funding=tmp_path/'fund.json';funding.write_text('[]')
    with pytest.raises(ValueError,match='exactly one'):
        audit_days(td,md,'2024-06-01',1,'BTCUSDT',funding)
