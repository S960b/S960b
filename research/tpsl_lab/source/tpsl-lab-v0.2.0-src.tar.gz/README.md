# TP/SL Lab v0.2 — OFFLINE conservative futures risk proxy

**Research only. No order API, no Binance credentials, no live/testnet trading.**
The original independent unlevered v0.1 engine remains available as
`tpsl_lab.cli` and `tpsl_lab.engine` and its 18 tests are unchanged.

v0.2 adds a SEPARATE model (`tpsl_lab.futures`) for linear USD-M perpetual
futures *risk scenarios*, not an exchange-exact liquidation engine.

## Implemented

- Trade OHLCV and separate mark-price OHLCV, exact time alignment, no gaps.
- A signal formed on a completed bar may enter only at the next bar OPEN.
- Fixed TP/SL, conservative stop-first when both touch the same candle.
- Adverse entry/exit slippage and taker fees on both sides, as explicit scenarios.
- Isolated initial margin = entered position notional / selected leverage.
- Bracket maintenance margin = max(0, current mark notional * maintenance rate
  - maintenance amount). Enforce configured max leverage at entry, missing tiers
  fail closed. Brackets supplied by the operator are **scenarios**, not verified
  historical Binance rules.
- Funding events from explicit historical timestamps and their associated mark
  prices: signed cashflow = -direction * quantity * mark_price * funding_rate.
  Longs pay positive funding, shorts receive it. No inferred 8-hour schedule.
- Funding timing around a candle boundary is not exact. Conservative treatment:
  book possible debits on entry at funding boundary, suppress uncertain credits
  for positions that exit at that candle OPEN; record boundary events.
- Liquidation risk evaluated from MARK-price open and adverse extremum,
  independent of the execution-price candle. If mark intrabar breaches
  maintenance + configurable risk reserve, flag `liquidation_PROXY`.
- On liquidation, book a **full loss of isolated margin**, leave `exit_price`
  and precise trade `net_pnl` null. This is an adverse stress-bookkeeping proxy,
  **not** Binance execution price/settlement or a guarantee that losses are
  bounded by margin, especially during gaps.
- Immutable returned event records (numbered sequentially) plus closed trades,
  per-trade funding and clear limitations. Only single position at a time.

## Explicit remaining limitations

1. Intrabar ordering of liquidation vs stop/target is unknown. If both are
   possible within one candle, the proxy chooses liquidation and reports the
   ambiguous count. 1m data is NOT tick-level or order-book evidence.
2. Exact Binance liquidation auction, fees, insurance fund, ADL, cross mode,
   portfolio margin, partial liquidation, bankruptcy price not implemented.
3. Funding JSON must be **complete for the requested period**. Passing a file
   (including `[]`) and declaring coverage does NOT prove actual completeness.
   Check history/cadence externally before interpreting output.
4. Live and historical margin brackets can differ; scenario tier fixture is
   illustrative only. Never infer historic tiers from today's API snapshot.
5. Execution has constant scenario slippage, no queue/depth/latency, and no
   fill-size/step constraints. Mark and trade bars can be misordered intrabar.
6. The conservative liquidation proxy is NOT an accurate Binance futures PnL
   model and must not rank leveraged strategies for capital deployment.

## Installation (Kali VM; separate venv)

```bash
/usr/bin/python3.13 -m venv .venv
.venv/bin/python -m pip install -e '.[test]'
.venv/bin/python -m pytest -q
.venv/bin/python -m compileall -q src
```

## Offline synthetic demo (NOT Binance historical mark/funding)

`demo.csv` is synthetic. `mark_same_as_trade_SYNTHETIC.csv` is intentionally a
copy to validate the interface, NOT a substitute for historical mark prices.
`funding_none.json` intentionally has no events, ONLY valid as a synthetic
scenario. `scenario_tiers.json` contains illustrative margin brackets.

```bash
.venv/bin/python -m tpsl_lab.futures_cli \
  --price-csv examples/demo.csv \
  --mark-csv examples/mark_same_as_trade_SYNTHETIC.csv \
  --funding-json examples/funding_none.json \
  --tiers-json examples/scenario_tiers.json \
  --strategy random --seed 7 --probability 1 --leverage 2 \
  --out reports/synthetic-v02.json
```

For Binance data, use separate historical USD-M `klines/` and
`markPriceKlines/` 1m data, both `--binance`, plus historical funding history
`GET /fapi/v1/fundingRate` in its returned JSON structure. Funding timestamps
in the API use milliseconds and contain `fundingRate` and `markPrice`.
Without a verified complete funding tape and appropriate historical bracket
snapshots, report remains **diagnostic only**. Never use synthetic empty funding
for a claim about real BTC/ETH futures profitability.

## Data references

- Binance official funding FAQ: https://www.binance.com/en/support/faq/detail/360033525031
- Binance official funding history: https://developers.binance.com/docs/derivatives/usds-margined-futures/market-data/rest-api/Get-Funding-Rate-History
- Binance official maintenance margin FAQ: https://www.binance.com/en/support/faq/detail/360033162192
- Binance public data: https://github.com/binance/binance-public-data

## MT acceptance scope

Read only this release and install in a clean isolated directory. Test all
43 existing/new pytest cases, both CLIs, and independent hand-calculated
funding, liquidation and ambiguous-intrabar fixtures. Try to obtain one day of
*separate* historical BTCUSDT mark-price klines plus actual funding, but do not
invent or silently backfill missing data. Report all missing information.
Do NOT modify NEWS, Hermes services, taskboard, cron, branch `main`, existing
research v0.1 directory, API keys, or any real/testnet/paper trading account.
