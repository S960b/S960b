"""v0.11: NEW, explicitly post-v0.10 hypothesis; offline SPOT event-only entries.

This does NOT rehabilitate the failed v0.10 strategies. We reuse the TRAIN
period for exploratory discovery, and reserve 2025 validation and 2026 holdout.
Only a completed 1m/15m candle can generate a signal, entry NEXT 1m open.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
from dataclasses import dataclass
from pathlib import Path
from itertools import product

from .engine import replay
from .model import Candle, Settings
from .spot_study import (SYMBOLS, SPLITS, BASELINE_COST, STRESS_COST,
                         EQUITY, NOMINAL, load_split, _sha256_bytes)

SCHEMA='tpsl-lab/event-only-preregistered-v1'
RULES=('ema_cross','donchian_first')
TIMEFRAMES=(1,15)  # in minutes; 1m is also execution clock
TP_SL_PAIRS=((0.02,0.01),(0.03,0.01))
MIN_TRADES=30
MAX_SELECTED=2
MAX_REPORT_BYTES=5_000_000
COOLDOWN_SECONDS=3600


class EmaCrossEvent:
    """Fire once only when fast EMA crosses ABOVE slow EMA on a completed bar."""
    def __init__(self,fast=50,slow=200):
        if type(fast) is not int or type(slow) is not int or not 1<=fast<slow:
            raise ValueError('invalid EMA periods')
        self.fast_a=2/(fast+1); self.slow_a=2/(slow+1)
        self.fast=None; self.slow=None; self.count=0; self.prev_bull=False
        self.slow_period=slow

    def on_close(self,candle:Candle)->int:
        self.count+=1
        self.fast=candle.close if self.fast is None else self.fast_a*candle.close+(1-self.fast_a)*self.fast
        self.slow=candle.close if self.slow is None else self.slow_a*candle.close+(1-self.slow_a)*self.slow
        bull=self.fast>self.slow
        signal=int(self.count>=self.slow_period and bull and not self.prev_bull and candle.close>self.fast)
        self.prev_bull=bull
        return signal


class DonchianFirstEvent:
    """First bar closing above previous 20 highs; min 60m between triggers."""
    def __init__(self,window=20,cooldown_seconds=COOLDOWN_SECONDS):
        if type(window) is not int or window<2 or type(cooldown_seconds) is not int or cooldown_seconds<0:
            raise ValueError('bad donchian parameters')
        self.window=window; self.cooldown_seconds=cooldown_seconds
        self.highs=[]; self.above_prev=False; self.last_signal_ts=None

    def on_close(self,candle:Candle)->int:
        above=(len(self.highs)==self.window and candle.close>max(self.highs))
        ready=(self.last_signal_ts is None or candle.ts-self.last_signal_ts>=self.cooldown_seconds)
        signal=int(above and not self.above_prev and ready)
        if signal: self.last_signal_ts=candle.ts
        self.above_prev=above
        self.highs.append(candle.high)
        if len(self.highs)>self.window:self.highs.pop(0)
        return signal


class TimeframeSignal:
    """Aggregate completed 1m candles into UTC-aligned TF; never future data.

    On the 15th one-minute close only, compute the signal and let the reference
    engine enter at the 16th candle's open. Short positions cannot be signaled.
    """
    def __init__(self,kind:str,timeframe_min:int):
        if kind not in RULES or timeframe_min not in TIMEFRAMES:
            raise ValueError('outside preregistered event grid')
        self.kind=kind; self.tf=timeframe_min
        self.rule=EmaCrossEvent() if kind=='ema_cross' else DonchianFirstEvent()
        self.pending_bars:list[Candle]=[]
        self.next_ts=None
        self.events=0
        self.completions=0

    def on_close(self,candle:Candle)->int:
        if self.next_ts is not None and candle.ts!=self.next_ts:
            raise ValueError('1m timestamp gap or duplicate')
        self.next_ts=candle.ts+60
        if not self.pending_bars and candle.ts%(self.tf*60):
            raise ValueError('timeframe block must start on UTC boundary')
        self.pending_bars.append(candle)
        if len(self.pending_bars)<self.tf:
            return 0
        if len(self.pending_bars)!=self.tf:
            raise ValueError('timeframe overflow')
        x=self.pending_bars
        bar=Candle(x[0].ts,x[0].open,max(c.high for c in x),min(c.low for c in x),x[-1].close,sum(c.volume for c in x))
        self.pending_bars=[]
        self.completions+=1
        signal=self.rule.on_close(bar)
        if signal not in (0,1): raise ValueError('long-only research')
        self.events+=signal
        return signal


def configs()->list[dict]:
    return [{'id':f'{rule}_tf{tf:02d}_tp{round(tp*10000):03d}_sl{round(sl*10000):03d}',
             'entry_rule':rule,'timeframe_min':tf,'tp_pct':tp,'sl_pct':sl}
            for rule,tf,(tp,sl) in product(RULES,TIMEFRAMES,TP_SL_PAIRS)]


def plan()->dict:
    return {'hypothesis':'New first-event-only entry gate after FAILED v0.10 continuous entry train',
            'scope':'spot long only, 1m fills, completed 1m or UTC-aligned 15m signals',
            'rules':list(RULES),'timeframe_minutes':list(TIMEFRAMES),
            'tp_sl_pairs':[list(x) for x in TP_SL_PAIRS],
            'donchian_cooldown_seconds':COOLDOWN_SECONDS,
            'fee_per_side':BASELINE_COST.taker_fee,
            'slippage_per_side':BASELINE_COST.slippage,
            'stress_fee_per_side':STRESS_COST.taker_fee,
            'stress_slippage_per_side':STRESS_COST.slippage,
            'notional_usdt':NOMINAL,'equity_usdt':EQUITY,
            'train_months':list(SPLITS['train']),'validation_months':list(SPLITS['validation']),
            'unread_holdout_months':['2026-07','2026-08','2026-09'],
            'min_trades_per_symbol':MIN_TRADES,'max_selected':MAX_SELECTED,
            'selection':'>=30 closed and positive BASELINE+STRESS marked net PnL on BOTH BTC ETH; sort by worst symbol STRESS net descending then worst DD ascending then id',
            'multiple_testing_warning':'TRAIN reused after observing v0.10 losses; TRAIN results exploratory, not independent',
            'holdout_sealed':True,'no_orders':True}


def simulate(bars:list[Candle],c:dict,costs)->dict:
    strat=TimeframeSignal(c['entry_rule'],c['timeframe_min'])
    r=replay(bars,strat,Settings(starting_equity=EQUITY,notional=NOMINAL,tp_pct=c['tp_pct'],sl_pct=c['sl_pct']),costs)
    if r['open_position'] is not None and r['open_position']['direction']!=1:
        raise ValueError('spot short prohibited')
    return {'closed_trades':r['closed_trades'],'winning_trades':r['winning_trades'],
            'win_rate':r['win_rate'],'net_marked_usdt':round(r['marked_equity']-EQUITY,8),
            'fee_usdt':round(r['total_fees'],8),
            'max_drawdown':round(r['max_mark_to_market_drawdown'],8),
            'signal_events':strat.events,'complete_signal_bars':strat.completions,
            'open_position_at_end':r['open_position'] is not None,
            'ambiguous_stop_first':r['ambiguous_bars_closed_at_stop']}


def select(results:list[dict])->list[str]:
    expected={c['id'] for c in configs()}
    if len(results)!=len(expected) or {r['id'] for r in results}!=expected:
        raise ValueError('missing or altered preregistered configurations')
    ranking=[]
    for item in results:
        by=item['by_symbol']
        if set(by)!=set(SYMBOLS):raise ValueError('missing symbol')
        if any(by[s]['baseline']['closed_trades']<MIN_TRADES or
               by[s]['baseline']['net_marked_usdt']<=0 or
               by[s]['stress']['net_marked_usdt']<=0 for s in SYMBOLS):
            continue
        worst=min(by[s]['stress']['net_marked_usdt'] for s in SYMBOLS)
        dd=max(by[s]['stress']['max_drawdown'] for s in SYMBOLS)
        ranking.append((-worst,dd,item['id']))
    ranking.sort()
    return [x[2] for x in ranking[:MAX_SELECTED]]


def train(root:Path)->dict:
    series,prov=load_split(root,'train')  # read-only official CHECKSUM validated
    rows=[]
    for c in configs():
        by={symbol:{'baseline':simulate(series[symbol],c,BASELINE_COST),
                    'stress':simulate(series[symbol],c,STRESS_COST)} for symbol in SYMBOLS}
        rows.append({**c,'by_symbol':by})
    selected=select(rows)
    return {'schema':SCHEMA,'stage':'train','plan':plan(),
            'data_provenance':prov,'config_results':rows,
            'selected_config_ids':selected,'selected_count':len(selected),
            'validation_unseen':True,'holdout_unseen':True,
            'notes':['New hypothesis intentionally formed after negative 2024 TRAIN v0.10: do not claim independent 2024 evidence',
                     'If selected empty, validation is NOT authorized; 2026 holdout remains sealed.']}


def _verify_frozen_train(t:dict)->list[dict]:
    if not isinstance(t,dict) or t.get('schema')!=SCHEMA or t.get('stage')!='train' or t.get('plan')!=plan() or t.get('holdout_unseen') is not True or t.get('validation_unseen') is not True:
        raise ValueError('train preregistration or seal mismatch')
    raw=t.get('config_results')
    expected=configs()
    if not isinstance(raw,list) or len(raw)!=len(expected):
        raise ValueError('train results count mismatch')
    for x,c in zip(raw,expected):
        if not isinstance(x,dict) or any(x.get(k)!=v for k,v in c.items()):
            raise ValueError('train config identity mismatch')
    selected=select(raw)
    if selected!=t.get('selected_config_ids') or len(selected)!=t.get('selected_count'):
        raise ValueError('train selection mutated')
    return [c for c in expected if c['id'] in selected]


def validate(root:Path,train_report:dict,train_digest:str)->dict:
    chosen=_verify_frozen_train(train_report)
    if not chosen:
        raise ValueError('NO_ELIGIBLE_TRAIN_CANDIDATES: no validation')
    series,prov=load_split(root,'validation')
    rows=[]
    for c in chosen:
        by={sym:{'baseline':simulate(series[sym],c,BASELINE_COST),
                 'stress':simulate(series[sym],c,STRESS_COST)} for sym in SYMBOLS}
        rows.append({**c,'by_symbol':by})
    return {'schema':SCHEMA,'stage':'validation','plan':plan(),
            'train_report_sha256':train_digest,'selected_config_ids':train_report['selected_config_ids'],
            'candidate_results':rows,'data_provenance':prov,
            'holdout_unseen':True,
            'notes':['One frozen out-of-sample validation; no re-selection after reading results']}


def main(argv=None):
    p=argparse.ArgumentParser(description='Offline event-only strategy study: TRAIN first, HOLDOUT SEALED')
    p.add_argument('--stage',choices=('train','validation'),required=True)
    p.add_argument('--data-root',type=Path,required=True)
    p.add_argument('--train-report',type=Path)
    p.add_argument('--train-sha256',type=str,help='Exact separately frozen 64-character SHA256 of TRAIN JSON; mandatory for validation')
    p.add_argument('--out',type=Path,required=True)
    a=p.parse_args(argv)
    if a.out.exists():raise FileExistsError('refuse to overwrite any result')
    if not a.out.parent.is_dir():raise ValueError('output directory must already exist')
    if a.stage=='train':
        if a.train_report or a.train_sha256:p.error('--train-report and --train-sha256 only for validation')
        report=train(a.data_root)
    else:
        if not a.train_report or not a.train_sha256:
            p.error('validation requires --train-report AND a separately frozen --train-sha256')
        raw=a.train_report.read_bytes()
        digest=_sha256_bytes(raw)
        if len(a.train_sha256)!=64 or digest!=a.train_sha256.lower():
            raise ValueError('frozen train report SHA256 mismatch')
        report=validate(a.data_root,json.loads(raw),digest)
    encoded=(json.dumps(report,ensure_ascii=False,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()
    if len(encoded)>MAX_REPORT_BYTES:raise ValueError('report too large')
    with a.out.open('xb') as f:f.write(encoded)
    print(json.dumps({'stage':report['stage'],'out':str(a.out),
                      'sha256':hashlib.sha256(encoded).hexdigest(),
                      'selected_config_ids':report['selected_config_ids'],
                      'validation_unseen':report.get('validation_unseen',False),
                      'holdout_unseen':True,'no_orders':True},sort_keys=True))


if __name__=='__main__':main()
