"""Offline compatibility fixture: test stub is NOT a real Freqtrade acceptance."""
import hashlib
import math
import sys
import types
from pathlib import Path

import pytest

from tpsl_lab.model import Candle
from tpsl_lab import freqtrade_runtime_cli as ft


def synthetic(n=300):
    result = []
    for i in range(n):
        c = 100 + i * 0.03 + 4 * math.sin(i / 11)
        result.append(Candle(i*60, c, c+0.5, c-0.5, c, 10))
    return result


@pytest.fixture
def stub(monkeypatch):
    fake_pkg = types.ModuleType('freqtrade')
    fake_strat = types.ModuleType('freqtrade.strategy')
    class IStrategy:
        def __init__(self, config): self.config = config
    fake_strat.IStrategy = IStrategy
    monkeypatch.setitem(sys.modules, 'freqtrade', fake_pkg)
    monkeypatch.setitem(sys.modules, 'freqtrade.strategy', fake_strat)
    return IStrategy


@pytest.mark.parametrize('kind', ['ema', 'donchian'])
def test_harness_computes_adapter_parity(stub, kind):
    out = ft.check_actual_strategy(synthetic(), kind=kind, is_strategy=stub)
    assert out['bars'] == 300
    assert out['matches'] == 300
    assert out['mismatches'] == 0
    assert out['mismatch_sample'] == []
    assert out['adapter_sha256'] == hashlib.sha256(ft.ADAPTER.read_bytes()).hexdigest()


def test_adaptor_has_no_network_or_order_execution(stub):
    import ast
    syntax = ast.parse(ft.ADAPTER.read_text())
    imports = set()
    for item in ast.walk(syntax):
        if isinstance(item, ast.Import):
            imports.update(alias.name for alias in item.names)
        if isinstance(item, ast.ImportFrom):
            imports.add(item.module)
    assert not (imports & {'requests','httpx','ccxt','socket','subprocess'})
    assert 'create_order(' not in ft.ADAPTER.read_text()
    assert ft.check_actual_strategy(synthetic(),kind='ema',is_strategy=stub)['mismatches']==0


def test_missing_distribution_fails_closed(monkeypatch):
    import importlib.metadata as md
    def missing(name): raise md.PackageNotFoundError(name)
    monkeypatch.setattr(md, 'distribution', missing)
    with pytest.raises(RuntimeError, match='not installed'):
        ft.verify_real_freqtrade()


def test_real_dist_rejects_wrong_strategy_module(monkeypatch, stub):
    import importlib.metadata as md
    class FakeDist: version = 'fake'
    monkeypatch.setattr(md, 'distribution', lambda _: FakeDist())
    with pytest.raises(RuntimeError, match='real Freqtrade'):
        ft.verify_real_freqtrade()


@pytest.mark.parametrize('kind',['random','never','unknown'])
def test_not_supported_kind_fails(stub, kind):
    with pytest.raises(ValueError, match='only ema'):
        ft.check_actual_strategy(synthetic(),kind=kind,is_strategy=stub)


def test_missing_adapter_rejected(stub,tmp_path):
    with pytest.raises(FileNotFoundError):
        ft.check_actual_strategy(synthetic(), kind='ema', is_strategy=stub,adapter_path=tmp_path/'absent.py')


def test_requires_contiguous_bars(stub):
    b=synthetic()
    with pytest.raises(ValueError, match='continuous'):
        ft.check_actual_strategy(b[:30]+b[31:], kind='ema',is_strategy=stub)


def test_rejects_no_data(stub):
    with pytest.raises(ValueError):
        ft.check_actual_strategy([],kind='ema',is_strategy=stub)


def test_mismatch_is_diagnosed(stub,monkeypatch):
    original=ft.stream_signals
    def modified(bars,kind):
        res=original(bars,kind)
        res[220] = 0 if res[220] else 1
        return res
    monkeypatch.setattr(ft,'stream_signals',modified)
    result=ft.check_actual_strategy(synthetic(),kind='ema',is_strategy=stub)
    assert result['mismatches']==1
    assert result['mismatch_sample'][0]['index']==220


def test_no_future_data_mutation(stub):
    b=synthetic(330)
    c=b[:250]+[Candle(x.ts,x.open+1,x.high+1,x.low+1,x.close+1,x.volume) for x in b[250:]]
    one=ft.check_actual_strategy(b,kind='ema',is_strategy=stub)
    two=ft.check_actual_strategy(c,kind='ema',is_strategy=stub)
    assert one['mismatches']==two['mismatches']==0


def test_strategy_is_not_subclass_rejected(stub):
    class NotStrategy: pass
    with pytest.raises(TypeError,match='IStrategy subclass'):
        ft.check_actual_strategy(synthetic(),kind='ema',is_strategy=NotStrategy)
