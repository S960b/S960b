"""Offline-only audit of publicly downloaded Binance SPOT daily BTCUSDT 1m.

The kline CSV wire format is shared with the USD-M daily auditor, but the
source MUST be the separate /data/spot/ tree. This script never downloads.
"""
import argparse
import csv
from datetime import date, datetime, timedelta, timezone
import json
from pathlib import Path

from .dataset import _find_day, read_daily


def audit_spot_dir(input_dir: Path, start_date: str, days: int, output_dir: Path):
    if type(days) is not int or not 1 <= days <= 31:
        raise ValueError('1..31 days required')
    start=date.fromisoformat(start_date)
    if start.isoformat()!=start_date:
        raise ValueError('noncanonical start date')
    if output_dir.exists():
        raise FileExistsError('refuse to overwrite spot export directory')
    all_bars=[]
    daily=[]
    for n in range(days):
        day=start+timedelta(days=n)
        row=read_daily(_find_day(input_dir,'BTCUSDT',day),day)
        daily.append({'utc_day':day.isoformat(), 'path':Path(row.source_path).name,
                      'archive_sha256':row.raw_sha256,'csv_sha256':row.csv_sha256,
                      'bars':len(row.bars)})
        all_bars.extend(row.bars)
    if any(b.ts!=all_bars[0].ts+60*i for i,b in enumerate(all_bars)):
        raise ValueError('cross-day gap')
    output_dir.mkdir(parents=True,exist_ok=False)
    with (output_dir/'spot_1m.csv').open('x',newline='',encoding='utf8') as f:
        writer=csv.writer(f,lineterminator='\n')
        writer.writerow(['timestamp','open','high','low','close','volume'])
        for b in all_bars:
            writer.writerow([b.ts,b.open,b.high,b.low,b.close,b.volume])
    report={'schema':'tpsl-lab/spot-dataset-v1', 'market':'Binance public SPOT BTCUSDT',
            'days':days,'bars':len(all_bars),'first_ts':all_bars[0].ts,
            'end_exclusive_ts':all_bars[-1].ts+60,'daily':daily,
            'restrictions':['TECHNICAL_ENGINE_TEST_NOT_PROFITABILITY','OFFLINE_NO_ORDERS']}
    with (output_dir/'spot_audit.json').open('x',encoding='utf8') as f:
        json.dump(report,f,indent=2,sort_keys=True)
        f.write('\n')
    return report


def main(argv=None):
    p=argparse.ArgumentParser(description='Strict local SPOT BTCUSDT 1m ZIP audit; no internet')
    p.add_argument('--input-dir',type=Path,required=True)
    p.add_argument('--start-date',required=True)
    p.add_argument('--days',type=int,required=True)
    p.add_argument('--export-dir',type=Path,required=True)
    a=p.parse_args(argv)
    print(json.dumps(audit_spot_dir(a.input_dir,a.start_date,a.days,a.export_dir),indent=2))


if __name__=='__main__':
    main()
