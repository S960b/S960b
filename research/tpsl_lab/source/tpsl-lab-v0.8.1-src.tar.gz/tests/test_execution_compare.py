"""Synthetic, network-free tests of execution export comparability (not PnL edge)."""
from datetime import datetime, timezone
import json
from pathlib import Path
import zipfile

import pytest

from tpsl_lab.execution_compare import (
    reference_from_file, parse_freqtrade_trades, compare_reference, _parse_utc,
)
from tpsl_lab.execution_compare_cli import main


def sample_json(tmp_path, rows=None):
    p = tmp_path / 'freqtrade.json'
    trades = [] if rows is None else rows
    p.write_text(json.dumps({'strategy': {'TpslLabEmaParity': trades}}))
    return p


def row(*, pair='BTC/USDT:USDT', is_short=False, open_rate=100, close_rate=101,
        open_date='2024-06-01 00:01:00', close_date='2024-06-01 00:02:00', exit_reason='roi'):
    return locals()


def signal_data(tmp_path, n=255):
    import csv
    p = tmp_path / 'bars.csv'
    with p.open('w') as f:
        w = csv.writer(f)
        w.writerow(['timestamp', 'open', 'high', 'low', 'close', 'volume'])
        for i in range(n):
            close = 100 + i * .03
            w.writerow([1717200000 + 60 * i, close, close * 1.001, close * .999,
                        close, 10])
    return p


def test_reference_locks_signal_count_and_hash(tmp_path):
    r = reference_from_file(signal_data(tmp_path), kind='ema')
    assert r['bars'] == 255
    assert r['signal_count_long'] > 0
    assert r['signal_count_short'] == 0
    assert r['comparison_status'] == 'REFERENCE_ONLY_NOT_EXECUTION_PARITY'
    assert r['reference']['schema'] == 'tpsl-lab/v0.1'
    assert 'NO_FUNDING' in r['reference']['limitations']


def test_reference_rejects_gaps(tmp_path):
    p = signal_data(tmp_path)
    s = p.read_text().replace('1717200060', '1717200120', 1)
    p.write_text(s)
    with pytest.raises(ValueError, match='continuous'):
        reference_from_file(p, kind='ema')


def test_reference_rejects_invalid_kind(tmp_path):
    with pytest.raises(ValueError, match='kind'):
        reference_from_file(signal_data(tmp_path), kind='random')


def test_parse_basic_and_utc_conversion(tmp_path):
    got = parse_freqtrade_trades(sample_json(tmp_path, [row()]),
                                strategy='TpslLabEmaParity', pair='BTC/USDT:USDT')
    assert got[0]['entry_ts'] == int(datetime(2024,6,1,0,1,tzinfo=timezone.utc).timestamp())
    assert got[0]['direction'] == 1
    assert got[0]['exit_reason'] == 'roi'


def test_parse_short_and_sorting(tmp_path):
    data = [row(open_date='2024-06-01 00:03:00', close_date='2024-06-01 00:04:00', is_short=True), row()]
    got = parse_freqtrade_trades(sample_json(tmp_path,data),strategy='TpslLabEmaParity',pair='BTC/USDT:USDT')
    assert [x['direction'] for x in got] == [1,-1]


def test_parse_zip_export(tmp_path):
    p = tmp_path/'z.zip'
    with zipfile.ZipFile(p,'w') as z:
        z.writestr('bt.json', json.dumps({'strategy': {'TpslLabEmaParity': [row()]}}))
        z.writestr('bt.meta.json','{}')
    got = parse_freqtrade_trades(p,strategy='TpslLabEmaParity',pair='BTC/USDT:USDT')
    assert len(got)==1


def test_reject_zip_traversal(tmp_path):
    p=tmp_path/'z.zip'
    with zipfile.ZipFile(p,'w') as z:
        z.writestr('../secrets.json',json.dumps({'strategy':{'TpslLabEmaParity':[]}}))
    with pytest.raises(ValueError,match='unsafe'):
        parse_freqtrade_trades(p,strategy='TpslLabEmaParity',pair='BTC/USDT:USDT')


def test_reject_multiple_zip_exports(tmp_path):
    p=tmp_path/'z.zip'
    with zipfile.ZipFile(p,'w') as z:
        z.writestr('one.json','{}')
        z.writestr('two.json','{}')
    with pytest.raises(ValueError,match='exactly one'):
        parse_freqtrade_trades(p,strategy='TpslLabEmaParity',pair='BTC/USDT:USDT')


@pytest.mark.parametrize('bad', [
    row(pair='ETH/USDT:USDT'),
    row(open_rate=-1),
    row(is_short=1),
    row(open_date='2024-06-01T00:01:00+03:00'),
    row(close_date='2024-06-01 00:00:00'),
    row(open_date='2024-06-01T00:01:00.001Z'),
])
def test_reject_bad_trade(tmp_path,bad):
    with pytest.raises(ValueError):
        parse_freqtrade_trades(sample_json(tmp_path,[bad]),strategy='TpslLabEmaParity',pair='BTC/USDT:USDT')


def test_reject_duplicate_trade_entries(tmp_path):
    with pytest.raises(ValueError,match='duplicate'):
        parse_freqtrade_trades(sample_json(tmp_path,[row(),row()]),strategy='TpslLabEmaParity',pair='BTC/USDT:USDT')


def test_reject_wrong_strategy(tmp_path):
    with pytest.raises(ValueError,match='strategy'):
        parse_freqtrade_trades(sample_json(tmp_path),strategy='WrongName',pair='BTC/USDT:USDT')


def test_comparator_difference_and_missing_counts(tmp_path):
    r=reference_from_file(signal_data(tmp_path),kind='ema')
    a=r['reference']['trades']
    assert a
    t=a[0]
    ft=[{'entry_ts':t['entry_ts'],'exit_ts':t['exit_ts']+60,'direction':t['direction'],
         'entry_price':t['entry_price']*1.001,'exit_price':t['exit_price']*1.002,'exit_reason':'roi'}]
    got=compare_reference(r,ft,ft_sha256='a'*64,strategy='TpslLabEmaParity',pair='BTC/USDT:USDT')
    assert got['matched_entry_direction']==1
    assert got['entry_price_mismatches']==1
    assert got['exit_price_mismatches']==1
    assert got['exit_time_mismatches']==1
    assert got['only_reference']==len(a)-1
    assert got['status']=='DIAGNOSTIC_ONLY_NOT_PROOF_OF_EXCHANGE_FILLS'


def test_comparator_no_trade_ft(tmp_path):
    r=reference_from_file(signal_data(tmp_path),kind='ema')
    got=compare_reference(r,[],ft_sha256='a'*64,strategy='TpslLabEmaParity',pair='BTC/USDT:USDT')
    assert got['only_reference']==len(r['reference']['trades'])
    assert got['only_freqtrade']==0


def test_cli_reference_only_and_no_overwrite(tmp_path):
    p=signal_data(tmp_path);out=tmp_path/'report.json'
    assert main(['--csv',str(p),'--kind','ema','--out',str(out)])==0
    j=json.loads(out.read_text())
    assert j['compare'] is None and not j['live_orders']
    with pytest.raises(SystemExit):
        main(['--csv',str(p),'--kind','ema','--out',str(out)])


def test_cli_requires_pair_of_ft_arguments(tmp_path):
    p=signal_data(tmp_path)
    with pytest.raises(SystemExit):
        main(['--csv',str(p),'--kind','ema','--out',str(tmp_path/'out.json'),
              '--ft-strategy','TpslLabEmaParity'])


def test_cli_with_export(tmp_path):
    p=signal_data(tmp_path);out=tmp_path/'out.json';ft=sample_json(tmp_path)
    assert main(['--csv',str(p),'--kind','ema','--out',str(out),
                 '--ft-strategy','TpslLabEmaParity','--ft-export',str(ft)])==0
    j=json.loads(out.read_text())
    assert j['compare']['only_reference']>0
    assert j['compare']['freqtrade_strategy']=='TpslLabEmaParity'


def test_long_only_reference_filters_short(tmp_path):
    import csv
    p=tmp_path/'bars.csv'
    with p.open('w') as f:
        w=csv.writer(f);w.writerow(['timestamp','open','high','low','close','volume'])
        for i in range(250):
            c=120-i*.06
            w.writerow([1717200000+60*i,c,c*1.001,c*.999,c,10])
    normal=reference_from_file(p,kind='ema',long_only=False)
    longonly=reference_from_file(p,kind='ema',long_only=True)
    assert normal['signal_count_short']>0
    assert longonly['signal_count_short']==0
    assert longonly['reference']['closed_trades']==0
    assert longonly['long_only'] is True


def test_spot_converter_make_frame(tmp_path):
    from tpsl_lab.freqtrade_store_cli import make_frame
    from tpsl_lab.io import read_csv
    p=signal_data(tmp_path)
    df=make_frame(read_csv(p))
    assert len(df)==255 and df['date'].iloc[0].tzinfo is not None
    assert list(df.columns)==['date','open','high','low','close','volume']


def test_spot_converter_fails_if_nonempty_target(tmp_path):
    from tpsl_lab.freqtrade_store_cli import store_checked
    p=signal_data(tmp_path)
    d=tmp_path/'existing';d.mkdir()
    with pytest.raises(FileExistsError):
        store_checked(p,d)


def test_spot_converter_rejects_pair(tmp_path):
    from tpsl_lab.freqtrade_store_cli import store_checked
    p=signal_data(tmp_path)
    with pytest.raises(ValueError,match='only accepts'):
        store_checked(p,tmp_path/'newdir',pair='BTC/USDT:USDT')


def test_spot_dataset_reject_missing_zip(tmp_path):
    from tpsl_lab.spot_dataset_cli import audit_spot_dir
    with pytest.raises(ValueError,match='expected exactly one'):
        audit_spot_dir(tmp_path,'2024-06-01',1,tmp_path/'new')


def test_spot_dataset_reject_existing_output(tmp_path):
    from tpsl_lab.spot_dataset_cli import audit_spot_dir
    d=tmp_path/'some_output';d.mkdir()
    with pytest.raises(FileExistsError):
        audit_spot_dir(tmp_path,'2024-06-01',1,d)
