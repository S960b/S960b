"""Read-only CLI: calculate reference execution and compare local Freqtrade exports."""
import argparse
import hashlib
import json
from pathlib import Path

from .execution_compare import compare_reference, parse_freqtrade_trades, reference_from_file


def main(argv=None):
    p = argparse.ArgumentParser(description='No-orders TP/SL reference vs Freqtrade trade-export diagnostics')
    p.add_argument('--csv', required=True, type=Path)
    p.add_argument('--kind', choices=['ema', 'donchian'], required=True)
    p.add_argument('--fee', type=float, default=.0005)
    p.add_argument('--slippage', type=float, default=0.0)
    p.add_argument('--notional', type=float, default=100.)
    p.add_argument('--wallet', type=float, default=1000.)
    p.add_argument('--long-only', action='store_true')
    p.add_argument('--ft-export', type=Path)
    p.add_argument('--ft-strategy')
    p.add_argument('--ft-pair', default='BTC/USDT:USDT')
    p.add_argument('--out', type=Path, required=True)
    a = p.parse_args(argv)
    if a.out.exists():
        p.error('refusing to overwrite existing report')
    if (a.ft_export is None) != (a.ft_strategy is None):
        p.error('--ft-export and --ft-strategy must be supplied together')
    ref = reference_from_file(a.csv, kind=a.kind, fee=a.fee, slippage=a.slippage,
                              notional=a.notional, starting_equity=a.wallet, long_only=a.long_only)
    doc = {'schema': 'tpsl-lab/execution-report-v1', 'reference': ref,
           'compare': None, 'live_orders': False}
    if a.ft_export is not None:
        trades = parse_freqtrade_trades(a.ft_export, strategy=a.ft_strategy, pair=a.ft_pair)
        doc['compare'] = compare_reference(ref, trades, ft_sha256=hashlib.sha256(a.ft_export.read_bytes()).hexdigest(),
                                           strategy=a.ft_strategy, pair=a.ft_pair)
    content = json.dumps(doc, indent=2, sort_keys=True, allow_nan=False) + '\n'
    with a.out.open('x', encoding='utf-8') as f:
        f.write(content)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
