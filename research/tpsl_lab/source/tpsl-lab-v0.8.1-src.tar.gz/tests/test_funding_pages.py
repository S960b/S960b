"""Synthetic offline cases for tamper, pagination boundaries and data provenance."""
import hashlib
import json
from pathlib import Path
import pytest
from tpsl_lab.funding_pages import audit_funding_pages

T = 1717200000000
END = T + 7 * 86400000


def row(ms, symbol='BTCUSDT'):
    return {'symbol':symbol,'fundingTime':ms,'fundingRate':'0.0001','markPrice':'67800.0'}


def fixture(tmp_path, ranges=None, records=None, end=END):
    ranges = ranges or [(T,end)]
    pages=[]
    for i,(s,e) in enumerate(ranges):
        values = [r for r in (records if records is not None else [row(T),row(T+8*3600000+1),row(end)])
                  if s <= r['fundingTime'] <= e]
        fn=f'page{i}.json'
        raw=json.dumps(values).encode()
        (tmp_path/fn).write_bytes(raw)
        pages.append({'start_ms':s,'end_ms':e,'limit':1000,'file':fn,
                      'sha256':hashlib.sha256(raw).hexdigest()})
    manifest={'schema':'tpsl-lab/funding-pages-v1','symbol':'BTCUSDT','start_ms':T,
              'end_exclusive_ms':end,'pages':pages}
    m=tmp_path/'manifest.json';m.write_text(json.dumps(manifest));return m,manifest


def test_single_page_with_inclusive_end_preserves_ms(tmp_path):
    manifest,_=fixture(tmp_path)
    out=tmp_path/'funding.json';audit=tmp_path/'audit.json'
    result=audit_funding_pages(manifest,out,audit)
    assert result['funding_event_count']==2
    assert result['end_boundary_excluded']==1
    assert result['timestamps_ms']==[T,T+8*3600000+1]
    assert len(json.loads(out.read_text()))==2
    assert json.loads(audit.read_text())['exchange_event_completeness']=='NOT_PROVEN'


def test_multiple_contiguous_pages(tmp_path):
    mid=T+3*86400000
    m,_=fixture(tmp_path,[(T,mid-1),(mid,END)],records=[row(T),row(mid+1),row(END)])
    assert audit_funding_pages(m)['page_count']==2


def test_window_gap_fails(tmp_path):
    mid=T+3*86400000
    m,_=fixture(tmp_path,[(T,mid-2),(mid,END)],records=[row(T),row(mid+1)])
    with pytest.raises(ValueError,match='noncontiguous'):audit_funding_pages(m)


def test_window_overlap_fails(tmp_path):
    mid=T+3*86400000
    m,_=fixture(tmp_path,[(T,mid),(mid,END)],records=[row(T),row(mid+1)])
    with pytest.raises(ValueError,match='noncontiguous'):audit_funding_pages(m)


def test_full_response_limit_fails(tmp_path):
    m,d=fixture(tmp_path)
    d['pages'][0]['limit']=3
    m.write_text(json.dumps(d))
    with pytest.raises(ValueError,match='possible truncation'):audit_funding_pages(m)


def test_tamper_fails(tmp_path):
    m,_=fixture(tmp_path)
    (tmp_path/'page0.json').write_text('[]')
    with pytest.raises(ValueError,match='SHA-256 mismatch'):audit_funding_pages(m)


def test_wrong_symbol_fails(tmp_path):
    m,_=fixture(tmp_path,records=[row(T,'ETHUSDT')])
    with pytest.raises(ValueError,match='symbol'):audit_funding_pages(m)


def test_duplicate_timestamps_fails(tmp_path):
    m,_=fixture(tmp_path,records=[row(T),row(T)])
    with pytest.raises(ValueError,match='duplicate'):audit_funding_pages(m)


def test_reversed_timestamps_fails(tmp_path):
    m,_=fixture(tmp_path,records=[row(T+10000),row(T)])
    with pytest.raises(ValueError,match='order'):audit_funding_pages(m)


def test_outside_request_fails(tmp_path):
    m,d=fixture(tmp_path,records=[row(T-1)])
    data=[row(T-1)];raw=json.dumps(data).encode();(tmp_path/'page0.json').write_bytes(raw)
    d['pages'][0]['sha256']=hashlib.sha256(raw).hexdigest();m.write_text(json.dumps(d))
    with pytest.raises(ValueError,match='outside'):audit_funding_pages(m)


def test_path_traversal_fails(tmp_path):
    m,d=fixture(tmp_path)
    d['pages'][0]['file']='../private.json';m.write_text(json.dumps(d))
    with pytest.raises((ValueError,FileNotFoundError)):audit_funding_pages(m)


def test_existing_output_refused(tmp_path):
    m,_=fixture(tmp_path);p=tmp_path/'out.json';p.write_text('no overwrite')
    with pytest.raises(ValueError,match='overwrite'):audit_funding_pages(m,export_events=p)
    assert p.read_text()=='no overwrite'


def test_large_gap_is_warning_not_failure(tmp_path):
    m,_=fixture(tmp_path,records=[row(T),row(T+15*3600000)])
    r=audit_funding_pages(m)
    assert len(r['gaps_over_12h_observed'])==1
    assert r['exchange_event_completeness']=='NOT_PROVEN'


def test_bad_rate_rejected(tmp_path):
    rec=row(T);rec['fundingRate']='nan'
    m,_=fixture(tmp_path,records=[rec])
    with pytest.raises(ValueError,match='nonfinite'):audit_funding_pages(m)


def test_missing_page_file_rejected(tmp_path):
    m,_=fixture(tmp_path)
    (tmp_path/'page0.json').unlink()
    with pytest.raises(FileNotFoundError):audit_funding_pages(m)
