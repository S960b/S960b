"""Offline, unlevered reference engine. Not an execution bot."""
__version__ = "0.13.0"
