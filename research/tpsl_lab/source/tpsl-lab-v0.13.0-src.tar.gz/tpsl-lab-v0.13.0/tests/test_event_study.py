import json
import math
import pytest

from tpsl_lab.model import Candle,Costs
from tpsl_lab import event_study as es


def bar(i,close=100.0,high=None,low=None,volume=1.0):
    h=close if high is None else high
    l=close if low is None else low
    return Candle(i*60,close,h,l,close,volume)


def test_preregistration_eight_unique_no_holdout():
    cfg=es.configs()
    assert len(cfg)==8 and len({x['id'] for x in cfg})==8
    assert {x['entry_rule'] for x in cfg}==set(es.RULES)
    assert {x['timeframe_min'] for x in cfg}=={1,15}
    assert { (x['tp_pct'],x['sl_pct']) for x in cfg}=={(.02,.01),(.03,.01)}
    assert '2026-07' in es.plan()['unread_holdout_months']
    assert es.plan()['holdout_sealed'] is True
    assert es.plan()['no_orders'] is True


def test_unknown_rule_and_timeframe_rejected():
    with pytest.raises(ValueError):es.TimeframeSignal('ema',1)
    with pytest.raises(ValueError):es.TimeframeSignal('ema_cross',5)
    with pytest.raises(ValueError):es.EmaCrossEvent(201,200)
    with pytest.raises(ValueError):es.DonchianFirstEvent(1)


def test_tf15_not_before_fifteenth_minute():
    e=es.TimeframeSignal('donchian_first',15)
    for i in range(14):assert e.on_close(bar(i))==0
    assert e.completions==0
    assert e.on_close(bar(14))==0
    assert e.completions==1
    assert e.next_ts==900


def test_tf15_utc_aligned_aggregates_one_bar():
    e=es.TimeframeSignal('donchian_first',15)
    for i in range(15):e.on_close(bar(i,close=100+i*.01,high=100+i*.01,low=99+i*.01))
    assert len(e.rule.highs)==1
    assert e.rule.highs[0]==pytest.approx(100.14)
    assert e.next_ts==900


def test_tf15_unaligned_start_fails():
    with pytest.raises(ValueError,match='UTC boundary'):es.TimeframeSignal('donchian_first',15).on_close(bar(1))


def test_tf15_gap_fails():
    s=es.TimeframeSignal('donchian_first',15)
    s.on_close(bar(0))
    with pytest.raises(ValueError,match='gap'):s.on_close(bar(2))


def test_tf15_signal_only_at_complete_bar_and_next_open():
    s=es.TimeframeSignal('donchian_first',15)
    # 20 full previous TF blocks with flat OHLC at 100
    for i in range(20*15): assert s.on_close(bar(i))==0
    for i in range(20*15,21*15-1):assert s.on_close(bar(i,close=101))==0
    assert s.on_close(bar(21*15-1,close=101))==1
    assert s.events==1
    assert s.next_ts==21*15*60


def test_ema_cross_only_once_in_persistent_trend():
    a=es.EmaCrossEvent(fast=2,slow=4)
    out=[a.on_close(bar(i,close=100+i)) for i in range(40)]
    assert out.count(1)<=1
    assert all(x in (0,1) for x in out)


def test_ema_200_warmup_and_single_event():
    a=es.EmaCrossEvent()
    x=[a.on_close(bar(i,close=100+i*.1)) for i in range(260)]
    assert sum(x[:199])==0
    assert x.count(1)<=1


def test_donchian_previous_20_highs_first_event():
    d=es.DonchianFirstEvent()
    for i in range(20):assert d.on_close(bar(i,close=100))==0
    assert d.on_close(bar(20,close=101))==1
    assert d.on_close(bar(21,close=102))==0
    assert d.on_close(bar(22,close=103))==0


def test_donchian_cooldown_enforced():
    d=es.DonchianFirstEvent(window=2,cooldown_seconds=3600)
    for i in range(2):d.on_close(bar(i,100))
    assert d.on_close(bar(2,101))==1
    d.on_close(bar(3,100))
    assert d.on_close(bar(4,102))==0
    for i in range(5,63):d.on_close(bar(i,100))
    assert d.on_close(bar(63,103))==1


def test_no_future_data_changes_past_signals():
    def get(mutated):
        s=es.TimeframeSignal('donchian_first',15)
        out=[]
        for i in range(450):
            p=100+i*.015
            if mutated and i>=375:p+=20
            out.append(s.on_close(bar(i,close=p)))
        return out
    a,b=get(False),get(True)
    assert a[:375]==b[:375]


def test_no_fabricated_signals_on_incomplete_last_tf15():
    s=es.TimeframeSignal('ema_cross',15)
    for i in range(16):s.on_close(bar(i))
    assert s.completions==1 and len(s.pending_bars)==1


def test_simulate_long_only_and_fee():
    cfg=es.configs()[0]
    bars=[bar(i,close=100+i*.1) for i in range(260)]
    result=es.simulate(bars,cfg,Costs())
    assert result['closed_trades']>=0
    assert result['fee_usdt']>=0
    assert 'signal_events' in result


def test_select_empty_if_negative_stress():
    fake=[]
    for c in es.configs():
        fake.append({**c,'by_symbol':{s:{'baseline':{'closed_trades':30,'net_marked_usdt':1},'stress':{'net_marked_usdt':-1,'max_drawdown':0.01}} for s in es.SYMBOLS}})
    assert es.select(fake)==[]


def test_select_rank_deterministic_and_bounded():
    fake=[]
    for idx,c in enumerate(es.configs()):
        fake.append({**c,'by_symbol':{s:{'baseline':{'closed_trades':31,'net_marked_usdt':10+idx},'stress':{'net_marked_usdt':1+idx,'max_drawdown':0.01}} for s in es.SYMBOLS}})
    selected=es.select(fake)
    assert len(selected)==2
    assert selected==[es.configs()[-1]['id'],es.configs()[-2]['id']]


def test_select_rejects_missing_rows():
    with pytest.raises(ValueError):es.select([])


def test_frozen_train_invalid_fails():
    with pytest.raises(ValueError):es._verify_frozen_train({'schema':es.SCHEMA,'stage':'train','plan':es.plan(),'holdout_unseen':False})


def test_validation_with_no_selected_is_blocked_before_read(monkeypatch):
    fake=[]
    for c in es.configs():
        fake.append({**c,'by_symbol':{s:{'baseline':{'closed_trades':30,'net_marked_usdt':-1},'stress':{'net_marked_usdt':-1,'max_drawdown':0.01}} for s in es.SYMBOLS}})
    t={'schema':es.SCHEMA,'stage':'train','plan':es.plan(),'holdout_unseen':True,'validation_unseen':True,'config_results':fake,'selected_config_ids':[],'selected_count':0}
    monkeypatch.setattr(es,'load_split',lambda *_:pytest.fail('validation must not open data'))
    with pytest.raises(ValueError,match='NO_ELIGIBLE'):es.validate(None,t,'abc')


def test_cli_refuses_holdout(monkeypatch,tmp_path):
    with pytest.raises(SystemExit):es.main(['--stage','holdout','--data-root',str(tmp_path),'--out',str(tmp_path/'x.json')])


def test_cli_no_overwrite(monkeypatch,tmp_path):
    p=tmp_path/'a.json';p.write_text('protected')
    with pytest.raises(FileExistsError):es.main(['--stage','train','--data-root',str(tmp_path),'--out',str(p)])
    assert p.read_text()=='protected'


def test_split_sealed_by_underlying_loader(tmp_path):
    from tpsl_lab.spot_study import load_split, read_spot_month
    with pytest.raises(ValueError,match='HOLDOUT'):read_spot_month(tmp_path,'BTCUSDT','2026-07')
    with pytest.raises(ValueError,match='HOLDOUT'):load_split(tmp_path,'holdout')


def test_validation_frozen_sha_failure_prevents_input_read(monkeypatch,tmp_path):
    report=tmp_path/'train.json';report.write_text('{}')
    monkeypatch.setattr(es,'load_split',lambda *_:pytest.fail('validation must not open any dataset'))
    with pytest.raises(ValueError,match='SHA256 mismatch'):
        es.main(['--stage','validation','--data-root',str(tmp_path),
                 '--train-report',str(report),'--train-sha256','0'*64,
                 '--out',str(tmp_path/'validation.json')])


def test_validation_sha_is_mandatory(tmp_path):
    report=tmp_path/'train.json';report.write_text('{}')
    with pytest.raises(SystemExit):
        es.main(['--stage','validation','--data-root',str(tmp_path),
                 '--train-report',str(report),'--out',str(tmp_path/'validation.json')])
