"""Offline, deterministic and fail-closed preregistered monthly research tests."""
import hashlib
import io
import json
import zipfile
from datetime import datetime,timezone
from pathlib import Path

import pytest

from tpsl_lab.model import Candle
from tpsl_lab.spot_study import (
    BASELINE_COST, SPLITS, HOLDOUT_MONTHS, SCHEMA, _configs, _checksum_expected,
    _select, _verify_train_report, _plan_metadata, _replay_summary,
    _find_exact, read_spot_month, LongOnly, config_id, load_split,
    validate, MAX_SELECTED,MIN_TRADES_PER_SYMBOL,
)


def sample(n=250):
    return [Candle(i*60,100+i*.01,100.5+i*.01,99.5+i*.01,100+i*.01,12) for i in range(n)]


def synthzip(root:Path,month='2024-04',symbol='BTCUSDT',bad=None):
    from calendar import monthrange
    year,m=map(int,month.split('-'))
    n=monthrange(year,m)[1]*1440
    ts0=int(datetime(year,m,1,tzinfo=timezone.utc).timestamp())
    scale=1000 if month<'2025-01' else 1_000_000
    name=f'{symbol}-1m-{month}.zip'; member=name[:-4]+'.csv'
    buf=io.StringIO()
    for i in range(n):
        ts=(ts0+i*60)*scale
        if bad=='gap' and i==100:ts+=scale*60
        if bad=='negative' and i==100:open_price=-1
        else:open_price=100
        buf.write(f'{ts},{open_price},101,99,100.5,10,0,0,0,0,0,0\n')
    path=root/name
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        z.writestr('../escape.csv' if bad=='unsafe' else member,buf.getvalue())
    sha=hashlib.sha256(path.read_bytes()).hexdigest()
    (root/(name+'.CHECKSUM')).write_text(f'{sha}  {name}\n')
    return path


def test_grid_preregistered_fixed():
    a=_configs()
    assert len(a)==18 and len({c['id'] for c in a})==18
    assert config_id('ema',.005,.02)=='ema_tp050_sl200'
    assert all(c['entry_rule'] in ('ema','donchian') for c in a)
    with pytest.raises(ValueError):config_id('random',.005,.02)


def test_holdout_not_in_allowed_splits():
    assert all(m not in sum([list(x) for x in SPLITS.values()],[]) for m in HOLDOUT_MONTHS)
    with pytest.raises(ValueError,match='sealed'):
        read_spot_month(Path('/tmp'),'BTCUSDT','2026-07')
    with pytest.raises(ValueError,match='HOLDOUT'):
        load_split(Path('/tmp'),'holdout')


def test_read_april_month_2024_valid(tmp_path):
    synthzip(tmp_path)
    bars,prov=read_spot_month(tmp_path,'BTCUSDT','2024-04')
    assert len(bars)==43200 and prov['rows']==43200 and prov['scale']=='ms'
    assert bars[0].ts==1711929600 and bars[-1].ts==1714521540
    assert prov['zip_sha256']==prov['official_checksum_sha256']


def test_read_april_month_2025_uses_us(tmp_path):
    synthzip(tmp_path,'2025-04')
    bars,prov=read_spot_month(tmp_path,'BTCUSDT','2025-04')
    assert len(bars)==43200 and prov['scale']=='us'
    assert bars[0].ts==1743465600


def test_gap_rejected(tmp_path):
    synthzip(tmp_path,bad='gap')
    with pytest.raises(ValueError,match='noncontiguous'):
        read_spot_month(tmp_path,'BTCUSDT','2024-04')


def test_negative_prices_rejected(tmp_path):
    synthzip(tmp_path,bad='negative')
    with pytest.raises(ValueError,match='prices'):
        read_spot_month(tmp_path,'BTCUSDT','2024-04')


def test_zip_traversal_rejected(tmp_path):
    synthzip(tmp_path,bad='unsafe')
    with pytest.raises(ValueError,match='unsafe ZIP'):
        read_spot_month(tmp_path,'BTCUSDT','2024-04')


def test_wrong_checksum_fails(tmp_path):
    p=synthzip(tmp_path)
    (tmp_path/(p.name+'.CHECKSUM')).write_text('0'*64+'  '+p.name+'\n')
    with pytest.raises(ValueError,match='SHA256 mismatch'):
        read_spot_month(tmp_path,'BTCUSDT','2024-04')


def test_bad_checksum_format_and_name():
    with pytest.raises(ValueError,match='format/name'):
        _checksum_expected(b'0'*64+b'  different.zip','file.zip')
    with pytest.raises(ValueError,match='format/name'):
        _checksum_expected(b'0'*63+b'  file.zip','file.zip')


def test_duplicates_file_paths_fail(tmp_path):
    a=tmp_path/'a'; b=tmp_path/'b';a.mkdir();b.mkdir()
    (a/'x.zip').write_text('1');(b/'x.zip').write_text('2')
    with pytest.raises(ValueError,match='exactly one'):
        _find_exact(tmp_path,'x.zip')


def test_spot_wrapper_never_shorts():
    bars=sample(250)
    for kind in ('ema','donchian','random'):
        s=LongOnly(kind)
        result=[s.on_close(b) for b in bars]
        assert set(result).issubset({0,1})


def test_selection_top_three_worst_asset_and_trade_filter():
    def item(id,p1,p2,n1=40,n2=40,dd1=.01,dd2=.01):
        return {'id':id,'by_symbol':{
            'BTCUSDT':{'closed_trades':n1,'net_marked_usdt':p1,'max_drawdown':dd1},
            'ETHUSDT':{'closed_trades':n2,'net_marked_usdt':p2,'max_drawdown':dd2}}}
    items=[item('a',10,5),item('b',9,7),item('c',1,100),item('d',10,10),item('e',100,-1),item('f',100,100,1,40)]
    assert _select(items)==['d','b','a']


def test_no_winner_blocks_validation():
    items=[]
    for cfg in _configs():
        items.append({**cfg,'by_symbol':{
            'BTCUSDT':{'closed_trades':50,'net_marked_usdt':10,'max_drawdown':.01},
            'ETHUSDT':{'closed_trades':50,'net_marked_usdt':-1,'max_drawdown':.01}}})
    train={'schema':SCHEMA,'stage':'train','plan':_plan_metadata(),
           'config_results':items,'selected_config_ids':[],'holdout_unseen':True}
    assert _verify_train_report(train)==[]
    with pytest.raises(ValueError,match='NO_ELIGIBLE'):
        validate(Path('/does_not_exist'),train,'a'*64)


def test_train_report_tampering_rejected():
    items=[]
    for cfg in _configs():
        items.append({**cfg,'by_symbol':{s:{'closed_trades':50,'net_marked_usdt':2,'max_drawdown':.001}
                                              for s in ('BTCUSDT','ETHUSDT')}})
    train={'schema':SCHEMA,'stage':'train','plan':_plan_metadata(),
           'config_results':items,'selected_config_ids':_select(items),'holdout_unseen':True}
    assert len(_verify_train_report(train))==MAX_SELECTED
    train['plan']['tp_grid']=[.5]
    with pytest.raises(ValueError,match='preregistration'):
        _verify_train_report(train)


def test_replay_deterministic_without_shorts():
    bars=sample(250)
    r1=_replay_summary(bars,'ema',.005,.02,BASELINE_COST)
    r2=_replay_summary(bars,'ema',.005,.02,BASELINE_COST)
    assert r1==r2
    assert r1['marked_equity_usdt']>0


def test_validation_requires_authentic_train_results():
    with pytest.raises(ValueError,match='invalid train'):
        _verify_train_report({'schema':'bad','stage':'train'})


def test_month_zip_name_unique_and_checksum_filename(tmp_path):
    a=synthzip(tmp_path)
    chk=(tmp_path/(a.name+'.CHECKSUM'))
    expected=hashlib.sha256(a.read_bytes()).hexdigest()
    assert _checksum_expected(chk.read_bytes(),a.name)==expected


def test_train_pipeline_uses_only_train_split(monkeypatch,tmp_path):
    import tpsl_lab.spot_study as study
    called=[]
    def fake(root,split):
        called.append(split)
        assert split=='train'
        return {'BTCUSDT':sample(300),'ETHUSDT':sample(300)},[{'month':'2024-04'}]
    monkeypatch.setattr(study,'load_split',fake)
    out=study.train(tmp_path)
    assert called==['train']
    assert out['stage']=='train' and out['holdout_unseen']
    assert len(out['config_results'])==18
    assert out['selected_config_ids']==[]
    assert out['controls']['BTCUSDT']['never']['closed_trades']==0


def test_validation_only_preselected(monkeypatch,tmp_path):
    import tpsl_lab.spot_study as study
    items=[]
    for cfg in _configs():
        items.append({**cfg,'by_symbol':{s:{'closed_trades':45,'net_marked_usdt':2,
            'max_drawdown':0.002} for s in ('BTCUSDT','ETHUSDT')}})
    t={'schema':SCHEMA,'stage':'train','plan':_plan_metadata(),'holdout_unseen':True,
       'config_results':items,'selected_config_ids':_select(items)}
    called=[]
    def fake(root,split):
        called.append(split)
        assert split=='validation'
        return {'BTCUSDT':sample(300),'ETHUSDT':sample(300)},[{'month':'2025-04'}]
    monkeypatch.setattr(study,'load_split',fake)
    out=study.validate(tmp_path,t,'a'*64)
    assert called==['validation']
    assert len(out['candidate_results'])==3 and out['holdout_unseen']
    assert all(set(c['by_symbol']['BTCUSDT'])=={'baseline','stress'} for c in out['candidate_results'])
