import pytest
from tpsl_lab.engine import replay
from tpsl_lab.model import Candle, Costs, Settings
from tpsl_lab.strategies import EmaTrend, NeverEntry, RandomEntry


class Once:
    def __init__(self, direction):
        self.direction = direction
        self.calls = 0

    def on_close(self, bar):
        self.calls += 1
        return self.direction if self.calls == 1 else 0


def bar(i, o=100, h=100, l=100, c=100):
    return Candle(i * 60, o, h, l, c, 1)


def run(rows, direction=1, tp=.01, sl=.005, fee=0, slip=0):
    return replay(rows, Once(direction), Settings(1000, 100, tp, sl), Costs(fee, slip))


def test_signal_at_close_enters_only_at_next_open():
    result = run([bar(0, 100, 110, 90, 100), bar(1, 100)])
    assert result['closed_trades'] == 0
    assert result['open_position']['entry_ts'] == 60


def test_long_target_and_net():
    r = run([bar(0), bar(1, 100, 102, 100, 101)])
    assert r['trades'][0]['exit_reason'] == 'target'
    assert r['trades'][0]['net_pnl'] == pytest.approx(1)
    assert r['closed_equity'] == pytest.approx(1001)


def test_short_target_and_net():
    r = run([bar(0), bar(1, 100, 100, 98, 99)], direction=-1)
    assert r['trades'][0]['exit_reason'] == 'target'
    assert r['trades'][0]['net_pnl'] == pytest.approx(1)


def test_both_levels_hit_assume_stop_long():
    r = run([bar(0), bar(1, 100, 102, 98, 100)])
    assert r['trades'][0]['exit_reason'] == 'stop'
    assert r['trades'][0]['ambiguous'] is True
    assert r['ambiguous_bars_closed_at_stop'] == 1
    assert r['trades'][0]['net_pnl'] == pytest.approx(-.5)


def test_both_levels_hit_assume_stop_short():
    r = run([bar(0), bar(1, 100, 102, 98, 100)], direction=-1)
    assert r['trades'][0]['exit_reason'] == 'stop'
    assert r['trades'][0]['ambiguous'] is True
    assert r['trades'][0]['net_pnl'] == pytest.approx(-.5)


def test_gap_beyond_stop_long_not_filled_at_stop():
    r = run([bar(0), bar(1), bar(2, 97, 98, 96, 97)])
    assert r['trades'][0]['exit_reason'] == 'stop_gap'
    assert r['trades'][0]['exit_price'] == pytest.approx(97)
    assert r['trades'][0]['net_pnl'] == pytest.approx(-3)


def test_gap_beyond_stop_short_not_filled_at_stop():
    r = run([bar(0), bar(1), bar(2, 103, 103, 101, 102)], direction=-1)
    assert r['trades'][0]['exit_reason'] == 'stop_gap'
    assert r['trades'][0]['net_pnl'] == pytest.approx(-3)


def test_adverse_slippage_and_two_fees():
    r = run([bar(0), bar(1, 100, 103, 100, 102)], tp=.01, fee=.001, slip=.001)
    t = r['trades'][0]
    assert t['entry_price'] == pytest.approx(100.1)
    assert t['exit_price'] == pytest.approx(100.1 * 1.01 * .999)
    qty = 100 / 100.1
    expected = qty * (t['exit_price'] - t['entry_price']) - .1 - qty * t['exit_price'] * .001
    assert t['net_pnl'] == pytest.approx(expected)
    assert r['closed_equity'] == pytest.approx(1000 + expected)
    assert r['total_fees'] == pytest.approx(.1 + qty * t['exit_price'] * .001)


def test_reject_time_gaps_duplicate_or_misaligned():
    with pytest.raises(ValueError):
        run([bar(0), bar(2)])
    with pytest.raises(ValueError):
        run([bar(0), bar(0)])
    with pytest.raises(ValueError):
        run([bar(0), Candle(61, 100, 100, 100, 100)])


def test_no_trade_control():
    r = replay([bar(0), bar(1)], NeverEntry())
    assert r['closed_trades'] == 0
    assert r['closed_equity'] == 1000
    assert r['marked_equity'] == 1000


def test_reproducible_random_seed():
    data = [bar(i, 100, 102, 98, 100) for i in range(500)]
    a = replay(data, RandomEntry(seed=123, probability=.5))
    b = replay(data, RandomEntry(seed=123, probability=.5))
    assert a == b
    assert a['closed_trades'] > 0


def test_ema_no_signal_before_warmup():
    ema = EmaTrend(fast=2, slow=4)
    for i in range(3):
        assert ema.on_close(bar(i, 100, 105, 99, 100 + i)) == 0


def test_insufficient_balance_disables_entry():
    r = replay([bar(0), bar(1)], Once(1), Settings(100, 101, .01, .005))
    assert r['open_position'] is None


def test_reject_invalid_data():
    with pytest.raises(ValueError):
        Candle(0, 100, 99, 98, 100)
    with pytest.raises(ValueError):
        Settings(1000, 100, -1, .005)
    with pytest.raises(ValueError):
        Costs(-.001, .001)
