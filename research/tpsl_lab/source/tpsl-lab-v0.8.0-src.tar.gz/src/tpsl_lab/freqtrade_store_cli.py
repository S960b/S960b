"""One-way, OFFLINE import of checked public SPOT candles into Freqtrade storage.

This CLI uses the installed Freqtrade datahandler, not an exchange client.
It refuses non-empty output directories, avoids overwriting data, and
round-trips candles to catch schema/candle-type mismatches.
"""
import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

from .io import read_csv


def make_frame(bars):
    import pandas as pd
    if len(bars) < 2 or any(b.ts != bars[0].ts + i * 60 for i, b in enumerate(bars)):
        raise ValueError('require 1m continuous candles')
    return pd.DataFrame([{'date': datetime.fromtimestamp(b.ts,timezone.utc),
                          'open': b.open, 'high': b.high, 'low': b.low,
                          'close': b.close, 'volume': b.volume} for b in bars])


def store_checked(csv_path: Path, target: Path, *, pair='BTC/USDT') -> dict:
    # Only one explicit pair and a dedicated empty location. This prevents
    # accidental edits to any real Freqtrade user_data directory.
    if pair != 'BTC/USDT':
        raise ValueError('v0.8 only accepts BTC/USDT spot research pair')
    if not csv_path.is_file():
        raise FileNotFoundError(csv_path)
    if target.exists():
        raise FileExistsError('output datadir already exists')
    from freqtrade.data.history.datahandlers import get_datahandler
    from freqtrade.enums import CandleType
    bars = read_csv(csv_path)
    frame = make_frame(bars)
    target.mkdir(parents=True, exist_ok=False)
    handler = get_datahandler(target, 'json')
    handler.ohlcv_store(pair, '1m', frame, candle_type=CandleType.SPOT)
    loaded = handler.ohlcv_load(pair, '1m', candle_type=CandleType.SPOT,
                                fill_missing=False, drop_incomplete=False)
    if len(loaded) != len(frame):
        raise RuntimeError('Freqtrade storage roundtrip bar count differs')
    if not loaded['date'].reset_index(drop=True).equals(frame['date'].reset_index(drop=True)):
        raise RuntimeError('Freqtrade storage timestamp roundtrip differs')
    for col in ('open','high','low','close','volume'):
        for a,b in zip(frame[col],loaded[col]):
            if abs(float(a)-float(b)) > max(1e-9, 1e-12*abs(float(a))):
                raise RuntimeError('Freqtrade storage price/volume differs: '+col)
    return {'schema':'tpsl-lab/spot-data-import-v1', 'pair':pair,
            'bars':len(bars), 'first_ts':bars[0].ts, 'last_ts':bars[-1].ts,
            'source_sha256':hashlib.sha256(csv_path.read_bytes()).hexdigest(),
            'storage':'Freqtrade json SPOT', 'roundtrip':'VERIFIED',
            'no_orders':True, 'futures_funding':'NOT_APPLICABLE_SPOT_TEST'}


def main(argv=None):
    p=argparse.ArgumentParser(description='Local SPOT historical candles into a NEW Freqtrade JSON datadir; no bot')
    p.add_argument('--csv',type=Path,required=True)
    p.add_argument('--datadir',type=Path,required=True)
    p.add_argument('--out',type=Path,required=True)
    args=p.parse_args(argv)
    if args.out.exists():
        p.error('cannot overwrite report')
    report=store_checked(args.csv,args.datadir)
    with args.out.open('x',encoding='utf8') as f:
        json.dump(report,f,indent=2,sort_keys=True,allow_nan=False)
        f.write('\n')


if __name__=='__main__':
    main()
