"""No-orders compatibility check against the actual installed Freqtrade IStrategy.

Never initializes a bot, exchange, data provider, wallets, or API client.
The CLI refuses to run with a mocked or missing Freqtrade distribution.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import importlib.util
import json
from datetime import datetime, timezone
from pathlib import Path

from .entry_signals import stream_signals
from .io import read_csv


ADAPTER = Path(__file__).resolve().parents[2] / "user_data" / "strategies" / "TpslLabSignalParity.py"


def verify_real_freqtrade():
    """Require an installed Freqtrade distribution, not a test stub."""
    try:
        dist = importlib.metadata.distribution("freqtrade")
    except importlib.metadata.PackageNotFoundError as exc:
        raise RuntimeError("Freqtrade is not installed in THIS isolated Python environment") from exc
    from freqtrade.strategy import IStrategy
    if not IStrategy.__module__.startswith("freqtrade."):
        raise RuntimeError("IStrategy does not appear to be the real Freqtrade class")
    return dist.version, IStrategy


def check_actual_strategy(bars, *, kind: str, is_strategy, adapter_path: Path = ADAPTER):
    """Call real-class populate_* hooks on local OHLCV; no Freqtrade bot."""
    import pandas as pd
    if kind not in ("ema", "donchian"):
        raise ValueError("only ema and donchian supported")
    if not bars or any(b.ts != bars[0].ts + 60 * i for i, b in enumerate(bars)):
        raise ValueError("requires continuous 1m bars")
    if not adapter_path.is_file():
        raise FileNotFoundError(adapter_path)
    spec = importlib.util.spec_from_file_location("tpsl_local_freqtrade_adapter", adapter_path)
    if spec is None or spec.loader is None:
        raise RuntimeError("cannot load local Freqtrade strategy")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    classname = "TpslLabEmaParity" if kind == "ema" else "TpslLabDonchianParity"
    cls = getattr(module, classname)
    if not issubclass(cls, is_strategy):
        raise TypeError("adapter is not an IStrategy subclass")
    if cls.timeframe != "1m" or cls.can_short is not True:
        raise RuntimeError("unexpected adapter timeframe or side configuration")
    if getattr(cls, "INTERFACE_VERSION", None) != 3:
        raise RuntimeError("incompatible IStrategy interface version")
    # This creates ONLY a strategy object. No Freqtrade bot or exchange is created.
    strategy = cls(config={})
    frame = pd.DataFrame([{
        "date": datetime.fromtimestamp(b.ts, tz=timezone.utc),
        "open": b.open, "high": b.high, "low": b.low,
        "close": b.close, "volume": b.volume,
    } for b in bars])
    metadata = {"pair": "BTC/USDT:USDT"}
    processed = strategy.populate_indicators(frame.copy(), metadata)
    processed = strategy.populate_entry_trend(processed, metadata)
    processed = strategy.populate_exit_trend(processed, metadata)
    if len(processed) != len(bars) or not processed.index.equals(frame.index):
        raise RuntimeError("strategy changed candle sequence or index")
    for col in ("enter_long", "enter_short", "exit_long", "exit_short"):
        if col not in processed:
            raise RuntimeError("missing Freqtrade signal column: " + col)
        if not processed[col].dropna().isin((0, 1)).all():
            raise RuntimeError("invalid signal values in " + col)
    if processed["exit_long"].fillna(0).ne(0).any() or processed["exit_short"].fillna(0).ne(0).any():
        raise RuntimeError("unexpected explicit exit signals")
    longs = processed["enter_long"].fillna(0).astype(int)
    shorts = processed["enter_short"].fillna(0).astype(int)
    if ((longs == 1) & (shorts == 1)).any():
        raise RuntimeError("conflicting long and short")
    realized = [int(l) - int(s) for l, s in zip(longs, shorts)]
    expected = stream_signals(bars, kind)
    diff = [{"index": i, "ts": b.ts, "reference": expected[i], "freqtrade": realized[i]}
            for i, b in enumerate(bars) if expected[i] != realized[i]]
    return {
        "strategy": classname, "bars": len(bars), "matches": len(bars) - len(diff),
        "mismatches": len(diff), "mismatch_sample": diff[:20],
        "long_count": realized.count(1), "short_count": realized.count(-1),
        "startup_candle_count": cls.startup_candle_count,
        "timeframe": cls.timeframe, "can_short": cls.can_short,
        "adapter_sha256": hashlib.sha256(adapter_path.read_bytes()).hexdigest(),
    }


def main(argv=None):
    parser = argparse.ArgumentParser(description="Offline real-IStrategy signals smoke (no orders)")
    parser.add_argument("--csv", type=Path, required=True)
    parser.add_argument("--binance", action="store_true")
    parser.add_argument("--out", type=Path)
    args = parser.parse_args(argv)
    # Hard requirement: never silently substitute a fake Freqtrade module in CLI.
    freqtrade_version, is_strategy = verify_real_freqtrade()
    bars = read_csv(args.csv, args.binance)
    outputs = [check_actual_strategy(bars, kind=kind, is_strategy=is_strategy)
               for kind in ("ema", "donchian")]
    report = {
        "schema": "tpsl-lab/real-freqtrade-adapter-v1",
        "freqtrade_version": freqtrade_version,
        "data_sha256": hashlib.sha256(args.csv.read_bytes()).hexdigest(),
        "first_ts": bars[0].ts if bars else None,
        "last_ts": bars[-1].ts if bars else None,
        "data_source": "local CSV", "no_orders": True,
        "execution_parity": "NOT_TESTED", "strategy_results": outputs,
    }
    content = json.dumps(report, indent=2, sort_keys=True, allow_nan=False) + "\n"
    if args.out:
        with args.out.open("x", encoding="utf-8") as f:
            f.write(content)
    else:
        print(content)
    return 0 if all(o["mismatches"] == 0 for o in outputs) else 2


if __name__ == "__main__":
    raise SystemExit(main())
