# TP/SL Lab v0.11.0

**New exploratory, pre-specified event-entry hypothesis**, developed after v0.10's negative TRAIN result, retaining previous v0.10 features for reproducibility. All computations are offline. NO real exchange orders or account/network access. Historical simulations do not imply profitability.

Read [EVENT_PROTOCOL.md](EVENT_PROTOCOL.md) before a run. The document freezes a minimal 8-configuration grid and distinguishes already observed April–June 2024 TRAIN from untouched April–June 2025 VALIDATION and July–September 2026 HOLDOUT. Unlike continuous v0.10 signals, the new rules open only on first crossing/breakout events; the 15m signal stream forms exclusively from completed UTC-aligned 1m candles and enters at the following 1m open.

Run in a new virtual environment using `pip install -e '.[test,parity]'` and `pytest -q`. Run **TRAIN only**:

```bash
python -m tpsl_lab.event_study --stage train \
  --data-root /home/kali/research/tpsl-spot-history-v10 \
  --out /home/kali/research/tpsl-results-v011/train_v011.json
```

`--out` must not exist and its parent directory must exist. Monthly public ZIPs and CHECKSUM files must have already been downloaded to the data-root. The module validates SHA-256 of required TRAIN source files and fails closed on gaps/corruption. It refuses all 2026 months and does not support `--stage holdout`. Do not run 2025 VALIDATION without a separate instruction after freezing the training result. No additional optimizer, parameter sweep or retrospective changes permitted.

The original `spot_study` v0.10 remains included for negative-result reproduction only. Freqtrade source/strategy adapter and other prior modules are retained; event_study itself has no Freqtrade dependency and does not run Freqtrade.
