# TP/SL Lab v0.12 — Are our entry signals informative?

This is an **exploratory offline, TRAIN-only** historical information audit following the negative v0.10 and v0.11 strategy tests. It does **not** define a new trading strategy, claim an edge, execute trades, or authorize real-market use.

Added:

- `src/tpsl_lab/entry_edge.py`: diagnostic of the *unchanged* v0.11 EMA crossover and Donchian first-breakout events against same-UTC-day randomized controls.
- `tests/test_entry_edge.py`: 21 new tests (235 total).
- `ENTRY_INFORMATION_PROTOCOL.md`: complete frozen definitions and interpretation limits.

Versions aligned at `0.12.0`. No changes to previous TP/SL execution engine or earlier trade strategies. Prior train, validation and holdout source files are not modified.

## Install / test

```bash
python3.13 -m venv .venv
.venv/bin/python -m pip install -e '.[test,parity]'
.venv/bin/python -m pytest -q
.venv/bin/python -m compileall -q src user_data/strategies
```

## TRAIN only

The following uses only the 2024 Spot monthly ZIPs plus their official `*.CHECKSUM` files already saved by MT:

```bash
mkdir -p /home/kali/research/tpsl-results-v012
.venv/bin/python -m tpsl_lab.entry_edge \
  --stage train \
  --data-root /home/kali/research/tpsl-spot-history-v10 \
  --out /home/kali/research/tpsl-results-v012/entry_information_train_v012.json
```

It produces exactly 24 rows: BTC/ETH × EMA/Donchian event × 1m/15m signal frame × 1h/4h/24h hypothetical forward price window. Same-day random time-matched controls, 32 per event, fixed seed, approximate 7-day block-bootstrap intervals, baseline/stress roundtrip costs. No trade fills, TP/SL, position management, return compounding, or executable orders. Output writes fail closed if path exists.

**Do not run** any validation/holdout. The CLI has *no* validation or holdout stage. Do not open 2025/2026 ZIPs, start backtests, or search for a profitable parameter combination. All results on the reused 2024 training window are exploratory.
