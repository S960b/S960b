"""TRAIN-ONLY exploratory aggressor trade-flow forward-return diagnostic.

Research-only. No fitted parameters, order APIs, trading, optimization, or
access to validation (2025) / holdout (2026). This follows unsuccessful price-
signal studies on the same TRAIN 2024 data; results are NOT independent proof.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import random
import zipfile
from collections import defaultdict
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from pathlib import Path

from .entry_edge import _net_return, _week_bootstrap_mean_ci
from .model import Candle
from .spot_study import (
    SPLITS, SYMBOLS, BASELINE_COST, STRESS_COST,
    read_spot_month, _find_exact,
)

VERSION = '0.13.0'
SCHEMA = 'tpsl-lab/tradeflow-information-exploratory-v1'
HORIZONS = (60, 240)
TIMEFRAMES = (1, 15)
SIDES = ('high_buy', 'high_sell')
LOW_CUTOFF = {1: Decimal('0.20'), 15: Decimal('0.40')}
NEUTRAL_LO = Decimal('0.40')
NEUTRAL_HI = Decimal('0.60')
CONTROLS_PER_EVENT = 16
SEED = 20261110
MIN_EVENTS = 30
MAX_OUTPUT_BYTES = 2_500_000


@dataclass(frozen=True)
class FlowMinute:
    ts: int
    quote: Decimal
    buy_quote: Decimal

    def __post_init__(self):
        if (type(self.ts) is not int or self.ts < 0 or
                not self.quote.is_finite() or self.quote <= 0 or
                not self.buy_quote.is_finite() or self.buy_quote < 0 or
                self.buy_quote > self.quote):
            raise ValueError('invalid non-positive or out-of-bounds aggressor quote volume')

    @property
    def fraction(self) -> Decimal:
        return self.buy_quote / self.quote


def _positive_decimal(raw: str, what: str) -> Decimal:
    try:
        x = Decimal(raw)
    except (InvalidOperation, ValueError) as e:
        raise ValueError(f'invalid decimal: {what}') from e
    if not x.is_finite() or x < 0:
        raise ValueError(f'invalid nonfinite/negative {what}')
    return x


def _read_month(root: Path, symbol: str, month: str) -> tuple[list[Candle], list[FlowMinute], dict]:
    """Validate official SHA, 1m OHLC via the frozen v0.10 loader, then flow.

    Re-hash ZIP before parsing the raw flow columns; never unzip to disk.
    """
    bars, provenance = read_spot_month(root, symbol, month)
    zip_name = provenance['zip_name']
    path = _find_exact(root, zip_name)
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != provenance['zip_sha256']:
        raise ValueError('data archive changed between integrity and flow read')
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        entries = z.infolist()
        if len(entries) != 1 or entries[0].filename != zip_name[:-4]+'.csv':
            raise ValueError('unexpected ZIP members')
        csv_bytes = z.read(entries[0])
    if hashlib.sha256(csv_bytes).hexdigest() != provenance['csv_sha256']:
        raise ValueError('CSV SHA mismatch on flow read')
    items = []
    reader = csv.reader(io.StringIO(csv_bytes.decode('utf8'), newline=''))
    for i, row in enumerate(reader):
        if i >= len(bars) or len(row) != 12:
            raise ValueError('invalid flow CSV row count/width')
        if not row[0].isdecimal() or int(row[0]) != bars[i].ts * 1000:
            raise ValueError('flow timestamp mismatch')
        base = _positive_decimal(row[5], 'base volume')
        quote = _positive_decimal(row[7], 'quote volume')
        buy_base = _positive_decimal(row[9], 'taker buy base')
        buy_quote = _positive_decimal(row[10], 'taker buy quote')
        if (base <= 0 or quote <= 0 or buy_base > base or buy_quote > quote or
                not row[8].isdecimal()):
            raise ValueError('invalid Binance taker/trade volume invariants')
        items.append(FlowMinute(bars[i].ts, quote, buy_quote))
    if len(items) != len(bars):
        raise ValueError('incomplete flow CSV')
    return bars, items, provenance


def load_train(root: Path) -> tuple[dict[str,tuple[list[Candle],list[FlowMinute]]],list[dict]]:
    """Hard-coded to 2024 TRAIN. Cannot load validation or sealed holdout."""
    result = {}
    provenance = []
    for sym in SYMBOLS:
        all_bars, all_flow = [], []
        for month in SPLITS['train']:
            bars, flow, prov = _read_month(root, sym, month)
            if all_bars and (bars[0].ts != all_bars[-1].ts+60 or flow[0].ts != all_flow[-1].ts+60):
                raise ValueError('cross-month gap')
            all_bars.extend(bars)
            all_flow.extend(flow)
            provenance.append(prov)
        result[sym] = (all_bars, all_flow)
    return result, provenance


def grouped_entries(bars: list[Candle], flow: list[FlowMinute], timeframe: int) -> list[tuple[int,Decimal]]:
    """Return (NEXT-open index, completed-bar buy fraction) for eligible bars."""
    if timeframe not in TIMEFRAMES:
        raise ValueError('unregistered timeframe')
    if len(bars) != len(flow) or not bars or bars[0].ts % 86400 != 0:
        raise ValueError('bad input length or UTC boundary')
    for i in range(len(bars)):
        if bars[i].ts != flow[i].ts or (i and bars[i].ts != bars[i-1].ts + 60):
            raise ValueError('gap/mismatch in minute flow')
    if len(bars) % timeframe != 0:
        raise ValueError('incomplete aggregate block')
    result = []
    for k in range(0, len(bars), timeframe):
        if bars[k].ts % (timeframe*60):
            raise ValueError('unaligned aggregate block')
        # None of the future 1m bars beyond this COMPLETED block contributes.
        total_quote = sum((f.quote for f in flow[k:k+timeframe]), Decimal(0))
        total_buy = sum((f.buy_quote for f in flow[k:k+timeframe]), Decimal(0))
        if total_quote <= 0:
            raise ValueError('empty quote volume in aggregate')
        entry = k + timeframe
        if entry < len(bars):
            result.append((entry, total_buy/total_quote))
    return result


def _classify(fraction: Decimal,timeframe: int) -> str:
    if timeframe not in TIMEFRAMES:
        raise ValueError('unregistered timeframe')
    if not fraction.is_finite() or not Decimal(0) <= fraction <= Decimal(1):
        raise ValueError('invalid flow fraction')
    low = LOW_CUTOFF[timeframe]
    if fraction <= low: return 'high_sell'
    if fraction >= 1-low: return 'high_buy'
    if NEUTRAL_LO <= fraction <= NEUTRAL_HI: return 'neutral'
    return 'other'


def _forward(bars: list[Candle], index: int,horizon: int) -> float:
    if horizon not in HORIZONS or index < 1 or index+horizon >= len(bars):
        raise ValueError('outside fixed forward horizon or missing future open')
    return bars[index+horizon].open / bars[index].open - 1.0


def analyze(bars: list[Candle], flow: list[FlowMinute], symbol: str, timeframe: int,
            side: str,horizon: int) -> dict:
    """Compare extremes to same-day neutral flow with frozen random controls.

    The SELL signal is not an executable spot-short trade; signed lift for SELL
    is descriptive price-direction evidence only. 16 same-day neutral controls
    are sampled WITH replacement per event.
    """
    if symbol not in SYMBOLS or timeframe not in TIMEFRAMES or side not in SIDES or horizon not in HORIZONS:
        raise ValueError('outside preregistered diagnostic dimensions')
    entries = grouped_entries(bars,flow,timeframe)
    valid = [(i,cat) for i,f in entries if i+horizon<len(bars)
             for cat in [_classify(f,timeframe)]]
    events = [i for i,cat in valid if cat == side]
    neutrals = defaultdict(list)
    for i,cat in valid:
        if cat == 'neutral':
            neutrals[bars[i].ts//86400].append(i)
    seed = (SEED + 1777*SYMBOLS.index(symbol) + 111*TIMEFRAMES.index(timeframe)
            + 7*SIDES.index(side) + horizon)
    rng = random.Random(seed)
    sign = 1 if side == 'high_buy' else -1
    rows=[]
    no_neutral = 0
    for i in events:
        candidates=neutrals.get(bars[i].ts//86400,[])
        if not candidates:
            no_neutral += 1
            continue
        event_return = _forward(bars,i,horizon)
        control_return = sum(_forward(bars,candidates[rng.randrange(len(candidates))],horizon)
                             for _ in range(CONTROLS_PER_EVENT))/CONTROLS_PER_EVENT
        rows.append((bars[i].ts,event_return,control_return))
    n=len(rows)
    prefix={'symbol':symbol,'timeframe_min':timeframe,'side':side,'horizon_min':horizon,
            'threshold_low':str(LOW_CUTOFF[timeframe]),
            'threshold_high':str(1-LOW_CUTOFF[timeframe]),
            'neutral_fraction_range':[str(NEUTRAL_LO),str(NEUTRAL_HI)],
            'total_extreme_entries':len(events),'eligible_paired_entries':n,
            'skipped_no_same_day_neutral':no_neutral,
            'controls_per_event':CONTROLS_PER_EVENT,'no_orders':True,
            'spot_short_executable':False if side=='high_sell' else None}
    if not rows:
        return {**prefix,'status':'INSUFFICIENT_PAIRED_EVENTS',
                'signed_lift_bps':None,'ci95_lower_bps':None,'ci95_upper_bps':None}
    mean_event=sum(x[1] for x in rows)/n
    mean_control=sum(x[2] for x in rows)/n
    signed = sign*(mean_event-mean_control)
    lo,hi,weeks=_week_bootstrap_mean_ci([(ts,sign*(a-b)) for ts,a,b in rows],bars[0].ts,seed)
    c=BASELINE_COST.taker_fee+BASELINE_COST.slippage
    d=STRESS_COST.taker_fee+STRESS_COST.slippage
    return {**prefix,'active_7day_blocks':weeks,
            'mean_event_forward_bps':round(mean_event*10000,6),
            'mean_same_day_neutral_forward_bps':round(mean_control*10000,6),
            'signed_lift_bps':round(signed*10000,6),
            'ci95_lower_bps':None if lo is None else round(lo*10000,6),
            'ci95_upper_bps':None if hi is None else round(hi*10000,6),
            'event_long_only_baseline_net_bps':round(_net_return(mean_event,BASELINE_COST.taker_fee,BASELINE_COST.slippage)*10000,6) if sign==1 else None,
            'event_long_only_stress_net_bps':round(_net_return(mean_event,STRESS_COST.taker_fee,STRESS_COST.slippage)*10000,6) if sign==1 else None,
            'status':'EXPLORATORY_ONLY' if n>=MIN_EVENTS and lo is not None else 'INSUFFICIENT_EVENTS_OR_WEEKS',
            'multiple_comparisons_uncorrected':True}


def plan() -> dict:
    return {
        'schema':SCHEMA,'stage':'train',
        'train_months':list(SPLITS['train']),
        'symbols':list(SYMBOLS),'timeframes_min':list(TIMEFRAMES),
        'horizons_min':list(HORIZONS),'sides':list(SIDES),
        'cutoffs_by_timeframe':{str(k):str(v) for k,v in LOW_CUTOFF.items()},
        'neutral_control_fraction_bounds':[str(NEUTRAL_LO),str(NEUTRAL_HI)],
        'same_day_neutral_controls_per_event':CONTROLS_PER_EVENT,
        'seed':SEED,'minimum_paired_events':MIN_EVENTS,
        'primary_diagnostic':['BTCUSDT','ETHUSDT','15m high_buy 60m horizon'],
        'no_posthoc_selection':True,'training_reused_after_prior_negative_results':True,
        'validation_unseen':True,'holdout_sealed':True,'no_orders':True,
        'caveats':['extreme flow can be contemporaneously price-correlated; forward returns only measured from next OPEN',
                   'overlapping future windows are not independent trades',
                   'same-day neutral-flow controls are observational, not causal',
                   'sell pressure is a directional diagnostic only; no SPOT short execution',
                   '7-day block bootstrap is approximate with 13 weeks; multiple comparisons uncorrected',
                   '2024 TRAIN reused; results cannot prove out-of-sample alpha',
                   'no brokerage fills, net long is fixed-horizon proxy only, not executable TP/SL PnL']}


def train(root:Path)->dict:
    data,prov=load_train(root)
    rows=[analyze(data[sym][0],data[sym][1],sym,tf,side,h)
          for sym in SYMBOLS for tf in TIMEFRAMES for side in SIDES for h in HORIZONS]
    return {'schema':SCHEMA,'stage':'train','plan':plan(),
            'data_provenance':prov,'results':rows,'validation_unseen':True,
            'holdout_unseen':True,'no_orders':True,
            'conclusion':'EXPLORATORY_INFORMATION_ONLY_NO_STRATEGY_SELECTION'}


def main(argv=None):
    p=argparse.ArgumentParser(description='Offline TRAIN-only aggressor-flow forward-return diagnostic')
    p.add_argument('--stage',required=True,choices=['train'])
    p.add_argument('--data-root',required=True,type=Path)
    p.add_argument('--out',required=True,type=Path)
    args=p.parse_args(argv)
    if args.out.exists() or args.out.is_symlink():raise FileExistsError('refusing overwrite')
    if not args.out.parent.is_dir() or args.out.parent.is_symlink():
        raise ValueError('output parent must exist as a real directory')
    report=train(args.data_root)
    blob=(json.dumps(report,sort_keys=True,indent=2,allow_nan=False)+'\n').encode('utf8')
    if len(blob)>MAX_OUTPUT_BYTES:raise ValueError('report too large')
    with args.out.open('xb') as f:f.write(blob)
    print(json.dumps({'stage':'train','rows':len(report['results']),
                      'sha256':hashlib.sha256(blob).hexdigest(),'out':str(args.out),
                      'validation_unseen':True,'holdout_unseen':True,'no_orders':True}))


if __name__=='__main__':
    main()
