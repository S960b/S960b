"""Regression cases from MT's real Freqtrade 2026.11.dev0 spot acceptance.
No network, exchange, or live execution is required.
"""
from __future__ import annotations
from pathlib import Path
from datetime import datetime, timezone
import json
import sys
import types
import zipfile

import pytest

from tpsl_lab.execution_compare import parse_freqtrade_trades
from tpsl_lab.freqtrade_store_cli import store_checked


def trade():
    return {
        "pair": "BTC/USDT", "is_short": False,
        "open_rate": 67777.0, "close_rate": 68454.0,
        "open_date": "2024-06-02 01:00:00",
        "close_date": "2024-06-02 01:30:00",
        "exit_reason": "roi"
    }


def payload(*, nested=True):
    return {"strategy":{"TpslLabEmaLongOnly":{"trades":[trade()],"total_trades":1} if nested else [trade()]}}


def test_parse_modern_freqtrade_nested_json(tmp_path):
    p = tmp_path / 'result.json'
    p.write_text(json.dumps(payload()))
    ts = int(datetime(2024, 6, 2, 1, tzinfo=timezone.utc).timestamp())
    t = parse_freqtrade_trades(p, strategy='TpslLabEmaLongOnly',pair='BTC/USDT')
    assert len(t)==1 and t[0]['entry_ts']==ts and t[0]['entry_price']==67777


def test_parse_old_freqtrade_flat_list(tmp_path):
    p = tmp_path / 'old.json'
    p.write_text(json.dumps(payload(nested=False)))
    assert len(parse_freqtrade_trades(p,strategy='TpslLabEmaLongOnly',pair='BTC/USDT'))==1


def test_parse_realistic_export_zip_with_config_and_meta(tmp_path):
    p = tmp_path / 'backtest-result-2026-11-10_06-07-49.zip'
    with zipfile.ZipFile(p, 'w') as z:
        z.writestr('backtest-result-2026-11-10_06-07-49.json',json.dumps(payload()))
        z.writestr('backtest-result-2026-11-10_06-07-49_config.json',json.dumps({'strategy':'not the trade list'}))
        z.writestr('backtest-result-2026-11-10_06-07-49.meta.json','{}')
    result = parse_freqtrade_trades(p,strategy='TpslLabEmaLongOnly',pair='BTC/USDT')
    assert len(result)==1


def test_fail_closed_no_trades_key(tmp_path):
    p=tmp_path/'wrong.json';p.write_text(json.dumps({'strategy':{'TpslLabEmaLongOnly':{'total_trades':1}}}))
    with pytest.raises(ValueError,match='not a trade list'):
        parse_freqtrade_trades(p,strategy='TpslLabEmaLongOnly',pair='BTC/USDT')


def test_fail_closed_two_real_results(tmp_path):
    p=tmp_path/'two.zip'
    with zipfile.ZipFile(p, 'w') as z:
        z.writestr('first.json',json.dumps(payload()))
        z.writestr('second.json',json.dumps(payload()))
        z.writestr('first_config.json','{}')
    with pytest.raises(ValueError,match='exactly one'):
        parse_freqtrade_trades(p,strategy='TpslLabEmaLongOnly',pair='BTC/USDT')


def test_config_includes_required_pricing_for_pinned_freqtrade():
    path=Path(__file__).parents[1]/'config/freqtrade-spot-comparison.json'
    cfg=json.loads(path.read_text())
    assert cfg['entry_pricing']['price_side'] in ('other','same')
    assert cfg['exit_pricing']['price_side'] in ('other','same')
    assert cfg['order_types']['stoploss'] == 'market'
    assert cfg['exchange']['key']==cfg['exchange']['secret']==''
    assert cfg['trading_mode']=='spot'
    assert cfg['dry_run'] is True


def test_version_sync():
    import tpsl_lab
    assert tpsl_lab.__version__=='0.9.0'
    assert 'version = "0.9.0"' in (Path(__file__).parents[1]/'pyproject.toml').read_text()


def _make_csv(tmp_path):
    p=tmp_path/'spot.csv'
    p.write_text('timestamp,open,high,low,close,volume\n'
                 '1717200000,100,101,99,100,1\n'
                 '1717200060,100,102,99,101,1\n')
    return p


def test_storage_timestamp_precision_roundtrip(tmp_path,monkeypatch):
    """Emulate pandas us->ms dtype conversion without importing Freqtrade."""
    import pandas as pd
    df = pd.DataFrame({
        'date':pd.to_datetime(['2024-06-01 00:00:00+00:00','2024-06-01 00:01:00+00:00'],utc=True).astype('datetime64[us, UTC]'),
        'open':[100.,100.], 'high':[101.,102.], 'low':[99.,99.],
        'close':[100.,101.], 'volume':[1.,1.]
    })
    class DummyHandler:
        def ohlcv_store(self,pair,timeframe,frame,candle_type):
            self.frame=frame
        def ohlcv_load(self,pair,timeframe,candle_type,fill_missing,drop_incomplete):
            loaded=self.frame.copy()
            loaded['date']=loaded['date'].astype('datetime64[ms, UTC]')
            assert not loaded['date'].equals(self.frame['date'])
            return loaded
    handler=DummyHandler()
    # fake the two import paths consumed only inside store_checked
    freqtrade=types.ModuleType('freqtrade')
    data=types.ModuleType('freqtrade.data')
    history=types.ModuleType('freqtrade.data.history')
    handlers=types.ModuleType('freqtrade.data.history.datahandlers')
    enums=types.ModuleType('freqtrade.enums')
    handlers.get_datahandler=lambda target,fmt: handler
    enums.CandleType=types.SimpleNamespace(SPOT='spot')
    for name,obj in [('freqtrade',freqtrade),('freqtrade.data',data),('freqtrade.data.history',history),('freqtrade.data.history.datahandlers',handlers),('freqtrade.enums',enums)]:
        monkeypatch.setitem(sys.modules,name,obj)
    p=_make_csv(tmp_path)
    report=store_checked(p,tmp_path/'newtarget')
    assert report['roundtrip']=='VERIFIED'


def test_storage_rejects_timestamp_value_change(tmp_path,monkeypatch):
    import pandas as pd
    class DummyHandler:
        def ohlcv_store(self,pair,timeframe,frame,candle_type):self.frame=frame
        def ohlcv_load(self,pair,timeframe,candle_type,fill_missing,drop_incomplete):
            loaded=self.frame.copy()
            loaded['date']=loaded['date'].astype('datetime64[ms, UTC]') + pd.Timedelta(seconds=1)
            return loaded
    handler=DummyHandler()
    freqtrade=types.ModuleType('freqtrade');data=types.ModuleType('freqtrade.data')
    history=types.ModuleType('freqtrade.data.history')
    handlers=types.ModuleType('freqtrade.data.history.datahandlers');enums=types.ModuleType('freqtrade.enums')
    handlers.get_datahandler=lambda target,fmt:handler
    enums.CandleType=types.SimpleNamespace(SPOT='spot')
    for name,obj in [('freqtrade',freqtrade),('freqtrade.data',data),('freqtrade.data.history',history),('freqtrade.data.history.datahandlers',handlers),('freqtrade.enums',enums)]:
        monkeypatch.setitem(sys.modules,name,obj)
    with pytest.raises(RuntimeError,match='timestamp roundtrip differs'):
        store_checked(_make_csv(tmp_path),tmp_path/'differenttarget')
