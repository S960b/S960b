"""OPTIONAL Freqtrade adapter. RESEARCH ONLY.

This is *not* an execution-fidelity equivalence: Freqtrade fill semantics differ
from the conservative mark-price liquidation/funding proxy in tpsl_lab.futures.
Never run this class with live/dry-run exchange credentials. Offline backtests
only, with a local historical dataset and separate test environment.
"""
from freqtrade.strategy import IStrategy
from pandas import DataFrame
from tpsl_lab.entry_signals import dataframe_signals


class TpslLabEmaParity(IStrategy):
    INTERFACE_VERSION = 3
    timeframe = '1m'
    can_short = True
    startup_candle_count = 200
    minimal_roi = {'0': 0.01}
    stoploss = -0.005
    trailing_stop = False
    use_exit_signal = False
    process_only_new_candles = True

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # Signals computed on completed close, never shifted into past.
        dataframe['lab_signal'] = dataframe_signals(dataframe, 'ema', fast=50, slow=200)
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[dataframe['lab_signal'] == 1, 'enter_long'] = 1
        dataframe.loc[dataframe['lab_signal'] == -1, 'enter_short'] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['exit_long'] = 0
        dataframe['exit_short'] = 0
        return dataframe


class TpslLabDonchianParity(TpslLabEmaParity):
    startup_candle_count = 20

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['lab_signal'] = dataframe_signals(dataframe,'donchian',lookback=20)
        return dataframe
