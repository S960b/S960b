# TP/SL Lab v0.13.0 — TRAIN-only aggressor trade-flow information study

This release adds `src/tpsl_lab/tradeflow_edge.py`, `tests/test_tradeflow_edge.py` and the frozen `TRADEFLOW_PROTOCOL.md` on top of v0.12. **The old EMA, Donchian, Freqtrade, execution, NEWS, and trade logic are unchanged.** This is an exploratory measurement of executed aggressor buy volume, NOT a TP/SL trading strategy.

Read `TRADEFLOW_PROTOCOL.md` **before running**. It defines the same-day neutral controls, two timeframes, two horizons, two directions, fixed costs, bootstrap limitations and primary question. The inputs are the original checksum-audited monthly BTCUSDT/ETHUSDT Spot ZIPs from April–June 2024 only. No new downloads. No live or paper orders, API keys, 2025 validation, or 2026 holdout.

Local test installation (fresh Python 3.13 environment):

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -e '.[test,parity]'
.venv/bin/python -m pytest -q
.venv/bin/python -m compileall -q src user_data/strategies
```

Expected in developer environment: **265 passed**. On MT's Kali environment use `env -u APPDIR -u APPIMAGE /usr/bin/python3.13 -m venv .venv` for a clean venv.

**Only allowed market-data command (TRAIN):**

```bash
mkdir -p /home/kali/research/tpsl-results-v013
.venv/bin/python -m tpsl_lab.tradeflow_edge \
  --stage train \
  --data-root /home/kali/research/tpsl-spot-history-v10 \
  --out /home/kali/research/tpsl-results-v013/tradeflow_train_v013.json
```

The pre-existing data root must contain exactly one official `.zip` and `.zip.CHECKSUM` for each requested symbol/month. Raw `open_time`, quote and taker-buy quote volumes are checked against the archived file, with no filling or interpolation. The diagnostic has **16 descriptive rows**. A sell-pressure row never creates an executable Spot short. No capital allocation, PnL aggregation, optimization or trading decision.

Archive integrity is mandatory: release SHA256 is specified in the external `experiments/tpsl-lab/v0.13/MANIFEST.md`, and MT must compare archive SHA, file counts, official month CHECKSUM and final output SHA. No overwrites; create new directories; do not change earlier versions or NEWS services.
