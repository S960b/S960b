"""Synthetic invariants for frozen, TRAIN-only aggressor-flow diagnostic."""
import csv
import hashlib
import io
import zipfile
from decimal import Decimal
from pathlib import Path
import pytest
from tpsl_lab.model import Candle
from tpsl_lab import tradeflow_edge as t


def series(n=3600, f=lambda i:Decimal('0.5')):
    bars=[Candle(60*i,100,100,100,100,1) for i in range(n)]
    flow=[t.FlowMinute(60*i,Decimal('100'),Decimal('100')*f(i)) for i in range(n)]
    return bars, flow


def test_plan_sealed_fixed_dimensions():
    p=t.plan()
    assert p['stage']=='train' and p['holdout_sealed'] and p['validation_unseen']
    assert p['timeframes_min']==[1,15] and p['horizons_min']==[60,240]
    assert p['primary_diagnostic']==['BTCUSDT','ETHUSDT','15m high_buy 60m horizon']


def test_kline_no_short_allowed():
    assert 'high_sell' in t.SIDES
    b,f=series(f=lambda i:Decimal('0.18') if i%30==0 else Decimal('0.5'))
    out=t.analyze(b,f,'BTCUSDT',1,'high_sell',60)
    assert out['spot_short_executable'] is False
    assert 'event_long_only_baseline_net_bps' not in out or out['event_long_only_baseline_net_bps'] is None


def test_flow_quote_validation():
    with pytest.raises(ValueError): t.FlowMinute(0,Decimal('0'),Decimal('0'))
    with pytest.raises(ValueError): t.FlowMinute(0,Decimal('100'),Decimal('101'))
    with pytest.raises(ValueError): t.FlowMinute(0,Decimal('NaN'),Decimal('1'))
    with pytest.raises(ValueError): t.FlowMinute(0,Decimal('Infinity'),Decimal('1'))
    with pytest.raises(ValueError): t.FlowMinute(0,Decimal('100'),Decimal('-0.1'))


def test_decimal_field_parser():
    assert t._positive_decimal('0.000000000000001','quantity')==Decimal('0.000000000000001')
    for v in ['NaN','Infinity','-1','foo']:
        with pytest.raises(ValueError):t._positive_decimal(v,'quantity')


def test_classify_thresholds_inclusive():
    assert t._classify(Decimal('0.2'),1)=='high_sell'
    assert t._classify(Decimal('0.8'),1)=='high_buy'
    assert t._classify(Decimal('0.4'),15)=='high_sell'
    assert t._classify(Decimal('0.6'),15)=='high_buy'
    assert t._classify(Decimal('0.5'),1)=='neutral'
    assert t._classify(Decimal('0.5'),15)=='neutral'
    assert t._classify(Decimal('0.3'),1)=='other'


def test_classify_invalid_fraction():
    for v in [Decimal('-0.01'), Decimal('1.1'),Decimal('NaN')]:
        with pytest.raises(ValueError):t._classify(v,1)


def test_next_open_1m():
    b,f=series(n=1600,f=lambda i:Decimal('0.9') if i==3 else Decimal('0.5'))
    items=t.grouped_entries(b,f,1)
    assert items[3]==(4,Decimal('0.9'))
    assert len(items)==1599


def test_15m_uses_quote_weighted_fraction_not_average_of_fractions():
    b,f=series(1500)
    for j in range(15):
        f[j]=t.FlowMinute(b[j].ts,Decimal('90') if j==0 else Decimal('1'),
                          Decimal('90') if j==0 else Decimal('0'))
    items=t.grouped_entries(b,f,15)
    assert items[0]==(15,Decimal('90')/Decimal('104'))


def test_15m_completed_block_no_future_leak():
    b,f=series(1500)
    f[14]=t.FlowMinute(f[14].ts,Decimal('100'),Decimal('95'))
    first=t.grouped_entries(b,f,15)[0]
    changed=f[:]
    changed[15]=t.FlowMinute(f[15].ts,Decimal('999999'),Decimal('1'))
    assert first==t.grouped_entries(b,changed,15)[0]
    assert first[0]==15


def test_15m_no_first_14_entries():
    b,f=series(1500)
    assert t.grouped_entries(b,f,15)[0][0]==15
    assert all(i%15==0 for i,_ in t.grouped_entries(b,f,15))


def test_missing_bar_detected():
    b,f=series(1500)
    b[123]=Candle(60*124,100,100,100,100,1)
    with pytest.raises(ValueError,match='gap/mismatch'):t.grouped_entries(b,f,15)


def test_timestamp_alignment_detected():
    b,f=series(1500)
    b=[Candle(x.ts+60,x.open,x.high,x.low,x.close,1) for x in b]
    f=[t.FlowMinute(x.ts+60,x.quote,x.buy_quote) for x in f]
    with pytest.raises(ValueError,match='UTC boundary'):t.grouped_entries(b,f,15)


def test_length_detected():
    b,f=series(1500)
    with pytest.raises(ValueError):t.grouped_entries(b,f[:-1],15)


def test_incomplete_15m_block_detected():
    b,f=series(1501)
    with pytest.raises(ValueError,match='incomplete'):t.grouped_entries(b,f,15)


def test_frozen_params_reject():
    b,f=series()
    for params in [('ADAUSDT',1,'high_buy',60),('BTCUSDT',5,'high_buy',60),('BTCUSDT',1,'other',60),('BTCUSDT',1,'high_buy',30)]:
        with pytest.raises(ValueError,match='outside preregistered'):t.analyze(b,f,*params)


def test_future_returns_at_fixed_open_not_high():
    b,f=series()
    b[61]=Candle(b[61].ts,100,130,50,100,1)
    assert t._forward(b,1,60)==0
    with pytest.raises(ValueError):t._forward(b,len(b)-60,60)
    with pytest.raises(ValueError):t._forward(b,1,12)


def test_neutral_controls_same_day_deterministic():
    b,f=series(n=5*1440, f=lambda i:Decimal('.9') if i%12==0 else Decimal('.5'))
    a=t.analyze(b,f,'BTCUSDT',1,'high_buy',60)
    assert a==t.analyze(b,f,'BTCUSDT',1,'high_buy',60)
    assert a['eligible_paired_entries']>0
    assert a['signed_lift_bps']==0 and a['controls_per_event']==16


def test_no_same_day_neutrals_explicit_skip():
    b,f=series(n=5*1440,f=lambda i:Decimal('0.9'))
    a=t.analyze(b,f,'BTCUSDT',1,'high_buy',60)
    assert a['eligible_paired_entries']==0 and a['skipped_no_same_day_neutral']>0
    assert a['status']=='INSUFFICIENT_PAIRED_EVENTS'


def test_price_perturbation_future_changes_return_not_flow_label():
    b,f=series(n=5*1440, f=lambda i:Decimal('.9') if i%20==0 else Decimal('.5'))
    a=t.grouped_entries(b,f,1)
    b[100]=Candle(b[100].ts,110,110,110,110,1)
    assert a==t.grouped_entries(b,f,1)
    assert t._forward(b,40,60)==pytest.approx(.1)


def test_sell_direction_sign_flipped():
    b,f=series(n=5*1440,f=lambda i:Decimal('.1') if i%20==0 else Decimal('.5'))
    a=t.analyze(b,f,'ETHUSDT',1,'high_sell',60)
    assert a['eligible_paired_entries']>0
    assert a['signed_lift_bps']==0
    assert a['event_long_only_baseline_net_bps'] is None


def test_primary_independent_of_horizon_other_groups():
    p=t.plan();assert '15m high_buy 60m horizon' in p['primary_diagnostic']
    assert p['no_posthoc_selection'] and p['training_reused_after_prior_negative_results']


def test_cli_validation_rejected_before_reading_data(tmp_path):
    with pytest.raises(SystemExit):t.main(['--stage','validation','--data-root',str(tmp_path), '--out',str(tmp_path/'x.json')])


def test_cli_holdout_rejected_before_reading_data(tmp_path):
    with pytest.raises(SystemExit):t.main(['--stage','holdout','--data-root',str(tmp_path), '--out',str(tmp_path/'x.json')])


def test_cli_overwrite_rejected_before_reading_data(tmp_path):
    f=tmp_path/'result.json';f.write_text('preserve')
    with pytest.raises(FileExistsError):t.main(['--stage','train','--data-root',str(tmp_path), '--out',str(f)])
    assert f.read_text()=='preserve'


def test_non_existing_output_parent_rejected_before_data(tmp_path):
    with pytest.raises(ValueError,match='output parent'):t.main(['--stage','train','--data-root',str(tmp_path), '--out',str(tmp_path/'x'/'y.json')])


def _raw_fixture_csv(rows, amount='45', buy='30', count='12'):
    return ('\n'.join(','.join([str(i*60000),'100','101','99','100','1',str(i*60000+59999),amount,count,'0.5',buy,'0'])
                    for i in range(rows))+'\n').encode()


def _mock_read_month(monkeypatch,tmp_path,payload):
    import tpsl_lab.tradeflow_edge as m
    fn='BTCUSDT-1m-2024-04.zip'
    filename=tmp_path/fn
    with zipfile.ZipFile(filename,'w',compression=zipfile.ZIP_DEFLATED) as z:
        z.writestr(fn[:-4]+'.csv',payload)
    candles=[Candle(i*60,100,101,99,100,1) for i in range(len(payload.splitlines()))]
    prov={'zip_name':fn,'zip_sha256':hashlib.sha256(filename.read_bytes()).hexdigest(),
          'csv_sha256':hashlib.sha256(payload).hexdigest()}
    monkeypatch.setattr(m,'read_spot_month',lambda root,symbol,month:(candles,prov))
    monkeypatch.setattr(m,'_find_exact',lambda root,name:filename)
    return filename


def test_flow_archive_columns_and_timestamp(monkeypatch,tmp_path):
    b=_raw_fixture_csv(3)
    _mock_read_month(monkeypatch,tmp_path,b)
    bars,flow,prov=t._read_month(tmp_path,'BTCUSDT','2024-04')
    assert len(flow)==len(bars)==3
    assert flow[0].quote==Decimal('45') and flow[0].buy_quote==Decimal('30')
    assert flow[1].ts==60


def test_flow_archive_rejects_overbuy(monkeypatch,tmp_path):
    _mock_read_month(monkeypatch,tmp_path,_raw_fixture_csv(2,amount='15',buy='16'))
    with pytest.raises(ValueError,match='volume invariants'):t._read_month(tmp_path,'BTCUSDT','2024-04')


def test_flow_archive_rejects_invalid_trade_count(monkeypatch,tmp_path):
    _mock_read_month(monkeypatch,tmp_path,_raw_fixture_csv(2,count='12.5'))
    with pytest.raises(ValueError,match='volume invariants'):t._read_month(tmp_path,'BTCUSDT','2024-04')


def test_flow_archive_detects_tamper_after_ohlc_integrity(monkeypatch,tmp_path):
    fn=_mock_read_month(monkeypatch,tmp_path,_raw_fixture_csv(3))
    with fn.open('ab') as fh:fh.write(b'FORGED')
    with pytest.raises(ValueError,match='changed between integrity'):t._read_month(tmp_path,'BTCUSDT','2024-04')


def test_flow_archive_rejects_zero_quote(monkeypatch,tmp_path):
    _mock_read_month(monkeypatch,tmp_path,_raw_fixture_csv(2,amount='0',buy='0'))
    with pytest.raises(ValueError,match='volume invariants'):t._read_month(tmp_path,'BTCUSDT','2024-04')
