"""CLI for validating downloaded funding history. NO network operations."""
import argparse
import json
from .funding_pages import audit_funding_pages


def main(argv=None):
    p = argparse.ArgumentParser(description='Offline page-by-page Binance funding history audit')
    p.add_argument('--manifest', required=True)
    p.add_argument('--export-events')
    p.add_argument('--export-audit')
    args = p.parse_args(argv)
    print(json.dumps(audit_funding_pages(args.manifest, args.export_events,
                                         args.export_audit), indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
