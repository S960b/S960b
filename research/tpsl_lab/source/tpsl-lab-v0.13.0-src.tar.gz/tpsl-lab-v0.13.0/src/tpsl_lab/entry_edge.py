"""TRAIN-ONLY offline entry information diagnostic (NOT a TP/SL strategy).

Post-hoc exploratory research prompted by failed v0.10/v0.11 training outcomes.
Never exposes validation (2025) or holdout (2026). Only local, checksum-validated
monthly Spot BTC/ETH files are read. No orders, HTTP, API, optimization or PnL.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import random
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path

from .event_study import TimeframeSignal, RULES, TIMEFRAMES
from .model import Candle
from .spot_study import load_split, SYMBOLS, BASELINE_COST, STRESS_COST

VERSION = '0.12.0'
SCHEMA = 'tpsl-lab/entry-information-diagnostic-v1'
HORIZONS = (60, 240, 1440)  # 1h/4h/24h, after next-open entry
CONTROLS_PER_EVENT = 32
BOOTSTRAP_REPS = 500
SEED = 20261110
WEEK_SECONDS = 7 * 86400
MIN_ESTIMATION_WEEKS = 5
MAX_OUTPUT_BYTES = 3_000_000


def plan() -> dict:
    return {
        'schema': SCHEMA,
        'research_kind': 'post-hoc exploratory signal-information diagnostic; not TP/SL optimization',
        'source_train_months': ['2024-04', '2024-05', '2024-06'],
        'symbols': list(SYMBOLS), 'rules': list(RULES),
        'signal_timeframes_minutes': list(TIMEFRAMES),
        'holding_horizons_minutes': list(HORIZONS),
        'entry': 'first OPEN after the completed signal candle',
        'exit': 'OPEN exactly H complete one-minute bars after entry',
        'same_day_controls': CONTROLS_PER_EVENT,
        'control_matching': 'same UTC entry day, identical timeframe completion phase, exclude any event entry for this rule/timeframe',
        'benchmark': 'within-day uniform random eligible entry OPEN; common trading costs cancel only in paired relative lift',
        'uncertainty': f'{BOOTSTRAP_REPS} deterministic resamples of UTC 7-day blocks; approximate CI, not proof',
        'fixed_seed': SEED,
        'baseline_cost_per_side': {'fee': BASELINE_COST.taker_fee, 'slippage': BASELINE_COST.slippage},
        'stress_cost_per_side': {'fee': STRESS_COST.taker_fee, 'slippage': STRESS_COST.slippage},
        'no_signal_selection_or_trading_decision': True,
        'validation_unseen': True, 'holdout_sealed': True, 'no_orders': True,
        'caveat': '2024 TRAIN reused after inspecting negative strategies; never infer out-of-sample predictive ability from this report',
    }


def _require_continuous(bars: list[Candle]):
    if len(bars) < max(HORIZONS)+2:
        raise ValueError('insufficient history')
    if bars[0].ts % 86400 != 0:
        raise ValueError('input must start at UTC day boundary')
    for i in range(1,len(bars)):
        if bars[i].ts != bars[i-1].ts + 60:
            raise ValueError('missing or duplicate 1m candle')


def event_entry_indices(bars: list[Candle],rule: str,tf: int) -> list[int]:
    if rule not in RULES or tf not in TIMEFRAMES:
        raise ValueError('event rule/timeframe not preregistered')
    _require_continuous(bars)
    signal = TimeframeSignal(rule,tf)
    entries=[]
    for i,bar in enumerate(bars):
        fired=signal.on_close(bar)
        if fired:
            if i+1<len(bars):
                entries.append(i+1)
    if len(entries)!=len(set(entries)) or any(bars[j].ts % (tf*60) != 0 for j in entries):
        raise ValueError('event alignment or duplication failure')
    return entries


def gross_return(bars: list[Candle],entry_idx: int,horizon: int) -> float:
    if horizon not in HORIZONS:
        raise ValueError('outside fixed horizons')
    if entry_idx<1 or entry_idx+horizon>=len(bars):
        raise ValueError('no complete forward window')
    return bars[entry_idx+horizon].open / bars[entry_idx].open - 1.0


def _net_return(gross: float,fee: float,slippage: float) -> float:
    """Fixed notional SPOT proxy (not margin/broker execution)."""
    c=fee+slippage
    if not 0 <= c < 0.1:
        raise ValueError('invalid cost')
    return (1+gross)*(1-c)/(1+c)-1


def _week_bootstrap_mean_ci(lifts:list[tuple[int,float]],start_ts:int,seed:int)->tuple[float|None,float|None,int]:
    if not lifts:
        return None,None,0
    groups={}
    for ts,ret in lifts:
        k=(ts-start_ts)//WEEK_SECONDS
        groups.setdefault(k,[]).append(ret)
    keys=sorted(groups)
    if len(keys)<MIN_ESTIMATION_WEEKS:
        return None,None,len(keys)
    rng=random.Random(seed)
    boot=[]
    for _ in range(BOOTSTRAP_REPS):
        sampled=[groups[keys[rng.randrange(len(keys))]] for _ in keys]
        total=sum(sum(x) for x in sampled)
        count=sum(len(x) for x in sampled)
        boot.append(total/count)
    boot.sort()
    return boot[int(.025*(len(boot)-1))],boot[int(.975*(len(boot)-1))],len(keys)


def diagnose(bars:list[Candle],rule:str,tf:int,horizon:int,symbol:str) -> dict:
    if symbol not in SYMBOLS or rule not in RULES or tf not in TIMEFRAMES or horizon not in HORIZONS:
        raise ValueError('outside frozen diagnostic parameters')
    _require_continuous(bars)
    event_entries=event_entry_indices(bars,rule,tf)
    eligible=[j for j in event_entries if j+horizon<len(bars)]
    event_set=set(event_entries)
    by_day=defaultdict(list)
    for j in range(1,len(bars)-horizon):
        if bars[j].ts%(tf*60)==0 and j not in event_set:
            by_day[bars[j].ts//86400].append(j)
    rng=random.Random(SEED + 7*SYMBOLS.index(symbol)+31*RULES.index(rule)+211*TIMEFRAMES.index(tf)+1099*HORIZONS.index(horizon))
    rows=[]
    for j in eligible:
        pool=by_day.get(bars[j].ts//86400,[])
        if not pool:raise ValueError('no eligible matching time controls in day')
        er=gross_return(bars,j,horizon)
        mean_random=sum(gross_return(bars,pool[rng.randrange(len(pool))],horizon) for _ in range(CONTROLS_PER_EVENT))/CONTROLS_PER_EVENT
        rows.append((bars[j].ts,er,mean_random))
    if not rows:
        return {'symbol':symbol,'rule':rule,'timeframe_min':tf,'horizon_min':horizon,
                'event_entries_total':len(event_entries),'event_entries_eligible':0,
                'status':'INSUFFICIENT_EVENTS', 'no_orders':True}
    n=len(rows)
    mean_event=sum(x[1] for x in rows)/n
    mean_random=sum(x[2] for x in rows)/n
    mean_lift=mean_event-mean_random
    ci_lo,ci_hi,weeks=_week_bootstrap_mean_ci([(ts,er-rr) for ts,er,rr in rows],bars[0].ts,seed=SEED+131*n+tf+horizon+SYMBOLS.index(symbol))
    bas=BASELINE_COST.taker_fee+BASELINE_COST.slippage
    stress=STRESS_COST.taker_fee+STRESS_COST.slippage
    return {
        'symbol':symbol,'rule':rule,'timeframe_min':tf,'horizon_min':horizon,
        'event_entries_total':len(event_entries), 'event_entries_eligible':n,
        'events_skipped_insufficient_future':len(event_entries)-n,
        'events_first_10_entry_utc_seconds':[x[0] for x in rows[:10]],
        'mean_gross_event_bps':round(mean_event*10000,6),
        'mean_gross_same_day_control_bps':round(mean_random*10000,6),
        'mean_event_minus_control_bps':round(mean_lift*10000,6),
        'event_net_baseline_bps':round(_net_return(mean_event,BASELINE_COST.taker_fee,BASELINE_COST.slippage)*10000,6),
        'event_net_stress_bps':round(_net_return(mean_event,STRESS_COST.taker_fee,STRESS_COST.slippage)*10000,6),
        'control_net_baseline_bps':round(_net_return(mean_random,BASELINE_COST.taker_fee,BASELINE_COST.slippage)*10000,6),
        'control_net_stress_bps':round(_net_return(mean_random,STRESS_COST.taker_fee,STRESS_COST.slippage)*10000,6),
        'lift_bootstrap_ci95_lower_bps':None if ci_lo is None else round(ci_lo*10000,6),
        'lift_bootstrap_ci95_upper_bps':None if ci_hi is None else round(ci_hi*10000,6),
        'bootstrap_7day_blocks':weeks,
        'controls_per_event':CONTROLS_PER_EVENT,
        'status':'EXPLORATORY_ONLY' if ci_lo is not None else 'TOO_FEW_ACTIVE_WEEKS',
        'no_orders':True,
    }


def train(root:Path)->dict:
    candles,prov=load_split(root,'train')
    return {'schema':SCHEMA,'stage':'train','plan':plan(),
            'data_provenance':prov,
            'rows':[diagnose(candles[sym],rule,tf,h,sym)
                    for sym in SYMBOLS for rule in RULES for tf in TIMEFRAMES for h in HORIZONS],
            'validation_unseen':True,'holdout_unseen':True,
            'no_orders':True,
            'conclusion':'EXPLORATORY_DATA_ONLY_NO_SELECTION; do not run validation or holdout based on this result'}


def main(argv=None):
    p=argparse.ArgumentParser(description='Offline TRAIN-only event information diagnostic')
    p.add_argument('--stage',choices=['train'],required=True)
    p.add_argument('--data-root',type=Path,required=True)
    p.add_argument('--out',type=Path,required=True)
    a=p.parse_args(argv)
    if a.out.exists() or a.out.is_symlink():
        raise FileExistsError('refusing overwrite')
    if not a.out.parent.is_dir() or a.out.parent.is_symlink():
        raise ValueError('output parent must already exist and be real')
    report=train(a.data_root)
    data=(json.dumps(report,indent=2,sort_keys=True,allow_nan=False)+'\n').encode('utf8')
    if len(data)>MAX_OUTPUT_BYTES:raise ValueError('report too large')
    with a.out.open('xb') as fh:fh.write(data)
    print(json.dumps({'stage':'train','rows':len(report['rows']),
                      'sha256':hashlib.sha256(data).hexdigest(),
                      'output':str(a.out),'validation_unseen':True,'holdout_unseen':True,
                      'no_orders':True}))


if __name__=='__main__':
    main()
