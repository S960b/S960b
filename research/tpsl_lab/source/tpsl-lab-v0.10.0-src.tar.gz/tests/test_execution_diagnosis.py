"""Offline diagnostic assertions: no fabricated causal explanation for Freqtrade fills."""
from __future__ import annotations
import csv
import json
from pathlib import Path

import pytest

from tpsl_lab.model import Candle
from tpsl_lab.execution_diagnosis import diagnose, diagnose_files, SCHEMA
from tpsl_lab.execution_diagnosis_cli import main


START = 1717200000


def candles(n=8, lows=None, highs=None):
    lows = lows or {}
    highs = highs or {}
    return [Candle(START+60*i, 100., highs.get(i, 101.), lows.get(i, 99.8), 100., 10.) for i in range(n)]


def trade(*, entry_i=1, exit_i=3, reason='stop', exit_price=99.5):
    return {'entry_ts': START+60*entry_i,'exit_ts':START+60*exit_i,
            'direction':1,'entry_price':100.,'exit_price':exit_price,'exit_reason':reason}


def reference(trades, n=8):
    return {'schema':'tpsl-lab/execution-reference-v1','bars':n,'first_ts':START,
            'last_ts':START+(n-1)*60,'csv_sha256':'a'*64,
            'strategy_kind':'ema','settings':{'sl_pct':.005},
            'reference':{'trades':trades}}


def check(ref, ft, bars=None, **kw):
    return diagnose(ref, ft, bars or candles(), ft_sha256='b'*64,
                    strategy='EMA',pair='BTC/USDT',**kw)


def test_same_exit_prices_and_times_omitted():
    t=trade(); r=check(reference([t]),[dict(t)])
    assert r['schema']==SCHEMA and r['reason_count']=={'MATCHED_IDENTICAL':1}
    assert r['cases_total']==0 and not r['live_orders']


def test_stop_timing_unresolved_and_level_evidence():
    a=trade(exit_i=2);f=trade(exit_i=4,reason='stop_loss')
    r=check(reference([a]),[f],candles(lows={2:99.4,4:99.3}))
    c=r['cases'][0]
    assert c['type']=='STOP_TIMING_UNRESOLVED'
    assert c['first_reference_stop_touch_ts']==START+120
    assert c['reference_stop_level']==pytest.approx(99.5)
    assert c['exit_delta_seconds']==120
    assert c['freqtrade_stop_level']=='UNKNOWN_FROM_EXPORT'
    assert c['explanation_status']=='EVIDENCE_ONLY_NOT_CAUSAL_PROOF'
    assert any(x['ts']==START+120 and x['low']==99.4 for x in c['ohlc_witness'])


def test_roi_vs_target_not_declared_bugs():
    a=trade(exit_price=101.,reason='target');f=trade(exit_i=4,exit_price=101.1,reason='roi')
    c=check(reference([a]),[f])['cases'][0]
    assert c['type']=='ROI_TARGET_SEMANTICS_NEED_RECONCILIATION'


def test_reason_family_change_flags():
    r=check(reference([trade(reason='stop')]),[trade(reason='roi')]);
    assert r['cases'][0]['type']=='EXIT_REASON_FAMILY_MISMATCH'


def test_same_family_price_change_distinguished():
    r=check(reference([trade()]),[trade(exit_price=99.6,reason='stop_loss')]);
    assert r['cases'][0]['type']=='MATCHED_EXECUTION_DIFFERENCE'
    assert r['cases'][0]['exit_delta_bps']>0


def test_unmatched_positions_not_automatically_explained():
    a=trade(entry_i=1);b=trade(entry_i=2)
    r=check(reference([a]),[b])
    assert r['reason_count']=={'FREQTRADE_ONLY':1,'REFERENCE_ONLY':1}
    assert r['cases_total']==2 and all('UNRESOLVED' in c['explanation_status'] for c in r['cases'])


def test_evidence_limit_sets_truncated():
    a=trade(entry_i=1);b=trade(entry_i=2);c=trade(entry_i=3)
    r=check(reference([a,b,c]),[],max_evidence=1)
    assert r['cases_total']==3 and r['cases_included']==1 and r['evidence_truncated']


def test_reject_invalid_max_evidence():
    with pytest.raises(ValueError,match='max_evidence'):
        check(reference([]),[],max_evidence=0)


def test_reject_bad_schema():
    r=reference([]);r['schema']='bad'
    with pytest.raises(ValueError,match='schema'):
        check(r,[])


def test_reject_gaps():
    b=candles();b[2]=Candle(b[2].ts+60,100,101,99,100,10)
    with pytest.raises(ValueError,match='continuous'):
        check(reference([]),[],b)


def test_reject_duplicate_trade_keys():
    with pytest.raises(ValueError,match='duplicate'):
        check(reference([trade(),trade()]),[])
    with pytest.raises(ValueError,match='duplicate'):
        check(reference([]),[trade(),trade()])


def test_stop_touch_no_touch_returns_null():
    b=candles(lows={i:99.8 for i in range(8)})
    c=check(reference([trade(exit_i=2)]),[trade(exit_i=3,reason='stop_loss')],b)['cases'][0]
    assert c['first_reference_stop_touch_ts'] is None


def test_output_contains_unchanged_reference_comparison_counts():
    a=trade(); f=trade(exit_i=4,reason='stop_loss')
    r=check(reference([a]),[f])
    assert r['compare']['matched_entry_direction']==1
    assert r['compare']['only_reference']==0
    assert r['compare']['exit_time_mismatches']==1
    assert 'sample' not in r['compare']


def csv_fixture(tmp_path:Path,n=240):
    p=tmp_path/'spot.csv'
    with p.open('w') as f:
        w=csv.writer(f);w.writerow(['timestamp','open','high','low','close','volume'])
        for i in range(n):
            close=100+i*.03
            w.writerow([START+i*60,close,close*1.001,close*.999,close,10])
    return p


def test_offline_cli_json_and_overwrite(tmp_path):
    p=csv_fixture(tmp_path);data=tmp_path/'ft.json';data.write_text(json.dumps({'strategy':{'EMA':{'trades':[]}}}))
    out=tmp_path/'diagnostics.json'
    args=['--csv',str(p),'--ft-export',str(data),'--kind','ema',
          '--ft-strategy','EMA','--ft-pair','BTC/USDT','--long-only',
          '--freqtrade-commit','f'*40,'--out',str(out)]
    assert main(args)==0
    doc=json.loads(out.read_text())
    assert doc['status']=='POSTMORTEM_DIAGNOSTIC_NOT_TRADE_PARITY'
    assert doc['freqtrade_commit']=='f'*40 and doc['bars']==240
    assert not doc['live_orders']
    with pytest.raises(SystemExit):main(args)


def test_cli_reject_bad_commit(tmp_path):
    with pytest.raises(SystemExit):
        main(['--csv',str(tmp_path/'missing'),'--ft-export',str(tmp_path/'missing'),
              '--kind','ema','--ft-strategy','EMA','--freqtrade-commit','not-a-sha',
              '--out',str(tmp_path/'x.json')])


def test_reference_witness_capped_at_sixteen():
    a=trade(entry_i=1,exit_i=4);f=trade(entry_i=1,exit_i=7,reason='stop_loss')
    r=check(reference([a],n=30),[f],candles(30))
    assert len(r['cases'][0]['ohlc_witness']) <= 16
