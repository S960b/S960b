"""RESEARCH-ONLY Freqtrade SPOT-execution fixture for comparison.

1m, long only, no live orders, no keys. This strategy is ONLY for local
backtests on publicly downloaded SPOT BTC/USDT historical candles. It does not
represent Binance USD-M futures funding or short execution. Signals are taken
at candle close and Freqtrade considers entry on the next candle.
"""
from freqtrade.strategy import IStrategy
from pandas import DataFrame
from tpsl_lab.entry_signals import dataframe_signals


class TpslLabEmaLongOnly(IStrategy):
    INTERFACE_VERSION = 3
    timeframe = '1m'
    can_short = False
    startup_candle_count = 200
    minimal_roi = {'0': .01}
    stoploss = -.005
    trailing_stop = False
    use_exit_signal = False
    process_only_new_candles = True

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['lab_signal'] = dataframe_signals(dataframe, 'ema', fast=50, slow=200)
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[dataframe['lab_signal'] == 1, 'enter_long'] = 1
        dataframe['enter_short'] = 0
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['exit_long'] = 0
        dataframe['exit_short'] = 0
        return dataframe


class TpslLabDonchianLongOnly(TpslLabEmaLongOnly):
    startup_candle_count = 20

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['lab_signal'] = dataframe_signals(dataframe,'donchian',lookback=20)
        return dataframe
