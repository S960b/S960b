import pytest
from tpsl_lab.io import _timestamp, read_csv


def test_timestamp_milliseconds_and_microseconds():
    assert _timestamp('1704067200000') == 1704067200
    assert _timestamp('1704067200000000') == 1704067200
    assert _timestamp('2024-01-01T00:00:00Z') == 1704067200


def test_reject_naive_timestamp():
    with pytest.raises(ValueError):
        _timestamp('2024-01-01T00:00:00')


def test_normalized_csv(tmp_path):
    p = tmp_path / 'a.csv'
    p.write_text('timestamp,open,high,low,close,volume\n2024-01-01T00:00:00Z,100,101,99,100,12\n')
    rows = read_csv(p)
    assert rows[0].ts == 1704067200
    assert rows[0].volume == 12


def test_binance_csv(tmp_path):
    p = tmp_path / 'b.csv'
    p.write_text('1704067200000000,100,101,99,100,12,1704067259999999,1,1,1,1,0\n')
    rows = read_csv(p, binance=True)
    assert len(rows) == 1
    assert rows[0].ts == 1704067200
