"""Offline funding/tier loaders. Never contacts an API or sends orders."""
import json
from pathlib import Path
from .futures import FundingEvent, FundingTape, MarginTier


def read_binance_funding(path: str | Path, coverage_start: int, coverage_end: int) -> FundingTape:
    records = json.loads(Path(path).read_text(encoding='utf-8'))
    if not isinstance(records, list):
        raise ValueError('funding JSON must be a list of fapi history records')
    events = []
    for row in records:
        # Official endpoint stores fundingTime in milliseconds and markPrice
        ms = int(row['fundingTime'])
        if ms % 1000 != 0:
            raise ValueError('subsecond funding timestamp cannot be ordered using 1s candles')
        events.append(FundingEvent(ms//1000, float(row['fundingRate']), float(row['markPrice'])))
    return FundingTape(tuple(events), coverage_start, coverage_end,
                       f'binance-fapi-funding-history:file={Path(path).name};unverified_completeness')


def read_tiers(path: str | Path) -> tuple[MarginTier, ...]:
    payload = json.loads(Path(path).read_text(encoding='utf-8'))
    if payload.get('mode') != 'scenario' or not isinstance(payload.get('tiers'), list):
        raise ValueError('tier file must explicitly declare mode=scenario')
    rows = payload['tiers']
    return tuple(MarginTier(float(r['floor']), float(r['cap']),
                            float(r['maintenance_rate']), float(r['maintenance_amount']),
                            float(r['max_leverage'])) for r in rows)
