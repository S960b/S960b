# TP/SL Lab v0.4 - offline dataset audit + funding timestamp integrity

Research-only release retaining v0.3 functionality and adding multi-day historical data validation. **No order APIs, no API keys, no network requests in package code, no trading.** Base v0.1 replay remains unchanged. v0.2 scenario-margin and liquidation proxy remain intentionally non-Binance-exact.

## Motivation and fix

MT independently observed BTCUSDT fundingTime `1717257600001` at 2024-06-01 16:00:00.001 UTC. v0.2 rejected this record because it had `ms % 1000 != 0`. v0.3 preserves the **exact millisecond timestamp** (FundingEvent.ts_ms) and uses its full-second bucket to associate settlement with the proper 1-minute bar **without losing milliseconds**.

- Only an event at a known candle opening *within the first 999ms* may be replayed. Other intrabar events fail closed, and multiple settlements in one candle are rejected.
- If a position definitely exits at bar open before a +1ms funding event, funding is not charged.
- If order between funding and intrabar exit is unknown, possible debits are charged and uncertain credits suppressed (pessimistic, not actual exchange billing).
- For an entry at an exact-second funding boundary, uncertain credits remain suppressed. For delayed +1ms funding, a position opened at bar open can receive funding credit **only if the position is held for the entire candle**.
- Binance API fundingRate endTime is inclusive. A record **exactly** at the half-open replay period's end is excluded and counted in funding_source; other out-of-range events raise an error.
- `--symbol BTCUSDT` / `--symbol ETHUSDT` checks every funding row's symbol.
- `funding_timestamps_ms` and `funding_events_count` now appear in the report. Declared coverage is **not proof of completeness**. The 00:00/08:00/16:00 cadence from one day must never be assumed universal.

This remains an OHLC **conservative proxy**, not verified maker/taker fills or liquidation settlement. Funding timing and stop/target/mark liquidation inside a minute are not known precisely; results are not safe to use to rank live leveraged trading strategies.

## Installation and regression tests

Extract `tpsl-lab-v0.4.0-src.tar.gz` into a new isolated directory, check archive SHA-256 from release manifest, and run:

```bash
env -u APPDIR -u APPIMAGE /usr/bin/python3.13 -m venv .venv
.venv/bin/python -m pip install -e '.[test]'
.venv/bin/python -m pytest -q
.venv/bin/python -m compileall -q src
```

For the real 2024-06-01 one-day experiment, use BOTH trade and mark-price 1m historical CSVs from `data.binance.vision` and GET funding history from Binance **public, read-only** endpoint `/fapi/v1/fundingRate`. Keep raw JSON unchanged, including +1ms events, and save the UTC range, SHA-256 and provenance. Avoid private keys. The API may return the 2024-06-02 00:00 event because its `endTime` is inclusive; the v0.3 loader excludes that exact boundary with an audit count. Use `--symbol BTCUSDT`.

Example run **only when the agent has independently verified complete source files**, using a copy of the scenario tier fixture (NOT historical Binance tier evidence):

```bash
.venv/bin/python -m tpsl_lab.futures_cli \
  --price-csv /path/to/BTCUSDT-1m-2024-06-01.csv \
  --mark-csv /path/to/BTCUSDT-mark-1m-2024-06-01.csv \
  --funding-json /path/to/BTCUSDT-funding-2024-06-01.json \
  --tiers-json examples/scenario_tiers.json --symbol BTCUSDT --binance \
  --strategy random --seed 7 --probability 0.02 --leverage 2 \
  --out reports/binance-2024-06-01-diagnostic.json
```

**Do not interpret PnL as historical Binance futures performance**, due to scenario brackets, one-day period, insufficient microstructure, and conservative liquidation/funding order assumptions. If files or completeness cannot be verified, report blocker without substituting synthetic data.

## References

- https://developers.binance.com/docs/derivatives/usds-margined-futures/market-data/rest-api/Get-Funding-Rate-History
- https://www.binance.com/en/support/faq/detail/b3c689c1f50a44cabb3a84e663b81d93
- https://github.com/binance/binance-public-data

## MT acceptance

Read-only execution on a fresh isolated directory; verify checksum and paths, test 57 cases, prove raw +1ms is retained in the record and ledger, test +/- funding with stop-gap at OPEN, compare 43 historical v0.2 behaviour cases, try one-day public-data diagnostic with trade/mark/funding, and report divergences or unsupported claims. Do not change NEWS, existing service and taskboard, main branch, old venv, or perform any live/testnet/paper trade.

## v0.4: offline multi-day 1m dataset audit (NEW)

This release adds `tpsl_lab.dataset_cli` for strict local validation of
publicly downloaded Binance USD-M **daily** `klines` and `markPriceKlines`.
It performs **no downloads, API calls, order placement or strategy search**.
Each day's trade and mark inputs must be named `BTCUSDT-1m-YYYY-MM-DD.zip`
(or `.csv`) in separate directories, or use `ETHUSDT` consistently.
Each Binance archive must contain one flat 12-column CSV file.

Checks: one exact UTC day, 1440 rows, contiguous 60-second intervals,
exact aligned milliseconds or microseconds (never silently rounded),
valid Candle prices, 1:1 trade/mark timestamps, no missing or duplicate days,
unsafe ZIP names, compressed/decompressed size limits, SHA-256 of both original
files and CSV payloads, strict funding symbol, and half-open period bounds.
Funding timestamps are preserved in milliseconds; a funding event at the
exclusive end boundary is excluded with the count documented.

Example for a ONE-DAY AUDIT (after MT downloads these inputs and funding JSON):

```sh
python -m tpsl_lab.dataset_cli \
  --trade-dir /home/kali/research/tpsl-data/BTCUSDT/trade \
  --mark-dir /home/kali/research/tpsl-data/BTCUSDT/mark \
  --funding-json /home/kali/research/tpsl-data/BTCUSDT/funding_2024-06-01.json \
  --symbol BTCUSDT --start-date 2024-06-01 --days 1 \
  --export-dir /home/kali/research/tpsl-data/BTCUSDT/export_2024-06-01
```

Seven days: put one daily trade/mark ZIP per date in the respective
folders, use `--days 7` and a JSON containing ALL historical events in the
window, then use a NEW export folder. An existing export folder is never
replaced. Two normalized CSVs plus `audit.json` will be generated on success.
The resulting CSVs can feed `tpsl_lab.futures_cli` **without** `--binance`,
using the same funding JSON and explicit *scenario* margin tiers.

IMPORTANT: the auditor verifies structural and timestamp integrity, not the
truthfulness, provenance or completeness of the data source. A SHA-256 hash
records local bytes, not Binance authenticity. `funding.completeness=NOT_PROVEN`
remains mandatory because endpoint pagination and possible gaps must be checked
independently. It cannot certify Binance liquidation fills, funding settlement
priority, order book, or historical maintenance margin. This version is strictly
for diagnostic replay, not leveraged strategy ranking or paper/live orders.

`__version__` and `pyproject.toml` are synchronized at 0.4.0.
