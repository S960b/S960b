# TP/SL Lab v0.8.1 — Freqtrade real-backtest compatibility hotfix

**Offline research only. No real/demo/testnet/paper orders, no exchange API, no keys.** This is a targeted repair based on MT's v0.8 real Freqtrade run on BTC/USDT SPOT June 1–7 2024. It does **not** change strategy algorithms, our reference fill model, Freqtrade ROI or exit semantics, and it does **not** claim execution parity.

## Four resolved issues (retest on real pinned Freqtrade required)

1. Storage roundtrip: compare timestamps as UTC nanosecond epoch integers rather than requiring identical pandas datetime resolution. A changed instant must still FAIL.
2. Backtest config: include explicit `entry_pricing`, `exit_pricing`, and `order_types` required by the pinned Freqtrade development build. This is a keyless, offline backtest-only config, not a trading configuration.
3. Freqtrade ZIP selection: ignore auxiliary `*_config.json` and `.meta.json` while rejecting archives with zero or multiple primary results JSON files.
4. Freqtrade schema: support `strategy[name]` as either legacy trade list or modern stats mapping with `trades` list, with strict rejection of unknown shapes.

Regression suite: 155 tests (146 existing, 9 new); two new timestamp-precision cases use a local mock handler, NOT actual Freqtrade. Actual Freqtrade verification is MT's responsibility.

## MT retest priority

Use the exact previous Freqtrade Git SHA `227997806986013fb6544d9253429855c603ca97` and existing audited SPOT candles (`spot_1m.csv`, SHA-256 `aab77a75ce23c3ef7c29d33eb28f40f1fd887181c4cb6884130d2f11d454ae84`) and **original** unchanged backtest ZIP from v0.8. Create new v0.8.1 working directory and new outputs. First run all 155 tests. Then the real `freqtrade_store_cli` with a *new* empty datadir. Then run `execution_compare_cli` against the original ZIP, not an extracted manually modified JSON. Require successful parse and report discrepancies faithfully. Finally, if initial checks pass, optionally run one new Freqtrade `backtesting` command with the new explicit config and compare that separately; record all CLI args, config checksum and Freqtrade SHA.

Do not infer that 15 entry matches or 14 exit price mismatches are all explained by one particular mechanic; inspect individual events and label unexplained differences. Remember the reference and Freqtrade use different warmup eligibility, ROI math, fees and intrabar/gap assumptions. MT must not alter strategy parameters to force agreement. Without equivalent initial conditions and execution models, differences are expected but require explanation.

---

# TP/SL Lab v0.8 — first execution comparison (offline SPOT baseline)

**Research only, no real or paper orders.** Source: v0.7 reference + independent Freqtrade execution diagnostics. **This is a technical engine comparison, not a study of profitability.** The original USD-M futures proxy, mark/funding auditors and EMA/Donchian signal comparisons remain available and unchanged.

## What is implemented by ChatGPT

- `execution_compare.py`: replays *locked candle-close signals* using the audited reference engine (Long/Short, or explicitly `long_only`), records fees/prices/times and trades; validates and reads Freqtrade `--export trades` JSON or ZIP **only from local files**; matches trades by entry timestamp+direction, reports missing trades, price differences in basis points, exit-time deltas, reason-family differences. No requirement that different execution models produce identical outcomes.
- `execution_compare_cli.py`: offline CLI; `--ft-export` optional. Without it reports `REFERENCE_ONLY_NOT_EXECUTION_PARITY`. Refuses to overwrite reports.
- `spot_dataset_cli.py`: validates daily official SPOT BTCUSDT 1m ZIPs for 1440 bars/day, UTC continuity, archive/CSV SHA256, no gaps; exports a **new** normalized CSV and audit JSON. The raw ZIP inputs MUST come from the Binance `data/spot/` archive, not from USD-M futures. Never downloads automatically.
- `freqtrade_store_cli.py`: with an actual installed Freqtrade, writes previously audited SPOT candles into a **new** isolated JSON data directory using the Freqtrade data-handler and reads them back to verify count, timestamps, prices; no exchange/bot objects, no network calls and no overwrites.
- `user_data/strategies/TpslLabExecutionLongOnly.py`: isolated Freqtrade SPOT Long-only EMA and Donchian adapters (1m, TP/ROI 1%, stop 0.5%); no Short, leverage, funding or liquidation.
- `config/freqtrade-spot-comparison.json`: deliberately keyless, isolated backtesting-only template; do not use it for live or dry-run operation.

**Why SPOT first?** A simple Long-only backtest removes funding and mark-liquidation differences, which would obscure the initial execution comparison. We need to learn Freqtrade's fill/ROI semantics on exactly the same SPOT candles before attempting futures reconciliation.

## Independent MT acceptance recipe

1. Get this release at exact pinned SHA; verify SHA-256 and safe archive paths; install in **new** venv, run all unit tests. Keep Freqtrade pinned to actual Git commit `227997806986013fb6544d9253429855c603ca97` if still installed and compatible, or report real version plus SHA. Do not change the old v0.7 venv, NEWS, Hermes services, Taskboard or Git main.
2. Public READ ONLY: from the official SPOT archive, fetch BTCUSDT **spot** 1m daily klines for **2024-06-01..2024-06-07**, 7 separate ZIP files, e.g. `https://data.binance.vision/data/spot/daily/klines/BTCUSDT/1m/BTCUSDT-1m-2024-06-01.zip`. Save URLs, hashes, time range. Do NOT reuse USD-M futures trade bars under a spot label. Download to a new empty input folder, check raw checksums. If any day is missing/corrupt, STOP rather than filling gaps.
3. From the new v0.8 source and Freqtrade venv:

```bash
python -m tpsl_lab.spot_dataset_cli --input-dir NEW_SPOT_DAILY_DIR --start-date 2024-06-01 --days 7 --export-dir NEW_SPOT_AUDIT_EXPORT_DIR
python -m tpsl_lab.freqtrade_store_cli --csv NEW_SPOT_AUDIT_EXPORT_DIR/spot_1m.csv --datadir NEW_EMPTY_FT_DATA_DIR --out NEW_FT_STORE_AUDIT.json
python -m tpsl_lab.execution_compare_cli --csv NEW_SPOT_AUDIT_EXPORT_DIR/spot_1m.csv --kind ema --long-only --fee 0.0005 --slippage 0 --out NEW_EMA_REFERENCE.json
python -m tpsl_lab.execution_compare_cli --csv NEW_SPOT_AUDIT_EXPORT_DIR/spot_1m.csv --kind donchian --long-only --fee 0.0005 --slippage 0 --out NEW_DONCHIAN_REFERENCE.json
```

4. Only if spot CSV and `freqtrade_store_cli` roundtrip are valid, run one constrained **Freqtrade BACKTEST** (never `trade` or `webserver`!) with a new config copy, new Freqtrade results directory and zero credentials. Example **adapt to exact pinned CLI after checking `freqtrade backtesting --help`**:

```bash
freqtrade backtesting --config config/freqtrade-spot-comparison.json \
  --datadir NEW_FT_DATA_DIR --data-format-ohlcv json \
  --strategy-path user_data/strategies --strategy TpslLabEmaLongOnly \
  --timerange 20240601T0400-20240608 --fee 0.0005 \
  --stake-amount 100 --dry-run-wallet 1000 --max-open-trades 1 \
  --export trades --backtest-directory NEW_FT_RESULTS_DIR --cache none
```

The provided 04:00 UTC warmup cutoff allows >200 candles before the comparison start. Do not infer Freqtrade shares exactly the reference model's entry eligibility at the cutoff. Real Freqtrade may query public market metadata; if its commands require unsafe network capabilities, credentials or unexpected app changes, STOP and report rather than bypassing protections.

5. After a real `--export trades` ZIP exists, use the comparator, with the actual output filename:

```bash
python -m tpsl_lab.execution_compare_cli --csv NEW_SPOT_AUDIT_EXPORT_DIR/spot_1m.csv \
  --kind ema --long-only --fee 0.0005 --slippage 0 \
  --ft-export REAL_BACKTEST_EXPORT.zip --ft-strategy TpslLabEmaLongOnly \
  --ft-pair BTC/USDT --out NEW_EMA_COMPARISON.json
```

If this phase succeeds, optionally run the same Donchian long-only backtest and comparison. **DO NOT change or tailor the source to force agreement**. Record actual entries, exits, matched/unmatched counts and first 30 material discrepancies. This initial compare uses the same raw bar series but **does not impose identical starting/warmup eligibility**; first-window mismatches may be caused by warmup. Do not present aggregate PnL as an edge.

## Limits still in force

- Freqtrade's ROI exit is fee/time-aware and not mathematically identical to our simple price TP; stop-gap and same-bar pricing may differ. Differences are expected and should be classified.
- The reference engine is non-levered with no funding, no mark-price liquidation and no order book. The v0.3 futures risk model remains only a stress proxy, **not Binance-matched**.
- Freqtrade installation is a development build pinned by commit; its precise backtest command/JSON export format may differ. If the parser rejects an unknown format, report it rather than silently guessing fields.
- Offline 7-day 1m backtesting is a **technical compatibility test** only, not a statistically credible estimate of future profits. No parameter tuning, no real/testnet/paper trade operations, no trading services.

---

## Previous v0.7 notes

# TP/SL Lab v0.7 — isolated real-Freqtrade adapter compatibility

**Research-only, offline, no trading orders or credentials.**

New optional CLI `python -m tpsl_lab.freqtrade_runtime_cli --csv /path/to/trade_1m.csv --out /new/report.json` checks `populate_indicators`, `populate_entry_trend` and `populate_exit_trend` against the installed **real** Freqtrade `IStrategy`. It demands a separately installed Freqtrade distribution, checks class inheritance and input signal columns, and compares every EMA50/200 and Donchian20 signal to the independent streaming signal generator. The CLI does **not** start a Freqtrade bot or backtester, and it must never receive exchange credentials. An import stub is only used in our own unit tests.

This test is **NOT execution parity**. Binance funding/margin/liquidation and fee-fill semantics remain approximations from the v0.3 proxy. Freqtrade fills are not checked here. No claim of profitable strategy or suitable live trading.

## MT instructions

Use a **new** virtual environment (`/home/kali/research/tpsl-lab-v07-ft`), not existing NEWS or previous tpsl venvs. Fetch an isolated Freqtrade stable release per official documentation, pin and record installed Git SHA/version, preferably with its supported Python version and no privileged system changes. If unavailable or incompatible, report exact dependency failure and do not install into existing environments. No bot start, live/dry/testnet trading, exchange keys, API, download-data or background services.

Run all project tests (`python -m pytest -q`), compileall, then import the actual `freqtrade.strategy.IStrategy` and run the offline adapter check with the *previously downloaded and hashed* BTCUSDT seven-day trade_1m.csv. Save separate reports. Require mismatch=0 for both adapters; otherwise return minimal divergence. If real Freqtrade cannot install, this stage is **blocked**, not marked successful by a stub.

## Prior baseline

# TP/SL Lab v0.6 — Freqtrade-compatible signal parity (OFFLINE)

New: streaming ↔ pandas signal parity checks (EMA50/200, Donchian20),
optional Freqtrade IStrategy adapter, deterministic diagnostics. **No orders,
API credentials, network client or profit claim.** For integration details see
the v0.6 section at the end of this README. All v0.5 funding audit features
and tests remain available.

---

# TP/SL Lab v0.5 — funding history page audit (OFFLINE)

Research-only. No HTTP, no account keys and no order endpoints. This release retains the unmodified v0.4 core engines and all earlier synthetic tests; it adds a strict OFFLINE validator for funding-rate history downloaded from Binance USD-M GET /fapi/v1/fundingRate.

## New in 0.5

- Checks each raw response page against a SHA-256 entry in a JSON query manifest.
- Checks that inclusive `(startTime,endTime)` query windows tile the requested UTC period without holes or overlapping milliseconds.
- Rejects responses reaching their requested `limit` (API truncation may have occurred); split that time window and fetch again.
- Rejects duplicate, unsorted, wrong-symbol or out-of-range funding events, malformed rates, unsafe page paths and export overwrites.
- Records exact exchange timestamps, per-day counts, >12-hour observed gaps, and any end-boundary settlement excluded from the replay.
- Exports original records to a v0.4-compatible JSON list and a separate audit JSON.
- IMPORTANT: request-window coverage does NOT prove Binance returned every actual exchange funding event. Long gaps are warnings, not proof; funding cadence is not assumed to be constant.

### Manifest for an already-downloaded seven-day page

For BTCUSDT 2024-06-01 through 2024-06-07 inclusive, if the raw JSON was fetched with `endTime=1717804800000` (inclusive), create a separate manifest beside the saved JSON file:

```json
{
  "schema": "tpsl-lab/funding-pages-v1",
  "symbol": "BTCUSDT",
  "start_ms": 1717200000000,
  "end_exclusive_ms": 1717804800000,
  "pages": [
    {
      "start_ms": 1717200000000,
      "end_ms": 1717804800000,
      "limit": 1000,
      "file": "funding_2024-06-01_07.json",
      "sha256": "<actual raw SHA-256 from sha256sum>"
    }
  ]
}
```

The placeholder sha256 must be replaced with the actual checksum of that local file. The page might contain a settlement at 2024-06-08 00:00; the validator excludes that event from the half-open backtest period. Multiple pages must use contiguous, non-overlapping query windows: next start_ms = previous end_ms + 1.

```bash
PYTHONPATH=src python -m pytest -q
PYTHONPATH=src python -m tpsl_lab.funding_audit_cli \
  --manifest /path/to/funding-pages.json \
  --export-events /new/directory/funding_events_clean.json \
  --export-audit /new/directory/funding_pages_audit.json
```

Never overwrite an existing result. Outputs should be new files within an existing folder. The original raw pages are left untouched. Do not claim `exchange_event_completeness` is proven; it is always `NOT_PROVEN` until independent exchange-side verification is possible.

---

## Previous v0.4 documentation

# TP/SL Lab v0.4 - offline dataset audit + funding timestamp integrity

Research-only release retaining v0.3 functionality and adding multi-day historical data validation. **No order APIs, no API keys, no network requests in package code, no trading.** Base v0.1 replay remains unchanged. v0.2 scenario-margin and liquidation proxy remain intentionally non-Binance-exact.

## Motivation and fix

MT independently observed BTCUSDT fundingTime `1717257600001` at 2024-06-01 16:00:00.001 UTC. v0.2 rejected this record because it had `ms % 1000 != 0`. v0.3 preserves the **exact millisecond timestamp** (FundingEvent.ts_ms) and uses its full-second bucket to associate settlement with the proper 1-minute bar **without losing milliseconds**.

- Only an event at a known candle opening *within the first 999ms* may be replayed. Other intrabar events fail closed, and multiple settlements in one candle are rejected.
- If a position definitely exits at bar open before a +1ms funding event, funding is not charged.
- If order between funding and intrabar exit is unknown, possible debits are charged and uncertain credits suppressed (pessimistic, not actual exchange billing).
- For an entry at an exact-second funding boundary, uncertain credits remain suppressed. For delayed +1ms funding, a position opened at bar open can receive funding credit **only if the position is held for the entire candle**.
- Binance API fundingRate endTime is inclusive. A record **exactly** at the half-open replay period's end is excluded and counted in funding_source; other out-of-range events raise an error.
- `--symbol BTCUSDT` / `--symbol ETHUSDT` checks every funding row's symbol.
- `funding_timestamps_ms` and `funding_events_count` now appear in the report. Declared coverage is **not proof of completeness**. The 00:00/08:00/16:00 cadence from one day must never be assumed universal.

This remains an OHLC **conservative proxy**, not verified maker/taker fills or liquidation settlement. Funding timing and stop/target/mark liquidation inside a minute are not known precisely; results are not safe to use to rank live leveraged trading strategies.

## Installation and regression tests

Extract `tpsl-lab-v0.4.0-src.tar.gz` into a new isolated directory, check archive SHA-256 from release manifest, and run:

```bash
env -u APPDIR -u APPIMAGE /usr/bin/python3.13 -m venv .venv
.venv/bin/python -m pip install -e '.[test]'
.venv/bin/python -m pytest -q
.venv/bin/python -m compileall -q src
```

For the real 2024-06-01 one-day experiment, use BOTH trade and mark-price 1m historical CSVs from `data.binance.vision` and GET funding history from Binance **public, read-only** endpoint `/fapi/v1/fundingRate`. Keep raw JSON unchanged, including +1ms events, and save the UTC range, SHA-256 and provenance. Avoid private keys. The API may return the 2024-06-02 00:00 event because its `endTime` is inclusive; the v0.3 loader excludes that exact boundary with an audit count. Use `--symbol BTCUSDT`.

Example run **only when the agent has independently verified complete source files**, using a copy of the scenario tier fixture (NOT historical Binance tier evidence):

```bash
.venv/bin/python -m tpsl_lab.futures_cli \
  --price-csv /path/to/BTCUSDT-1m-2024-06-01.csv \
  --mark-csv /path/to/BTCUSDT-mark-1m-2024-06-01.csv \
  --funding-json /path/to/BTCUSDT-funding-2024-06-01.json \
  --tiers-json examples/scenario_tiers.json --symbol BTCUSDT --binance \
  --strategy random --seed 7 --probability 0.02 --leverage 2 \
  --out reports/binance-2024-06-01-diagnostic.json
```

**Do not interpret PnL as historical Binance futures performance**, due to scenario brackets, one-day period, insufficient microstructure, and conservative liquidation/funding order assumptions. If files or completeness cannot be verified, report blocker without substituting synthetic data.

## References

- https://developers.binance.com/docs/derivatives/usds-margined-futures/market-data/rest-api/Get-Funding-Rate-History
- https://www.binance.com/en/support/faq/detail/b3c689c1f50a44cabb3a84e663b81d93
- https://github.com/binance/binance-public-data

## MT acceptance

Read-only execution on a fresh isolated directory; verify checksum and paths, test 57 cases, prove raw +1ms is retained in the record and ledger, test +/- funding with stop-gap at OPEN, compare 43 historical v0.2 behaviour cases, try one-day public-data diagnostic with trade/mark/funding, and report divergences or unsupported claims. Do not change NEWS, existing service and taskboard, main branch, old venv, or perform any live/testnet/paper trade.

## v0.4: offline multi-day 1m dataset audit (NEW)

This release adds `tpsl_lab.dataset_cli` for strict local validation of
publicly downloaded Binance USD-M **daily** `klines` and `markPriceKlines`.
It performs **no downloads, API calls, order placement or strategy search**.
Each day's trade and mark inputs must be named `BTCUSDT-1m-YYYY-MM-DD.zip`
(or `.csv`) in separate directories, or use `ETHUSDT` consistently.
Each Binance archive must contain one flat 12-column CSV file.

Checks: one exact UTC day, 1440 rows, contiguous 60-second intervals,
exact aligned milliseconds or microseconds (never silently rounded),
valid Candle prices, 1:1 trade/mark timestamps, no missing or duplicate days,
unsafe ZIP names, compressed/decompressed size limits, SHA-256 of both original
files and CSV payloads, strict funding symbol, and half-open period bounds.
Funding timestamps are preserved in milliseconds; a funding event at the
exclusive end boundary is excluded with the count documented.

Example for a ONE-DAY AUDIT (after MT downloads these inputs and funding JSON):

```sh
python -m tpsl_lab.dataset_cli \
  --trade-dir /home/kali/research/tpsl-data/BTCUSDT/trade \
  --mark-dir /home/kali/research/tpsl-data/BTCUSDT/mark \
  --funding-json /home/kali/research/tpsl-data/BTCUSDT/funding_2024-06-01.json \
  --symbol BTCUSDT --start-date 2024-06-01 --days 1 \
  --export-dir /home/kali/research/tpsl-data/BTCUSDT/export_2024-06-01
```

Seven days: put one daily trade/mark ZIP per date in the respective
folders, use `--days 7` and a JSON containing ALL historical events in the
window, then use a NEW export folder. An existing export folder is never
replaced. Two normalized CSVs plus `audit.json` will be generated on success.
The resulting CSVs can feed `tpsl_lab.futures_cli` **without** `--binance`,
using the same funding JSON and explicit *scenario* margin tiers.

IMPORTANT: the auditor verifies structural and timestamp integrity, not the
truthfulness, provenance or completeness of the data source. A SHA-256 hash
records local bytes, not Binance authenticity. `funding.completeness=NOT_PROVEN`
remains mandatory because endpoint pagination and possible gaps must be checked
independently. It cannot certify Binance liquidation fills, funding settlement
priority, order book, or historical maintenance margin. This version is strictly
for diagnostic replay, not leveraged strategy ranking or paper/live orders.

`__version__` and `pyproject.toml` are synchronized at 0.4.0.

## v0.6: Freqtrade-compatible signal parity (offline, no orders)

v0.6 introduces two independent *signal calculations* for EMA50/200 and
Donchian20: a single-candle streaming implementation and a pandas/DataFrame
implementation used by the optional Freqtrade IStrategy adapter.
They must agree **on every completed candle**. The EMA initialization is
identical (`ewm(..., adjust=False)`); Donchian uses *previous* 20 highs/lows,
never current candle extrema. Both can generate long and short signals.

The adapter at `user_data/strategies/TpslLabSignalParity.py` imports Freqtrade
and therefore is intentionally *not* loaded by core pytest. Its framework
`populate_indicators/populate_entry_trend/populate_exit_trend` shapes follow
Freqtrade's documentation. It is **not** a live/dry-run approved strategy.

Install pandas only in an ISOLATED parity environment (not an existing NEWS venv):

```sh
python -m pip install -e '.[test,parity]'
python -m pytest -q
python -m tpsl_lab.parity_cli --csv /path/to/trade_1m.csv --strategy ema --out /new/parity_ema.json
python -m tpsl_lab.parity_cli --csv /path/to/trade_1m.csv --strategy donchian --out /new/parity_donchian.json
```

Use prior audited 10080-row BTCUSDT data; report mismatch counts and first
mismatch with UTC timestamps. Successful signal parity **does not** prove
Freqtrade fill/fee/funding parity; actual Freqtrade installation and full
backtest comparison is a *separate next acceptance stage*.

No strategy profitability claims are authorized. Funding completeness is still
NOT_PROVEN; liquidation is still a conservative proxy. The research will
require multi-year walk-forward and genuinely unseen forward testing.
