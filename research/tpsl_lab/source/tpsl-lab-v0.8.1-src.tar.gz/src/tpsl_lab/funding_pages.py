"""Offline, fail-closed validation of externally fetched Binance funding pages.

No HTTP, credentials, order endpoints, or claim of exchange-side completeness.
The manifest documents *exact* inclusive startTime/endTime windows from GET
/fapi/v1/fundingRate and SHA-256 of every raw response. Windows must tile the
requested backtest interval without gaps or overlapping request times.
"""
from __future__ import annotations

import hashlib
import json
import math
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

MAX_RAW_BYTES = 10_000_000
MAX_PAGES = 10000
LIMIT_MAX = 1000


def _integer(value: object, name: str) -> int:
    if type(value) is not int:
        raise ValueError(f'{name} must be an integer')
    return value


def _resolve_page(root: Path, value: object) -> Path:
    if not isinstance(value, str) or not value or Path(value).is_absolute():
        raise ValueError('page path must be a relative file')
    full = (root / value).resolve(strict=True)
    if not full.is_relative_to(root):
        raise ValueError('page path escapes manifest directory')
    if not full.is_file():
        raise ValueError('page path is not a file')
    return full


def _timestamp_ms(row: dict) -> int:
    raw = row.get('fundingTime')
    if type(raw) is int:
        return raw
    if isinstance(raw, str) and raw.isdecimal():
        return int(raw)
    raise ValueError('fundingTime must be integer milliseconds')


def _number(row: dict, key: str) -> float:
    try:
        x = float(row[key])
    except (KeyError, ValueError, TypeError) as exc:
        raise ValueError(f'invalid {key}') from exc
    if not math.isfinite(x):
        raise ValueError(f'nonfinite {key}')
    return x


def audit_funding_pages(manifest: str | Path, export_events: str | Path | None = None,
                        export_audit: str | Path | None = None) -> dict:
    """Validate ordered raw pages and optionally export original JSON records.

    All response windows are inclusive. The final response may include an event
    at end_exclusive_ms; that one event is not used for the replay. Page counts
    must be < requested limit, otherwise truncation cannot be excluded.

    Neither tiled query windows nor fewer-than-limit responses prove the API
    returned every historical exchange event; warn about unexplained large gaps.
    """
    manifest = Path(manifest).resolve(strict=True)
    root = manifest.parent
    if not manifest.is_file() or manifest.stat().st_size > MAX_RAW_BYTES:
        raise ValueError('missing or oversized manifest')
    data = json.loads(manifest.read_text(encoding='utf-8'))
    if not isinstance(data, dict) or data.get('schema') != 'tpsl-lab/funding-pages-v1':
        raise ValueError('invalid funding-page manifest schema')
    symbol = data.get('symbol')
    if symbol not in ('BTCUSDT','ETHUSDT'):
        raise ValueError('unsupported funding symbol')
    start = _integer(data.get('start_ms'), 'start_ms')
    end = _integer(data.get('end_exclusive_ms'), 'end_exclusive_ms')
    if start < 0 or end <= start or start % 60000 or end % 60000:
        raise ValueError('bad UTC coverage boundaries')
    pages = data.get('pages')
    if not isinstance(pages, list) or not 1 <= len(pages) <= MAX_PAGES:
        raise ValueError('missing or excessive page list')

    expected_start = start
    all_rows: list[dict] = []
    all_times: list[int] = []
    page_audit = []
    boundary_excluded = 0
    for i, p in enumerate(pages):
        if not isinstance(p, dict):
            raise ValueError('page metadata must be object')
        lo = _integer(p.get('start_ms'), 'page start_ms')
        hi = _integer(p.get('end_ms'), 'page end_ms')
        limit = _integer(p.get('limit'), 'page limit')
        if lo != expected_start or hi < lo or hi > end or not 1 <= limit <= LIMIT_MAX:
            raise ValueError('noncontiguous, overlapping or invalid funding query windows')
        if hi == end and i != len(pages) - 1:
            raise ValueError('end-boundary-inclusive query permitted only on last page')
        expected_start = hi + 1
        source = _resolve_page(root, p.get('file'))
        raw = source.read_bytes()
        if len(raw) > MAX_RAW_BYTES:
            raise ValueError('funding response too large')
        digest = hashlib.sha256(raw).hexdigest()
        declared_sha = p.get('sha256')
        if not isinstance(declared_sha, str) or len(declared_sha) != 64 or digest != declared_sha.lower():
            raise ValueError('funding response SHA-256 mismatch')
        rows = json.loads(raw)
        if not isinstance(rows, list):
            raise ValueError('Binance funding response must be JSON array')
        if len(rows) >= limit:
            raise ValueError('response at API limit: possible truncation; subdivide window')
        previous_time = all_times[-1] if all_times else -1
        for row in rows:
            if not isinstance(row, dict) or row.get('symbol') != symbol:
                raise ValueError('funding record has incorrect symbol or shape')
            ts = _timestamp_ms(row)
            if not lo <= ts <= hi or ts <= previous_time:
                raise ValueError('funding record outside declared query or out of order/duplicate')
            rate = _number(row, 'fundingRate')
            mark = _number(row, 'markPrice')
            if abs(rate) >= 1 or mark <= 0:
                raise ValueError('unreasonable rate or mark price')
            if ts == end:
                boundary_excluded += 1
            else:
                all_rows.append(row)
                all_times.append(ts)
            previous_time = ts
        page_audit.append({'index':i,'file':p['file'],'sha256':digest,
                           'requested_start_ms':lo,'requested_end_ms':hi,
                           'limit':limit,'returned':len(rows)})
    if expected_start not in (end, end + 1):
        raise ValueError('query windows do not cover requested end')
    if boundary_excluded > 1:
        raise ValueError('duplicate right-boundary events')

    daily = Counter(datetime.fromtimestamp(ts // 1000,timezone.utc).strftime('%Y-%m-%d') for ts in all_times)
    gaps = [{'from_ms':a,'to_ms':b,'hours':round((b-a)/3600000,6)}
            for a,b in zip(all_times,all_times[1:]) if b-a>12*3600000]
    report = {
      'schema':'tpsl-lab/funding-audit-v0.5', 'symbol':symbol,
      'coverage_start_ms':start,'coverage_end_exclusive_ms':end,
      'pages':page_audit,'page_count':len(page_audit),
      'funding_event_count':len(all_rows),'end_boundary_excluded':boundary_excluded,
      'timestamps_ms':all_times,'counts_per_utc_day':dict(sorted(daily.items())),
      'gaps_over_12h_observed':gaps,
      'requested_window_coverage':'VERIFIED',
      'response_limit_checks':'PASS',
      'exchange_event_completeness':'NOT_PROVEN',
      'caution':'No exchange schedule assumed; long funding gaps are warnings, not proof of missing events.',
    }
    outputs = [Path(p) for p in (export_events,export_audit) if p is not None]
    if len({p.resolve() for p in outputs}) != len(outputs) or any(p.exists() for p in outputs):
        raise ValueError('refuse to overwrite any audit output')
    if any(p.resolve() == manifest or any(p.resolve() == (root/a['file']).resolve() for a in page_audit) for p in outputs):
        raise ValueError('output overlaps input')
    for p in outputs:
        if not p.parent.is_dir():
            raise ValueError('output parent directory must already exist')
    if export_events is not None:
        Path(export_events).write_text(json.dumps(all_rows,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    if export_audit is not None:
        Path(export_audit).write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    return report
