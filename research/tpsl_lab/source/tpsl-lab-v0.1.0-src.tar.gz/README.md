# TP/SL Lab v0.1 — offline reference simulator

Small, auditable first milestone for BTC/ETH TP/SL research. This is **not** a
trading robot and **not** proof of an edge. The independent reference replay is
implemented before wiring it to Freqtrade so we can test fill mathematics against
known outcomes. No private keys, order endpoint or Binance account access.

## Scope and deliberate limitations

- Python standard library only at runtime, unlevered **nominal** position sizing.
- Long/short price-path hypotheses, *not* a production futures backtest.
- One position at a time; one pending entry created at completed bar close and
  filled at the **next** bar open, never using future prices in signals.
- Worst-case stop-first when both TP and SL fit the same candle. Gaps beyond a
  stop are executed at the opening price (with adverse slippage).
- Per-side fee and adverse slippage as configurable **scenarios**, not live quotes.
- Strict candle continuity; the replay refuses missing or duplicate bars.
- Equity at last close marks an open position; realized PnL excludes it.
- Funding, margin tiers, liquidations, queue position, order-book depth, tick-level
  chronology, latency and dynamic ATR stops are **not implemented in v0.1**.
- Therefore this release must **not** be used to rank leveraged/futures
  strategies or authorize real trading. Even short at 1x is hypothetical until
  derivatives-specific costs and margin rules are implemented.

## Installation (isolated environment)

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -e '.[test]'
.venv/bin/python -m pytest -q
```

## Run (local data only)

CSV columns: `timestamp,open,high,low,close,volume`, timestamp ISO-8601 UTC or
Binance epoch milliseconds/microseconds; for raw Binance 12-column kline CSV use
`--binance`. Rows must be contiguous at chosen timeframe (`--bar-seconds`).

```bash
.venv/bin/python -m tpsl_lab.cli --csv examples/demo.csv --strategy random \
  --probability 1 --seed 7 --tp 0.01 --sl 0.005 --notional 100 \
  --fee 0.0005 --slippage 0.0001 --out reports/demo.json
.venv/bin/python -m tpsl_lab.cli --csv examples/demo.csv --strategy never
```

`--tp` and `--sl` are decimal fractions, not percent numbers (0.01 means 1%).
Reinstantiate a strategy for each test run; it maintains state.

## MT acceptance tasks

1. Clone this research branch into a new isolated directory under
   `/home/kali/research/tpsl-lab`. Never replace another working tree.
2. Run pytest, CLI examples, compileall, record Python and package versions.
3. Independently check hand-calculated fixture outputs, no leakage and
   error handling for invalid data.
4. As a separate **read-only** validation, download a small BTCUSDT 1m public
   Binance kline CSV; check timestamps, gaps, and run a random and never-entry
   replay if the dataset is complete; no API key required.
5. Return results, command outputs, data hashes, local path and any bugs to
   the original Hermes task. Do not change NEWS, run services, or enable orders.

## Next design steps (not included in this milestone)

- Freqtrade strategy adapter and identical signal comparison.
- Real historical funding timeline; mark-price, maintenance margin,
  liquidation and tier checks; order-size/step checks.
- Intrabar exchange trade replay or explicit unresolved-bar sensitivity.
- Walk-forward, embargo, bootstrap and independent holdout reports.
- Immutable live paper signal journal, only when offline validation is sound.
