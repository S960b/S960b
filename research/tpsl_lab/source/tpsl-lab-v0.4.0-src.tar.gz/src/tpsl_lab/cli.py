"""Local replay CLI. No Binance API, no credentials, no trade execution."""
import argparse
import json
from pathlib import Path
from .engine import replay
from .io import read_csv
from .model import Costs, Settings
from .strategies import EmaTrend, NeverEntry, RandomEntry


def main(argv=None):
    p = argparse.ArgumentParser(description="OFFLINE diagnostic replay. Never places orders.")
    p.add_argument("--csv", required=True, help="Local candle CSV")
    p.add_argument("--binance", action="store_true", help="Binance kline CSV format")
    p.add_argument("--strategy", choices=("never", "random", "ema"), default="random")
    p.add_argument("--seed", type=int, default=7)
    p.add_argument("--probability", type=float, default=0.02)
    p.add_argument("--fast", type=int, default=50)
    p.add_argument("--slow", type=int, default=200)
    p.add_argument("--equity", type=float, default=1000)
    p.add_argument("--notional", type=float, default=100)
    p.add_argument("--tp", type=float, default=0.01, help="Fraction, e.g. 0.01 is 1%%")
    p.add_argument("--sl", type=float, default=0.005)
    p.add_argument("--fee", type=float, default=0.0005, help="Per-side taker fee")
    p.add_argument("--slippage", type=float, default=0.0001, help="Per-side adverse price shift")
    p.add_argument("--bar-seconds", type=int, default=60)
    p.add_argument("--out", type=Path, help="Write JSON report file")
    args = p.parse_args(argv)
    strategy = (NeverEntry() if args.strategy == "never" else
                RandomEntry(args.seed, args.probability) if args.strategy == "random" else
                EmaTrend(args.fast, args.slow))
    result = replay(read_csv(args.csv, args.binance), strategy,
                    Settings(args.equity, args.notional, args.tp, args.sl, args.bar_seconds),
                    Costs(args.fee, args.slippage))
    output = json.dumps(result, indent=2, ensure_ascii=False, allow_nan=False)
    if args.out:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(output + "\n", encoding="utf-8")
    else:
        print(output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
