"""Offline reference-vs-Freqtrade execution *diagnostics*, never order placement.

A signal match cannot guarantee a trade/fill match. For that reason this module
reports unmatched trades and differing prices/times without implying exchange
execution fidelity. It only reads local historical CSV and Freqtrade exports.
"""
from __future__ import annotations

from datetime import datetime, timezone
from hashlib import sha256
import json
from math import isfinite
from pathlib import Path, PurePosixPath
import zipfile

from .engine import replay
from .entry_signals import stream_signals
from .io import read_csv
from .model import Costs, Settings


class _LockedSignals:
    def __init__(self, bars, signals):
        self._timestamps = [b.ts for b in bars]
        self._signals = signals
        self._index = 0

    def on_close(self, candle):
        i = self._index
        if i >= len(self._signals) or candle.ts != self._timestamps[i]:
            raise ValueError('locked signal stream out of order')
        self._index += 1
        return self._signals[i]


def reference_from_file(csv_path: Path, *, kind: str, fee: float = .0005,
                        slippage: float = 0.0, notional: float = 100.0,
                        starting_equity: float = 1000.0, long_only: bool = False) -> dict:
    """Reference trades generated from locked candle-close signal decisions."""
    if kind not in ('ema', 'donchian'):
        raise ValueError('kind must be ema or donchian')
    bars = read_csv(csv_path)
    if len(bars) < 2 or any(b.ts != bars[0].ts + 60 * i for i, b in enumerate(bars)):
        raise ValueError('need continuous 1m candles, no gaps')
    signals = stream_signals(bars, kind)
    if type(long_only) is not bool:
        raise ValueError("long_only must be bool")
    if long_only:
        signals = [max(0, signal) for signal in signals]
    sim = replay(bars, _LockedSignals(bars, signals),
                 Settings(starting_equity=starting_equity, notional=notional,
                          tp_pct=.01, sl_pct=.005, bar_seconds=60),
                 Costs(taker_fee=fee, slippage=slippage))
    return {
        'schema': 'tpsl-lab/execution-reference-v1',
        'comparison_status': 'REFERENCE_ONLY_NOT_EXECUTION_PARITY',
        'strategy_kind': kind, 'long_only': long_only,
        'csv_sha256': sha256(csv_path.read_bytes()).hexdigest(),
        'bars': len(bars), 'first_ts': bars[0].ts, 'last_ts': bars[-1].ts,
        'signal_count_long': signals.count(1),
        'signal_count_short': signals.count(-1),
        'settings': {'notional': notional, 'starting_equity': starting_equity,
                     'fee_per_side': fee, 'slippage_per_side': slippage,
                     'tp_pct': .01, 'sl_pct': .005},
        'reference': sim,
        'critical_limitations': [
            'SIGNAL_PARITY_IS_NOT_FILL_PARITY',
            'FREQTRADE_ROI_IS_NOT_IDENTICAL_TO_REFERENCE_PRICE_TARGET',
            'FREQTRADE_STOP_GAP_PRICE_MAY_DIFFER',
            'UNLEVERED_REFERENCE_HAS_NO_FUNDING_OR_LIQUIDATION',
            'OHLC_INTRABAR_PATH_UNKNOWN',
            'NO_LIVE_ORDERS'
        ],
    }


def _load_export(path: Path) -> object:
    if path.suffix.lower() == '.zip':
        with zipfile.ZipFile(path) as z:
            names = z.namelist()
            if len(names) > 30:
                raise ValueError('unexpected ZIP member count')
            for name in names:
                pp = PurePosixPath(name)
                if pp.is_absolute() or '..' in pp.parts or '\\' in name:
                    raise ValueError('unsafe export ZIP path')
                info = z.getinfo(name)
                if info.file_size > 20_000_000:
                    raise ValueError('oversized Freqtrade export')
            candidates = [n for n in names if n.endswith('.json') and not n.endswith('.meta.json')]
            if len(candidates) != 1:
                raise ValueError('expected exactly one results JSON in the export ZIP')
            raw = z.read(candidates[0])
    elif path.suffix.lower() == '.json':
        if path.stat().st_size > 20_000_000:
            raise ValueError('oversized Freqtrade JSON export')
        raw = path.read_bytes()
    else:
        raise ValueError('Freqtrade export must be .json or .zip')
    if len(raw) > 20_000_000:
        raise ValueError('export uncompressed size too large')
    return json.loads(raw)


def _parse_utc(v) -> int:
    if not isinstance(v, str):
        raise ValueError('trade date must be UTC ISO string')
    dt = datetime.fromisoformat(v.strip().replace('Z', '+00:00'))
    if dt.tzinfo is None:
        # Freqtrade's historical JSON export often uses naive strings in UTC.
        dt = dt.replace(tzinfo=timezone.utc)
    if dt.utcoffset().total_seconds() != 0:
        raise ValueError('export date must be UTC')
    if dt.microsecond:
        raise ValueError('subsecond Freqtrade trade dates are not comparable at bar-level')
    return int(dt.timestamp())


def _rate(v, label):
    if type(v) not in (float, int) or not isfinite(v) or v <= 0:
        raise ValueError('invalid '+label)
    return float(v)


def parse_freqtrade_trades(path: Path, *, strategy: str, pair: str) -> list[dict]:
    doc = _load_export(path)
    if not isinstance(doc, dict) or not isinstance(doc.get('strategy'), dict):
        raise ValueError('unsupported backtest format: missing strategy mapping')
    data = doc['strategy'].get(strategy)
    if not isinstance(data, list):
        raise ValueError('requested strategy missing or not a trade list')
    trades, seen = [], set()
    for t in data:
        if not isinstance(t, dict):
            raise ValueError('malformed trade')
        if t.get('pair') != pair or type(t.get('is_short')) is not bool:
            raise ValueError('pair or side missing/mismatched')
        direction = -1 if t['is_short'] else 1
        entry_ts = _parse_utc(t.get('open_date'))
        exit_ts = _parse_utc(t.get('close_date'))
        if exit_ts < entry_ts:
            raise ValueError('trade exit earlier than entry')
        key = (entry_ts, direction)
        if key in seen:
            raise ValueError('duplicate entry timestamp/direction: unsupported scale-in')
        seen.add(key)
        trades.append({'entry_ts': entry_ts, 'exit_ts': exit_ts,
                       'direction': direction, 'entry_price': _rate(t.get('open_rate'), 'open_rate'),
                       'exit_price': _rate(t.get('close_rate'), 'close_rate'),
                       'exit_reason': str(t.get('exit_reason') or 'UNKNOWN')})
    return sorted(trades, key=lambda t: (t['entry_ts'], t['direction']))


def _reason_category(reason: str) -> str:
    if reason in ('target', 'target_gap', 'roi'):
        return 'target_family'
    if reason in ('stop', 'stop_gap', 'stop_loss', 'stoploss', 'stop_loss_limit'):
        return 'stop_family'
    return 'other'


def compare_reference(reference: dict, ft_trades: list[dict], *, ft_sha256: str,
                      strategy: str, pair: str) -> dict:
    if reference.get('schema') != 'tpsl-lab/execution-reference-v1':
        raise ValueError('unknown reference schema')
    ours = reference['reference']['trades']
    ours_by = {(t['entry_ts'], t['direction']): t for t in ours}
    ft_by = {(t['entry_ts'], t['direction']): t for t in ft_trades}
    if len(ours_by) != len(ours) or len(ft_by) != len(ft_trades):
        raise ValueError('duplicate trade entry key')
    all_keys = sorted(set(ours_by) | set(ft_by))
    samples = []
    entry_price_mismatch = exit_price_mismatch = time_mismatch = reason_mismatch = 0
    matched = only_ref = only_ft = 0
    for key in all_keys:
        a, b = ours_by.get(key), ft_by.get(key)
        if a is None:
            only_ft += 1
            if len(samples) < 30:
                samples.append({'entry_ts': key[0], 'direction': key[1], 'type': 'FREQTRADE_ONLY'})
            continue
        if b is None:
            only_ref += 1
            if len(samples) < 30:
                samples.append({'entry_ts': key[0], 'direction': key[1], 'type': 'REFERENCE_ONLY'})
            continue
        matched += 1
        ebps = (b['entry_price'] - a['entry_price']) / a['entry_price'] * 10000
        xbps = (b['exit_price'] - a['exit_price']) / a['exit_price'] * 10000
        esec = b['exit_ts'] - a['exit_ts']
        reason_diff = _reason_category(a['exit_reason']) != _reason_category(b['exit_reason'])
        entry_price_mismatch += abs(ebps) > 1e-6
        exit_price_mismatch += abs(xbps) > 1e-6
        time_mismatch += esec != 0
        reason_mismatch += reason_diff
        if (abs(ebps) > 1e-6 or abs(xbps) > 1e-6 or esec or reason_diff) and len(samples) < 30:
            samples.append({'entry_ts': key[0], 'direction': key[1],
                            'type': 'MATCHED_WITH_DIFFERENCE', 'entry_delta_bps': ebps,
                            'exit_delta_bps': xbps, 'exit_delta_seconds': esec,
                            'ref_reason': a['exit_reason'], 'ft_reason': b['exit_reason']})
    return {
        'schema': 'tpsl-lab/execution-comparison-v1',
        'status': 'DIAGNOSTIC_ONLY_NOT_PROOF_OF_EXCHANGE_FILLS',
        'freqtrade_export_sha256': ft_sha256,
        'reference_csv_sha256': reference['csv_sha256'],
        'strategy_kind': reference['strategy_kind'],
        'freqtrade_strategy': strategy, 'pair': pair,
        'reference_closed_trades': len(ours), 'freqtrade_closed_trades': len(ft_trades),
        'matched_entry_direction': matched, 'only_reference': only_ref,
        'only_freqtrade': only_ft, 'entry_price_mismatches': entry_price_mismatch,
        'exit_price_mismatches': exit_price_mismatch,
        'exit_time_mismatches': time_mismatch, 'exit_reason_family_mismatches': reason_mismatch,
        'sample': samples,
        'interpretation': 'Differences are evidence to investigate, not errors by definition. '
                          'Futures funding, leverage, liquidation and fee/ROI semantics differ.'
    }
