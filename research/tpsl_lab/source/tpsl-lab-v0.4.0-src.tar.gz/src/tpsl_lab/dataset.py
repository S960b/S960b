"""Strict, local-only Binance USD-M 1m daily trade/mark dataset auditor.

No HTTP access. This module validates downloaded inputs and can export clean
multi-day replay CSVs. Checksums document bytes, NOT source authenticity.
"""
from __future__ import annotations

import csv
import hashlib
import io
import json
import re
import zipfile
from dataclasses import asdict, dataclass
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

from .futures_io import read_binance_funding
from .model import Candle
from .io import _timestamp

MAX_ARCHIVE_BYTES = 25_000_000
MAX_CSV_BYTES = 12_000_000


@dataclass(frozen=True)
class DailyBars:
    source_path: str
    raw_sha256: str
    csv_sha256: str
    bars: tuple[Candle, ...]


def _sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def _open_daily_bytes(path: Path) -> tuple[bytes, bytes]:
    if not path.is_file() or path.stat().st_size > MAX_ARCHIVE_BYTES:
        raise ValueError(f'missing or oversized input: {path}')
    raw = path.read_bytes()
    if path.suffix.lower() == '.csv':
        if len(raw) > MAX_CSV_BYTES:
            raise ValueError('CSV too large')
        return raw, raw
    if path.suffix.lower() != '.zip':
        raise ValueError('only local ZIP or CSV supported')
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        infos = archive.infolist()
        if len(infos) != 1 or infos[0].is_dir():
            raise ValueError('ZIP must contain exactly one CSV')
        item = infos[0]
        if (not re.fullmatch(r'[A-Za-z0-9._-]+\.csv', item.filename) or
                item.flag_bits & 1 or item.file_size > MAX_CSV_BYTES or
                ((item.external_attr >> 16) & 0o170000) == 0o120000):
            raise ValueError('unsafe or oversized ZIP member')
        data = archive.read(item)
        if len(data) > MAX_CSV_BYTES:
            raise ValueError('CSV decompression limit exceeded')
    return raw, data


def _raw_timestamp_check(raw: str, expected: int) -> None:
    raw = raw.strip()
    if not raw.isdecimal():
        raise ValueError('Binance timestamp must be numeric')
    num = int(raw)
    if num >= 10**14:  # microseconds
        if num % 60_000_000:
            raise ValueError('non-minute microsecond timestamp')
    elif num >= 10**11:  # milliseconds
        if num % 60_000:
            raise ValueError('non-minute millisecond timestamp')
    else:
        if num % 60:
            raise ValueError('non-minute seconds timestamp')
    if _timestamp(raw) != expected:
        raise ValueError('noncontiguous Binance minute or incorrect UTC date')


def read_daily(path: str | Path, day: date) -> DailyBars:
    """Validate a *complete* UTC daily 1m kline, with no timestamp rounding."""
    path = Path(path)
    raw, data = _open_daily_bytes(path)
    try:
        csv_text = data.decode('utf-8-sig', errors='strict')
    except UnicodeError as exc:
        raise ValueError('CSV must be UTF-8') from exc
    expected_start = int(datetime(day.year,day.month,day.day,tzinfo=timezone.utc).timestamp())
    candles = []
    reader = csv.reader(io.StringIO(csv_text))
    for row in reader:
        if row and row[0] == 'open_time' and not candles:
            continue
        if len(row) != 12:
            raise ValueError('expected 12 Binance kline CSV columns')
        if len(candles) >= 1440:
            raise ValueError('more than 1440 bars')
        expected = expected_start + 60 * len(candles)
        _raw_timestamp_check(row[0], expected)
        candles.append(Candle(expected,*(float(x) for x in row[1:6])))
    if len(candles) != 1440:
        raise ValueError(f'incomplete UTC day: {len(candles)} bars instead of 1440')
    return DailyBars(str(path),_sha(raw),_sha(data),tuple(candles))


def _find_day(directory: Path, symbol: str, day: date) -> Path:
    stem = f'{symbol}-1m-{day.isoformat()}'
    paths = [directory/(stem+'.zip'), directory/(stem+'.csv')]
    found = [p for p in paths if p.exists()]
    if len(found)!=1:
        raise ValueError(f'expected exactly one CSV or ZIP for {stem} in {directory}')
    return found[0]


def _emit_csv(path: Path, bars: list[Candle]) -> None:
    with path.open('w',newline='',encoding='utf-8') as f:
        writer=csv.writer(f,lineterminator='\n')
        writer.writerow(['timestamp','open','high','low','close','volume'])
        for bar in bars:
            writer.writerow([bar.ts,bar.open,bar.high,bar.low,bar.close,bar.volume])


def audit_days(trade_dir: str | Path, mark_dir: str | Path, start_date: str,
               days: int, symbol: str, funding_json: str | Path,
               export_dir: str | Path | None = None) -> dict:
    """Audit raw history and optionally write normalized multi-day replay files.

    Funding completeness remains explicitly unverified: historical endpoint
    pagination and exchange data retention must be audited independently.
    """
    if symbol not in ('BTCUSDT','ETHUSDT') or type(days) is not int or not 1 <= days <= 31:
        raise ValueError('invalid symbol or day count (1..31)')
    try:
        start = date.fromisoformat(start_date)
        if start.isoformat() != start_date:
            raise ValueError('noncanonical date')
    except (TypeError, ValueError) as exc:
        raise ValueError('start_date must be YYYY-MM-DD') from exc
    trade_dir = Path(trade_dir)
    mark_dir = Path(mark_dir)
    all_trade: list[Candle] = []
    all_mark: list[Candle] = []
    summaries = []
    for delta in range(days):
        day = start + timedelta(days=delta)
        t = read_daily(_find_day(trade_dir,symbol,day),day)
        m = read_daily(_find_day(mark_dir,symbol,day),day)
        if any(x.ts != y.ts for x,y in zip(t.bars,m.bars)):
            raise ValueError('mark/trade candles misaligned')
        all_trade.extend(t.bars)
        all_mark.extend(m.bars)
        summaries.append(dict(day=day.isoformat(),bars=1440,
           trade=dict(path=Path(t.source_path).name,raw_sha256=t.raw_sha256,csv_sha256=t.csv_sha256),
           mark=dict(path=Path(m.source_path).name,raw_sha256=m.raw_sha256,csv_sha256=m.csv_sha256)))
    coverage_start = all_trade[0].ts
    coverage_end = all_trade[-1].ts+60
    funding_path=Path(funding_json)
    if not funding_path.is_file() or funding_path.stat().st_size > MAX_CSV_BYTES:
        raise ValueError('missing or oversized funding JSON')
    funding = read_binance_funding(funding_path,coverage_start,coverage_end,symbol)
    report=dict(schema='tpsl-lab/dataset-v0.4',symbol=symbol,
      timeframe='1m',start_utc=datetime.fromtimestamp(coverage_start,timezone.utc).isoformat(),
      end_exclusive_utc=datetime.fromtimestamp(coverage_end,timezone.utc).isoformat(),
      days=days,total_bars=len(all_trade),daily=summaries,
      funding=dict(raw_sha256=_sha(funding_path.read_bytes()),
                   event_count=len(funding.events), timestamps_ms=[e.exact_ms for e in funding.events],
                   source=funding.source, completeness='NOT_PROVEN'),
      restrictions=['OFFLINE_ONLY','NO_FUNDING_COMPLETENESS_PROOF',
                    'NO_HISTORICAL_MARGIN_TIERS','NO_ORDERBOOK_OR_EXECUTION_PROOF'])
    if export_dir is not None:
        out=Path(export_dir)
        if out.exists():
            raise ValueError('export directory already exists (refuse overwrite)')
        out.mkdir(parents=True)
        _emit_csv(out/'trade_1m.csv',all_trade)
        _emit_csv(out/'mark_1m.csv',all_mark)
        (out/'audit.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    return report
