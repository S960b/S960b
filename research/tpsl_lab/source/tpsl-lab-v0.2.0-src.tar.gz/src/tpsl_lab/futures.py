"""Offline isolated-margin *risk proxy* for USD-M linear perps.

No Binance credentials, network, order placement, or claim of exact liquidation fills.
Uses trade-price bars for TP/SL and independent mark-price bars for margin checks.
Liquidation is CONSERVATIVE: if a mark candle breaches maintenance in the same
bar as a possible stop or target, liquidation wins and full isolated margin is
charged. This is a stress accounting proxy, NOT Binance's settlement engine.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from math import isfinite
from .engine import _exit_check, _fill
from .model import Candle, Costs, Position


def _positive_finite(x: float) -> bool:
    return isfinite(x) and x > 0


@dataclass(frozen=True)
class MarginTier:
    floor: float
    cap: float
    maintenance_rate: float
    maintenance_amount: float
    max_leverage: float

    def __post_init__(self):
        if (not isfinite(self.floor) or self.floor < 0 or
            not _positive_finite(self.cap) or self.cap <= self.floor or
            not isfinite(self.maintenance_rate) or not 0 <= self.maintenance_rate < 1 or
            not isfinite(self.maintenance_amount) or self.maintenance_amount < 0 or
            not _positive_finite(self.max_leverage)):
            raise ValueError('invalid margin tier')


@dataclass(frozen=True)
class FuturesSettings:
    starting_equity: float = 1000.0
    position_notional: float = 100.0
    leverage: float = 2.0
    tp_pct: float = 0.01
    sl_pct: float = 0.005
    bar_seconds: int = 60
    liquidation_fee_reserve_rate: float = 0.005

    def __post_init__(self):
        if any(not _positive_finite(x) for x in (
            self.starting_equity, self.position_notional, self.leverage,
            self.tp_pct, self.sl_pct)):
            raise ValueError('invalid positive futures setting')
        if not 1 <= self.leverage <= 125:
            raise ValueError('leverage outside research safety bounds')
        if not 0 < self.tp_pct < 1 or not 0 < self.sl_pct < 1:
            raise ValueError('invalid TP/SL fraction')
        if type(self.bar_seconds) is not int or self.bar_seconds <= 0:
            raise ValueError('invalid bar seconds')
        if not isfinite(self.liquidation_fee_reserve_rate) or not 0 <= self.liquidation_fee_reserve_rate < 0.1:
            raise ValueError('invalid liquidation reserve rate')


@dataclass(frozen=True)
class FundingEvent:
    ts: int  # funding event UTC seconds, exact; no inferred 8h schedule
    rate: float  # + rate => longs pay / shorts receive
    mark_price: float

    def __post_init__(self):
        if type(self.ts) is not int or self.ts < 0 or not isfinite(self.rate) or abs(self.rate) >= 1 or not _positive_finite(self.mark_price):
            raise ValueError('invalid funding event')


@dataclass(frozen=True)
class FundingTape:
    events: tuple[FundingEvent, ...]
    coverage_start: int
    coverage_end: int  # exclusive
    source: str  # e.g. 'binance-fapi-funding-history'; no proof of completeness!

    def __post_init__(self):
        if (type(self.coverage_start) is not int or type(self.coverage_end) is not int or
            self.coverage_start < 0 or self.coverage_end <= self.coverage_start or not self.source.strip()):
            raise ValueError('invalid funding coverage')
        prev = -1
        for e in self.events:
            if not self.coverage_start <= e.ts < self.coverage_end or e.ts <= prev:
                raise ValueError('funding timestamps must be strictly sorted and within coverage')
            prev = e.ts


@dataclass
class _Open:
    entry_ts: int
    direction: int
    quantity: float
    entry_price: float
    margin: float
    entry_fee: float
    stop: float
    target: float
    funding_cashflow: float = 0.0


def _tier(tiers: tuple[MarginTier, ...], notional: float) -> MarginTier:
    for i, t in enumerate(tiers):
        if t.floor <= notional < t.cap or (i == len(tiers)-1 and notional == t.cap):
            return t
    raise ValueError('no maintenance tier covers mark notional: FAIL CLOSED')


def _maintenance(tiers: tuple[MarginTier, ...], notional: float) -> float:
    t = _tier(tiers, notional)
    return max(0.0, notional * t.maintenance_rate - t.maintenance_amount)


def _liquidation_risk_at(mark: float, pos: _Open, tiers: tuple[MarginTier, ...], reserve_rate: float) -> bool:
    notional = mark * pos.quantity
    equity_in_isolated = pos.margin + pos.direction * pos.quantity * (mark - pos.entry_price) + pos.funding_cashflow
    return equity_in_isolated <= _maintenance(tiers, notional) + notional * reserve_rate + 1e-10


def replay_futures(bars: list[Candle], marks: list[Candle], strategy,
                   funding: FundingTape, tiers: tuple[MarginTier, ...],
                   settings: FuturesSettings = FuturesSettings(),
                   costs: Costs = Costs()) -> dict:
    """Offline deterministic conservative futures proxy, with strict inputs.

    Candle open timestamp is UTC second; only a closed candle creates a signal;
    its entry (if any) executes at next bar open. Mark and execution candles
    must align 1:1. Funding at bar boundary applies to existing position;
    pending entries are processed AFTER existing-position funding on that boundary,
    but an adverse debit is conservatively booked for new entrants at the same
    timestamp (uncertain settlement window). Credits on same-open exits are
    suppressed. An intrabar funding timestamp is rejected.
    Liquidation is an adverse event if mark OHLC breached it intrabar; it wins
    all same-bar uncertainty. On liquidation the booked loss is full isolated
    margin, NOT a claimed Binance fill or precise realized PnL.
    """
    if len(bars) < 2 or len(bars) != len(marks):
        raise ValueError('require >=2 aligned execution/mark bars')
    if not tiers or tiers[0].floor != 0:
        raise ValueError('tiers must cover notional from zero')
    for i, t in enumerate(tiers):
        if i and abs(t.floor - tiers[i-1].cap) > 1e-10:
            raise ValueError('missing or overlapping maintenance tier')
    for i, (bar, mark) in enumerate(zip(bars, marks)):
        if bar.ts != mark.ts or bar.ts % settings.bar_seconds:
            raise ValueError('mark/trade timestamps misaligned')
        if i and bar.ts != bars[i-1].ts + settings.bar_seconds:
            raise ValueError('missing/duplicate/nonordered bar')
    if not (funding.coverage_start <= bars[0].ts and
            funding.coverage_end >= bars[-1].ts + settings.bar_seconds):
        raise ValueError('incomplete declared funding coverage')
    bar_starts = {b.ts for b in bars}
    if any(e.ts not in bar_starts for e in funding.events):
        raise ValueError('intrabar funding cannot be ordered in OHLC mode')
    # A missing funding event cannot be inferred; user is responsible for
    # obtaining complete history and its documented exact time window.
    equity = settings.starting_equity
    pos: _Open | None = None
    pending = 0
    events = []
    trades = []
    peak_equity = equity
    max_drawdown = 0.0
    funding_by_ts = {e.ts: e for e in funding.events}
    sum_fees = sum_funding = 0.0
    ambiguous_liquidations = 0
    total_liquidations = 0

    def log(ts, kind, **kwargs):
        events.append(dict(seq=len(events)+1, ts=ts, kind=kind, balance=equity, **kwargs))

    for bar, mark in zip(bars, marks):
        # Order at a funding timestamp is ambiguous at second resolution.
        # Existing position pays/receives; new positions execute afterwards.
        if pos is not None and bar.ts in funding_by_ts:
            f = funding_by_ts[bar.ts]
            raw_cashflow = -pos.direction * pos.quantity * f.mark_price * f.rate
            # Exit triggered exactly at the bar open may have beaten funding.
            # Do not assume a favourable funding credit for such a boundary.
            opening_exit = ((pos.direction == 1 and
                             (bar.open <= pos.stop or bar.open >= pos.target)) or
                            (pos.direction == -1 and
                             (bar.open >= pos.stop or bar.open <= pos.target)))
            cashflow = min(raw_cashflow, 0.0) if opening_exit else raw_cashflow
            equity += cashflow
            pos.funding_cashflow += cashflow
            sum_funding += cashflow
            log(bar.ts, 'funding', rate=f.rate, mark=f.mark_price,
                cashflow=cashflow, boundary_credit_suppressed=opening_exit and raw_cashflow > 0)

        if pos is None and pending:
            direction = pending
            entry_price = _fill(bar.open, direction, costs.slippage)
            margin = settings.position_notional / settings.leverage
            qty = settings.position_notional / entry_price
            tier = _tier(tiers, qty * entry_price)
            fee = qty * entry_price * costs.taker_fee
            # Validate leverage tiers and fee-adequate free collateral.
            if settings.leverage <= tier.max_leverage and margin + fee <= equity:
                equity -= fee
                sum_fees += fee
                pos = _Open(bar.ts, direction, qty, entry_price, margin, fee,
                            entry_price * (1 - direction * settings.sl_pct),
                            entry_price * (1 + direction * settings.tp_pct))
                log(bar.ts, 'entry', direction=direction, price=entry_price,
                    quantity=qty, margin=margin, fee=fee)
                if bar.ts in funding_by_ts:
                    f = funding_by_ts[bar.ts]
                    # Actual funding settlement can be offset from its scheduled
                    # timestamp. If entry is at that boundary, book only a
                    # possible debit, never an uncertain credit.
                    cashflow = min(0.0, -direction * qty * f.mark_price * f.rate)
                    equity += cashflow
                    pos.funding_cashflow += cashflow
                    sum_funding += cashflow
                    log(bar.ts, 'funding_entry_boundary_CONSERVATIVE',
                        rate=f.rate, mark=f.mark_price, cashflow=cashflow)
            else:
                log(bar.ts, 'rejected_entry', reason='margin_or_leverage_limit')
        pending = 0

        if pos is not None:
            # Validate risk with mark, including at bar OPEN, LOW/HIGH, not trade price.
            bad_open = _liquidation_risk_at(mark.open, pos, tiers, settings.liquidation_fee_reserve_rate)
            bad_extreme = _liquidation_risk_at(mark.low if pos.direction == 1 else mark.high,
                                               pos, tiers, settings.liquidation_fee_reserve_rate)
            normal_exit = _exit_check(bar, Position(pos.entry_ts, pos.direction, pos.quantity,
                                                      pos.entry_price, pos.entry_fee, pos.stop, pos.target),
                                      costs.slippage)
            if bad_open or bad_extreme:
                # Account-level profit/loss after proxy liquidation: assume isolated
                # collateral wiped. Funding already booked separately.
                ambiguous = bool(normal_exit) and not bad_open
                ambiguous_liquidations += int(ambiguous)
                equity -= pos.margin
                total_liquidations += 1
                trades.append(dict(entry_ts=pos.entry_ts, exit_ts=bar.ts,
                    direction=pos.direction, entry_price=pos.entry_price,
                    exit_price=None, quantity=pos.quantity, net_pnl=None,
                    funding_cashflow=pos.funding_cashflow, proxy_margin_loss=pos.margin,
                    reason='liquidation_PROXY', ambiguous=ambiguous))
                log(bar.ts, 'liquidation_PROXY', margin_loss=pos.margin,
                    ambiguity_with_stop_or_target=ambiguous, bad_at_open=bad_open)
                pos = None
            elif normal_exit is not None:
                price, reason, ambiguous = normal_exit
                exit_fee = pos.quantity * price * costs.taker_fee
                gross = pos.direction * pos.quantity * (price - pos.entry_price)
                equity += gross - exit_fee
                sum_fees += exit_fee
                trades.append(dict(entry_ts=pos.entry_ts, exit_ts=bar.ts,
                    direction=pos.direction, entry_price=pos.entry_price,
                    exit_price=price, quantity=pos.quantity,
                    net_pnl=gross-pos.entry_fee-exit_fee+pos.funding_cashflow,
                    funding_cashflow=pos.funding_cashflow, proxy_margin_loss=0.0,
                    reason=reason, ambiguous=ambiguous))
                log(bar.ts, 'exit', reason=reason, price=price, fee=exit_fee,
                    gross=gross, ambiguous=ambiguous)
                pos = None

        marked = equity
        if pos is not None:
            marked += pos.direction * pos.quantity * (mark.close - pos.entry_price)
            marked -= pos.quantity * mark.close * costs.taker_fee
        peak_equity = max(peak_equity, marked)
        max_drawdown = max(max_drawdown, (peak_equity-marked)/peak_equity)
        direction = strategy.on_close(bar)
        if type(direction) is not int or direction not in (-1, 0, 1):
            raise ValueError('strategy signal must be -1, 0 or +1')
        if pos is None:
            pending = direction

    return dict(schema='tpsl-lab/v0.2', mode='offline_isolated_futures_CONSERVATIVE_PROXY',
                not_production_ready=True,
                limitations=['LIQUIDATION_IS_MARGIN_LOSS_PROXY_NOT_BINANCE_FILL',
                    'SAME_BAR_LIQUIDATION_WINS_UNKNOWN_ORDER',
                    'NO_ORDERBOOK_LATENCY_OR_QUEUE', 'NO_HISTORICAL_TIER_VALIDATION',
                    'FUNDING_TAPE_COMPLETENESS_NOT_AUTOMATICALLY_PROVEN',
                    'NO_EXACT_FUNDING_OR_ORDER_BOUNDARY_TIMING',
                    'NO_LIVE_OR_TESTNET_TRADING'],
                bars=len(bars), starting_equity=settings.starting_equity,
                closed_equity=equity, marked_equity=marked,
                max_drawdown=max_drawdown, total_fees=sum_fees,
                funding_cashflow=sum_funding, liquidations_proxy=total_liquidations,
                ambiguous_liquidations=ambiguous_liquidations,
                trades=trades, events=events,
                open_position=asdict(pos) if pos else None,
                funding_source=funding.source, funding_coverage=[funding.coverage_start,funding.coverage_end])
