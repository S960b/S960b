import math
from pathlib import Path
import pytest
from tpsl_lab.model import Candle
from tpsl_lab.entry_signals import DonchianBreakout, strategy_factory, stream_signals, dataframe_signals
from tpsl_lab.parity_cli import compare, main


def bars(n=450, *, slope=0):
    out=[]
    for i in range(n):
        close=100 + slope*i + 4*math.sin(i/11) + 0.3*math.sin(i/2)
        out.append(Candle(ts=i*60,open=close-0.1,high=close+0.5,low=close-0.5,close=close,volume=10))
    return out


def frame(data):
    pd=pytest.importorskip('pandas')
    return pd.DataFrame([dict(open=b.open,high=b.high,low=b.low,close=b.close,volume=b.volume) for b in data])


@pytest.mark.parametrize('kind,kw', [('ema',{'fast':5,'slow':21}),('ema',{'fast':50,'slow':200}),('donchian',{'lookback':5}),('donchian',{'lookback':20}),('never',{})])
def test_stream_vs_vector_exact(kind,kw):
    data=bars()
    assert stream_signals(data,kind,**kw)==dataframe_signals(frame(data),kind,**kw)


def test_ema_first_signal_never_before_slow():
    signals=stream_signals(bars(), 'ema',fast=5,slow=21)
    assert signals[:20]==[0]*20
    assert any(signals[20:])


def test_donchian_uses_previous_highs_and_lows():
    s=DonchianBreakout(3)
    def x(i,price):return Candle(i*60,price,price,price,price,10)
    assert [s.on_close(x(i,p)) for i,p in enumerate((100,101,102,103,104,99,98))]==[0,0,0,1,1,-1,-1]


def test_donchian_no_lookahead():
    original=bars()
    original_signals=stream_signals(original,'donchian',lookback=20)
    mutated=original[:250]+bars(200,slope=3)
    assert stream_signals(mutated,'donchian',lookback=20)[:250]==original_signals[:250]


def test_ema_no_lookahead():
    original=bars()
    original_signals=stream_signals(original,'ema',fast=50,slow=200)
    mutated=original[:250]+bars(200,slope=3)
    assert stream_signals(mutated,'ema',fast=50,slow=200)[:250]==original_signals[:250]


def test_factory_rejects_unknown_strategy():
    with pytest.raises(ValueError):strategy_factory('not_a_strategy')


def test_lookback_input_guard():
    for n in (1,0,-1,1.5,True):
        with pytest.raises(ValueError):DonchianBreakout(n)


def test_untradeable_volume_for_donchian():
    s=DonchianBreakout(2)
    s.on_close(Candle(0,100,100,100,100,volume=1))
    s.on_close(Candle(60,100,100,100,100,volume=1))
    assert s.on_close(Candle(120,101,101,101,101,volume=0))==0


def test_stream_vector_nondefault_index():
    f=frame(bars());f.index=range(1000,1000+len(f))
    assert dataframe_signals(f,'ema')==stream_signals(bars(),'ema')


def test_no_simultaneous_long_and_short():
    data=bars()
    sig=dataframe_signals(frame(data),'donchian')
    assert all(x in (-1,0,1) for x in sig)


def test_parity_cli_output_and_no_overwrite(tmp_path):
    data=bars(250)
    csv=tmp_path/'data.csv'
    csv.write_text('timestamp,open,high,low,close,volume\n'+''.join(
        f'{x.ts},{x.open},{x.high},{x.low},{x.close},{x.volume}\n' for x in data))
    out=tmp_path/'report.json'
    assert main(['--csv',str(csv),'--strategy','ema','--out',str(out)])==0
    assert '"mismatch_count": 0' in out.read_text()
    with pytest.raises(FileExistsError):main(['--csv',str(csv),'--strategy','ema','--out',str(out)])


def test_parity_reject_gaps():
    b=bars(60)
    with pytest.raises(ValueError,match='contiguous'):
        compare(b[:20]+b[21:],kind='donchian')


def test_df_bad_columns_rejected():
    pd=pytest.importorskip('pandas')
    with pytest.raises(ValueError):dataframe_signals(pd.DataFrame({'close':[1]}),'ema')


def test_signal_validation():
    with pytest.raises(ValueError):dataframe_signals(frame(bars()),'ema',fast=100,slow=10)
    with pytest.raises(ValueError):dataframe_signals(frame(bars()),'donchian',lookback=1)
    with pytest.raises(ValueError):dataframe_signals(frame(bars()),'random')


def test_freqtrade_adapter_compiles_and_is_offline():
    p=Path(__file__).resolve().parents[1]/'user_data/strategies/TpslLabSignalParity.py'
    code=p.read_text()
    compile(code,str(p),'exec')
    assert 'populate_entry_trend' in code and 'populate_exit_trend' in code
    assert 'requests' not in code and 'create_order' not in code and 'ccxt' not in code


def test_freqtrade_adapter_indicator_column_matches_stream(monkeypatch):
    import importlib.util
    import sys
    import types
    fake_pkg=types.ModuleType('freqtrade')
    fake_strat=types.ModuleType('freqtrade.strategy')
    fake_strat.IStrategy=type('IStrategy',(),{})
    monkeypatch.setitem(sys.modules,'freqtrade',fake_pkg)
    monkeypatch.setitem(sys.modules,'freqtrade.strategy',fake_strat)
    p=Path(__file__).resolve().parents[1]/'user_data/strategies/TpslLabSignalParity.py'
    spec=importlib.util.spec_from_file_location('lab_freqtrade_adapter_test',p)
    m=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    for kind,klass in [('ema',m.TpslLabEmaParity),('donchian',m.TpslLabDonchianParity)]:
        data=bars()
        d=frame(data)
        s=klass()
        d=s.populate_indicators(d,{})
        d=s.populate_entry_trend(d,{})
        d=s.populate_exit_trend(d,{})
        actual=[1 if x==1 else -1 if y==1 else 0 for x,y in zip(
            d['enter_long'].fillna(0),d['enter_short'].fillna(0))]
        assert actual==stream_signals(data,kind)
        assert d['exit_long'].tolist()==[0]*len(data)
        assert d['exit_short'].tolist()==[0]*len(data)
