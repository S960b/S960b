"""Offline only. Use previously downloaded Binance data; never sends HTTP or orders."""
import argparse
import json
from pathlib import Path
from .dataset import audit_days


def main(argv=None):
    p=argparse.ArgumentParser(description='Audit locally downloaded BTC/ETH 1m Binance USD-M files; NO NETWORK')
    p.add_argument('--trade-dir',required=True,type=Path)
    p.add_argument('--mark-dir',required=True,type=Path)
    p.add_argument('--start-date',required=True)
    p.add_argument('--days',type=int,required=True)
    p.add_argument('--symbol',choices=['BTCUSDT','ETHUSDT'],required=True)
    p.add_argument('--funding-json',required=True,type=Path)
    p.add_argument('--export-dir',type=Path)
    a=p.parse_args(argv)
    print(json.dumps(audit_days(a.trade_dir,a.mark_dir,a.start_date,a.days,a.symbol,
                                a.funding_json,a.export_dir),indent=2,ensure_ascii=False))
    return 0


if __name__=='__main__':
    raise SystemExit(main())
