"""Postmortem evidence for discrepancies in read-only Freqtrade backtests.

This module DOES NOT infer what occurred within an OHLC candle and DOES NOT
claim parity with actual exchange fills. It makes competing timing hypotheses
explicit, preserving original prices and exact exchange/backtest timestamps.
"""
from __future__ import annotations

from collections import Counter
from hashlib import sha256
from pathlib import Path

from .execution_compare import _reason_category, compare_reference
from .io import read_csv


SCHEMA = "tpsl-lab/execution-diagnosis-v1"


def _price_ratio_bps(a: float, b: float) -> float:
    if a <= 0 or b <= 0:
        raise ValueError("prices must be finite positive")
    return (b / a - 1.0) * 10_000.0


def _bar_dict(b):
    return {"ts": b.ts, "open": b.open, "high": b.high,
            "low": b.low, "close": b.close, "volume": b.volume}


def _validate(bars, reference, ft_trades):
    if reference.get("schema") != "tpsl-lab/execution-reference-v1":
        raise ValueError("reference schema mismatch")
    if not bars or len(bars) != reference.get("bars"):
        raise ValueError("bar count mismatch")
    for i, b in enumerate(bars):
        if b.ts != bars[0].ts + i * 60:
            raise ValueError("continuous 1m bars required")
    if bars[0].ts != reference.get("first_ts") or bars[-1].ts != reference.get("last_ts"):
        raise ValueError("reference timestamp range mismatch")
    ours = reference["reference"]["trades"]
    for group in (ours, ft_trades):
        keys = [(t["entry_ts"], t["direction"]) for t in group]
        if len(keys) != len(set(keys)):
            raise ValueError("duplicate entry key")
    return ours


def _expected_stop_touch(bars_by_ts, entry_ts, upper_ts, stop, direction):
    """First OHLC bar touching REFERENCE stop (not Freqtrade stop)."""
    for ts in range(entry_ts, upper_ts + 1, 60):
        candle = bars_by_ts.get(ts)
        if candle is None:
            continue
        hit = candle.low <= stop if direction == 1 else candle.high >= stop
        if hit:
            return ts
    return None


def diagnose(reference: dict, ft_trades: list[dict], bars, *, ft_sha256: str,
             strategy: str, pair: str, max_evidence: int = 100) -> dict:
    if not isinstance(max_evidence, int) or not 1 <= max_evidence <= 200:
        raise ValueError("max_evidence must be 1..200")
    ours = _validate(bars, reference, ft_trades)
    compare = compare_reference(reference, ft_trades, ft_sha256=ft_sha256,
                                strategy=strategy, pair=pair)
    settings = reference["settings"]
    stop_pct = settings["sl_pct"]
    if not isinstance(stop_pct, (int, float)) or not 0 < stop_pct < 1:
        raise ValueError("invalid stop_pct")
    by_ts = {b.ts: b for b in bars}
    ours_by = {(t["entry_ts"], t["direction"]): t for t in ours}
    ft_by = {(t["entry_ts"], t["direction"]): t for t in ft_trades}
    reason_counts = Counter()
    cases = []
    for key in sorted(set(ours_by) | set(ft_by)):
        a, f = ours_by.get(key), ft_by.get(key)
        if a is None or f is None:
            typ = "FREQTRADE_ONLY" if a is None else "REFERENCE_ONLY"
            reason_counts[typ] += 1
            if len(cases) < max_evidence:
                cases.append({"type": typ, "entry_ts": key[0], "direction": key[1],
                              "explanation_status": "DIFFERENT_POSITION_LIFECYCLE_UNRESOLVED"})
            continue
        stop_cat_a = _reason_category(a["exit_reason"])
        stop_cat_f = _reason_category(f["exit_reason"])
        exit_delta_s = f["exit_ts"] - a["exit_ts"]
        price_delta_bps = _price_ratio_bps(a["exit_price"], f["exit_price"])
        entry_delta_bps = _price_ratio_bps(a["entry_price"], f["entry_price"])
        if not exit_delta_s and abs(price_delta_bps) <= 1e-6 and abs(entry_delta_bps) <= 1e-6 and stop_cat_a == stop_cat_f:
            reason_counts["MATCHED_IDENTICAL"] += 1
            continue
        if stop_cat_a == stop_cat_f == "stop_family" and exit_delta_s:
            typ = "STOP_TIMING_UNRESOLVED"
        elif stop_cat_a == stop_cat_f == "target_family":
            typ = "ROI_TARGET_SEMANTICS_NEED_RECONCILIATION"
        elif stop_cat_a != stop_cat_f:
            typ = "EXIT_REASON_FAMILY_MISMATCH"
        else:
            typ = "MATCHED_EXECUTION_DIFFERENCE"
        reason_counts[typ] += 1
        if len(cases) >= max_evidence:
            continue
        stop_level = a["entry_price"] * (1 - key[1] * stop_pct)
        max_exit_ts = max(a["exit_ts"], f["exit_ts"])
        first_touch = _expected_stop_touch(by_ts, key[0], max_exit_ts, stop_level, key[1])
        witness_timestamps = set()
        for ts in (key[0], a["exit_ts"], f["exit_ts"], first_touch):
            if ts is not None:
                witness_timestamps.update((ts-60, ts, ts+60))
        # Preserve a bounded raw OHLC witness, never interpolate a future bar.
        witness = [_bar_dict(by_ts[ts]) for ts in sorted(witness_timestamps)
                   if ts in by_ts][:16]
        cases.append({
            "type": typ, "entry_ts": key[0], "direction": key[1],
            "reference_exit_ts": a["exit_ts"], "freqtrade_exit_ts": f["exit_ts"],
            "exit_delta_seconds": exit_delta_s, "entry_delta_bps": entry_delta_bps,
            "exit_delta_bps": price_delta_bps,
            "reference_reason": a["exit_reason"], "freqtrade_reason": f["exit_reason"],
            "reference_stop_level": stop_level,
            "first_reference_stop_touch_ts": first_touch,
            "freqtrade_stop_level": "UNKNOWN_FROM_EXPORT",
            "ohlc_witness": witness,
            "explanation_status": "EVIDENCE_ONLY_NOT_CAUSAL_PROOF",
        })
    return {
        "schema": SCHEMA, "status": "POSTMORTEM_DIAGNOSTIC_NOT_TRADE_PARITY",
        "bars": len(bars), "reference_csv_sha256": reference["csv_sha256"],
        "freqtrade_export_sha256": ft_sha256,
        "strategy": strategy, "pair": pair,
        "compare": {k: v for k, v in compare.items() if k != "sample"},
        "reason_count": dict(sorted(reason_counts.items())),
        "cases_total": sum(reason_counts.values())-reason_counts["MATCHED_IDENTICAL"],
        "cases_included": len(cases), "evidence_truncated": len(cases) < sum(reason_counts.values())-reason_counts["MATCHED_IDENTICAL"],
        "cases": cases,
        "limitations": ["STOP_LOSS_FEE_SEMANTICS_NOT_INFERRED", "FREQTRADE_BAR_TIMESTAMP_CONVENTIONS_NOT_PROVEN",
                        "OHLC_DOES_NOT_ORDER_INTRABAR_TRADES", "NO_EXCHANGE_EXECUTION_PARITY", "NO_ORDERS"],
        "live_orders": False,
    }


def diagnose_files(csv: Path, *, kind: str, fee: float, slippage: float,
                   long_only: bool, ft_export: Path, strategy: str, pair: str,
                   max_evidence: int = 100) -> dict:
    from .execution_compare import reference_from_file, parse_freqtrade_trades

    reference = reference_from_file(csv, kind=kind, fee=fee, slippage=slippage, long_only=long_only)
    trades = parse_freqtrade_trades(ft_export, strategy=strategy, pair=pair)
    return diagnose(reference, trades, read_csv(csv),
                    ft_sha256=sha256(ft_export.read_bytes()).hexdigest(),
                    strategy=strategy, pair=pair, max_evidence=max_evidence)
