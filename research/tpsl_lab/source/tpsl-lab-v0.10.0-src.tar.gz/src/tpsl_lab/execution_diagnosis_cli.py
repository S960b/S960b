"""Offline, read-only discrepancy evidence exporter. No exchange or order APIs."""
from __future__ import annotations
import argparse
from hashlib import sha256
import json
from pathlib import Path

from .execution_diagnosis import diagnose_files


def main(argv=None):
    p = argparse.ArgumentParser(description="Offline postmortem on Freqtrade backtest execution differences")
    p.add_argument("--csv", required=True, type=Path)
    p.add_argument("--ft-export", required=True, type=Path)
    p.add_argument("--kind", required=True, choices=["ema", "donchian"])
    p.add_argument("--ft-strategy", required=True)
    p.add_argument("--ft-pair", default="BTC/USDT")
    p.add_argument("--fee", type=float, default=.0005)
    p.add_argument("--slippage", type=float, default=0.0)
    p.add_argument("--long-only", action="store_true")
    p.add_argument("--ft-config", type=Path, help="Hash this pinned local config, without exporting its content")
    p.add_argument("--freqtrade-commit", help="Recorded, pinned 40-digit Git SHA")
    p.add_argument("--max-evidence", type=int, default=100)
    p.add_argument("--out", required=True, type=Path)
    args=p.parse_args(argv)
    if args.out.exists():
        p.error("refusing to overwrite output")
    if args.freqtrade_commit is not None:
        import re
        if not re.fullmatch(r"[0-9a-f]{40}", args.freqtrade_commit):
            p.error("freqtrade-commit must be a 40-digit lowercase Git SHA")
    report=diagnose_files(args.csv, kind=args.kind, fee=args.fee, slippage=args.slippage,
                          long_only=args.long_only, ft_export=args.ft_export,
                          strategy=args.ft_strategy, pair=args.ft_pair,
                          max_evidence=args.max_evidence)
    report["freqtrade_commit"] = args.freqtrade_commit
    report["freqtrade_config_sha256"] = sha256(args.ft_config.read_bytes()).hexdigest() if args.ft_config else None
    with args.out.open("x", encoding="utf-8") as f:
        json.dump(report,f,indent=2,sort_keys=True,allow_nan=False)
        f.write("\n")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
