"""Preregistered OFFLINE long-only SPOT BTC/ETH TP/SL research.

No network, exchange API, broker, Freqtrade backtesting or holdout access.
Train (2024-04..06) first; once-frozen train top candidates are evaluated on
validation (2025-04..06). The 2026 holdout is NOT loadable through this tool.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import math
import re
import stat
import zipfile
from calendar import monthrange
from dataclasses import dataclass
from datetime import datetime, timezone
from itertools import product
from pathlib import Path

from .engine import replay
from .entry_signals import strategy_factory
from .model import Candle, Costs, Settings

SCHEMA = 'tpsl-lab/spot-preregistered-study-v1'
SPLITS = {
    'train': ('2024-04','2024-05','2024-06'),
    'validation': ('2025-04','2025-05','2025-06'),
}
HOLDOUT_MONTHS = ('2026-07','2026-08','2026-09')
SYMBOLS = ('BTCUSDT','ETHUSDT')
TP_GRID = (0.005,0.01,0.02)
SL_GRID = (0.005,0.01,0.02)
RULES = ('ema','donchian')
BASELINE_COST = Costs(taker_fee=0.0005, slippage=0.0001)
STRESS_COST = Costs(taker_fee=0.001, slippage=0.0003)
NOMINAL = 100.0
EQUITY = 1000.0
MIN_TRADES_PER_SYMBOL = 30
MAX_SELECTED = 3
MAX_UNCOMPRESSED = 200_000_000
MAX_RATIO = 400.0
MAX_REPORT_OUTPUT = 5_000_000


def _sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def _find_exact(root: Path, name: str) -> Path:
    if not root.is_dir() or root.is_symlink():
        raise ValueError('data root must be a real directory')
    matches = [p for p in root.rglob(name) if p.name == name]
    if len(matches) != 1:
        raise ValueError(f'expected exactly one input named {name}, got {len(matches)}')
    p = matches[0]
    if not p.is_file() or p.is_symlink() or not p.resolve().is_relative_to(root.resolve()):
        raise ValueError('unsafe input path')
    return p


def _checksum_expected(raw: bytes, filename: str) -> str:
    try:
        data = raw.decode('ascii').strip()
    except UnicodeDecodeError as e:
        raise ValueError('checksum is not ASCII') from e
    parts = data.split()
    if len(parts) != 2 or not re.fullmatch(r'[0-9a-fA-F]{64}', parts[0]) or parts[1].lstrip('*') != filename:
        raise ValueError('official CHECKSUM format/name mismatch')
    return parts[0].lower()


def _utc_start(month: str) -> int:
    year, num = [int(v) for v in month.split('-')]
    return int(datetime(year, num, 1, tzinfo=timezone.utc).timestamp())


def _scale(month: str) -> int:
    return 1000 if month < '2025-01' else 1_000_000


def read_spot_month(root: Path, symbol: str, month: str) -> tuple[list[Candle],dict]:
    """Strict monthly ZIP and official sidecar CHECKSUM validation. Fail closed."""
    if symbol not in SYMBOLS or month not in SPLITS['train']+SPLITS['validation']:
        raise ValueError('unauthorized symbol/month: HOLDOUT is sealed')
    year,num=map(int,month.split('-'))
    bars_expected=monthrange(year,num)[1]*1440
    name=f'{symbol}-1m-{month}.zip'
    zipped=_find_exact(root,name)
    check=_find_exact(root,name+'.CHECKSUM')
    expected_sha=_checksum_expected(check.read_bytes(),name)
    data=zipped.read_bytes()
    digest=_sha256_bytes(data)
    if expected_sha!=digest:
        raise ValueError(f'SHA256 mismatch {name}')
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        entries=z.infolist()
        if len(entries)!=1:
            raise ValueError('expected exactly one CSV ZIP member')
        info=entries[0]
        if (info.filename!=name[:-4]+'.csv' or info.is_dir() or '..' in info.filename
                or '/' in info.filename or '\\' in info.filename or info.flag_bits & 1
                or stat.S_ISLNK((info.external_attr >> 16) & 0xffff)
                or info.file_size > MAX_UNCOMPRESSED
                or info.file_size / max(info.compress_size,1) > MAX_RATIO):
            raise ValueError('unsafe ZIP member')
        if info.file_size<=0:
            raise ValueError('empty CSV')
        payload=z.read(info)
    if len(payload)!=info.file_size:
        raise ValueError('CSV length mismatch')
    start=_utc_start(month)
    scale=_scale(month)
    result=[]
    try:
        reader=csv.reader(io.StringIO(payload.decode('utf8'),newline=''))
        for i,row in enumerate(reader):
            if i>=bars_expected:
                raise ValueError('more bars than UTC calendar month')
            if len(row)!=12 or not row[0].isdecimal():
                raise ValueError(f'invalid Binance 12-column kline at row {i}')
            rawts=int(row[0])
            expected_ts=(start+i*60)*scale
            if rawts!=expected_ts:
                raise ValueError(f'noncontiguous or misaligned {month} at row {i}')
            result.append(Candle(start+i*60,*[float(s) for s in row[1:6]]))
    except (UnicodeDecodeError,csv.Error,OverflowError) as e:
        raise ValueError('invalid kline CSV') from e
    if len(result)!=bars_expected:
        raise ValueError(f'incomplete {month}: {len(result)} != {bars_expected}')
    provenance={
        'symbol':symbol,'month':month,'zip_name':name,'zip_sha256':digest,
        'official_checksum_sha256':expected_sha,'csv_sha256':_sha256_bytes(payload),
        'rows':len(result),'scale':'ms' if scale==1000 else 'us',
        'first_ts':result[0].ts,'last_ts':result[-1].ts,
    }
    return result,provenance


def load_split(root: Path, split: str) -> tuple[dict[str,list[Candle]],list[dict]]:
    if split not in SPLITS:
        raise ValueError('train/validation ONLY — 2026 HOLDOUT is sealed')
    series={}
    prov=[]
    for symbol in SYMBOLS:
        all_bars=[]
        for month in SPLITS[split]:
            bars,p=read_spot_month(root,symbol,month)
            if all_bars and bars[0].ts!=all_bars[-1].ts+60:
                raise ValueError('cross-month gap')
            all_bars.extend(bars)
            prov.append(p)
        series[symbol]=all_bars
    return series,prov


class LongOnly:
    """Research SPOT-only wrapper; shorts are silently never opened."""
    def __init__(self, kind: str, seed: int = 7):
        self.inner=strategy_factory(kind,seed=seed,probability=0.02)

    def on_close(self,bar:Candle)->int:
        s=self.inner.on_close(bar)
        return 1 if s==1 else 0


def config_id(kind: str,tp: float,sl: float)->str:
    if kind not in RULES or tp not in TP_GRID or sl not in SL_GRID:
        raise ValueError('config outside preregistered grid')
    return f'{kind}_tp{round(tp*10000):03d}_sl{round(sl*10000):03d}'


def _configs() -> list[dict]:
    return [{'id':config_id(kind,tp,sl),'entry_rule':kind,'tp_pct':tp,'sl_pct':sl}
            for kind,tp,sl in product(RULES,TP_GRID,SL_GRID)]


def _replay_summary(bars:list[Candle],kind:str,tp:float,sl:float,costs:Costs,seed=7)->dict:
    settings=Settings(starting_equity=EQUITY,notional=NOMINAL,tp_pct=tp,sl_pct=sl)
    r=replay(bars,LongOnly(kind,seed),settings,costs)
    if r['open_position'] is not None and r['open_position']['direction']!=1:
        raise ValueError('short unexpectedly executed in spot-only study')
    return {
        'closed_trades':r['closed_trades'],'wins':r['winning_trades'],
        'win_rate':r['win_rate'],'net_marked_usdt':round(r['marked_equity']-EQUITY,8),
        'marked_equity_usdt':round(r['marked_equity'],8),
        'closed_equity_usdt':round(r['closed_equity'],8),
        'open_position_at_end':r['open_position'] is not None,
        'fee_usdt':round(r['total_fees'],8),
        'max_drawdown':round(r['max_mark_to_market_drawdown'],8),
        'ambiguous_stop_first':r['ambiguous_bars_closed_at_stop'],
    }


def _fixed_baselines(series:dict[str,list[Candle]])->dict:
    out={}
    for symbol,bars in series.items():
        out[symbol]={}
        for kind,seed in [('never',7),('random',7),('random',17),('random',29)]:
            label=kind if kind=='never' else f'random_seed_{seed}'
            out[symbol][label]=_replay_summary(bars,kind,0.01,0.01,BASELINE_COST,seed)
    return out


def _plan_metadata() ->dict:
    return {
        'train_months':list(SPLITS['train']),'validation_months':list(SPLITS['validation']),
        'holdout_months_not_read':list(HOLDOUT_MONTHS),
        'symbols':list(SYMBOLS),'entry_rules':list(RULES),
        'tp_grid':list(TP_GRID),'sl_grid':list(SL_GRID),
        'baseline_cost':{'fee_per_side':BASELINE_COST.taker_fee,'adverse_slippage_per_side':BASELINE_COST.slippage},
        'stress_cost':{'fee_per_side':STRESS_COST.taker_fee,'adverse_slippage_per_side':STRESS_COST.slippage},
        'starting_equity_usdt':EQUITY,'position_notional_usdt':NOMINAL,
        'min_closed_trades_per_symbol':MIN_TRADES_PER_SYMBOL,
        'selection_rule':'positive marked PnL BOTH assets, min 30 closed trades EACH; top 3 worst-asset marked PnL; deterministic tie break',
        'research_scope':'SPOT LONG ONLY, unlevered reference proxy; not real executable returns',
        'restrictions':['HOLDOUT_NEVER_READ','NO_SHORTS','NO_FUNDING','NO_LEVERAGE',
                        'NO_EXCHANGE_ORDERS','NO_NETWORK','NO_PNL_CLAIM_BEYOND_SCENARIOS'],
    }


def _select(items:list[dict])->list[str]:
    ok=[]
    for item in items:
        results=item['by_symbol']
        if not all(results[s]['closed_trades']>=MIN_TRADES_PER_SYMBOL
                   and results[s]['net_marked_usdt']>0 for s in SYMBOLS):
            continue
        worst=min(results[s]['net_marked_usdt'] for s in SYMBOLS)
        dd=max(results[s]['max_drawdown'] for s in SYMBOLS)
        ok.append(( -worst,dd,item['id']))
    ok.sort()
    return [x[2] for x in ok[:MAX_SELECTED]]


def train(root:Path)->dict:
    series,provenance=load_split(root,'train')
    items=[]
    for cfg in _configs():
        results={s:_replay_summary(series[s],cfg['entry_rule'],cfg['tp_pct'],cfg['sl_pct'],BASELINE_COST)
                 for s in SYMBOLS}
        items.append({**cfg,'by_symbol':results})
    winners=_select(items)
    return {
        'schema':SCHEMA,'stage':'train','plan':_plan_metadata(),
        'data_provenance':provenance,'config_results':items,
        'selected_config_ids':winners,'selected_count':len(winners),
        'controls':_fixed_baselines(series),
        'validation_unseen':True,'holdout_unseen':True,
        'notes':['Selection is in-sample only. Positive TRAIN is NOT evidence of future profit.',
                 'If no eligible configuration: do NOT run validation or tune based on validation.'],
    }


def _verify_train_report(t:dict)->list[dict]:
    if not isinstance(t,dict) or t.get('schema')!=SCHEMA or t.get('stage')!='train':
        raise ValueError('invalid train report')
    if t.get('plan')!=_plan_metadata() or t.get('holdout_unseen') is not True:
        raise ValueError('research preregistration mismatch')
    cfgs=t.get('config_results')
    if not isinstance(cfgs,list) or len(cfgs)!=len(_configs()):
        raise ValueError('train grid mismatch')
    expected=_configs()
    if any({k:item.get(k) for k in ('id','entry_rule','tp_pct','sl_pct')} !=c
           for item,c in zip(cfgs,expected)):
        raise ValueError('train configs modified')
    selected=_select(cfgs)
    if selected!=t.get('selected_config_ids'):
        raise ValueError('train selection altered')
    return [c for c in expected if c['id'] in selected]


def validate(root:Path,t:dict,train_sha256:str)->dict:
    chosen=_verify_train_report(t)
    if not chosen:
        raise ValueError('NO_ELIGIBLE_TRAIN_CANDIDATES: validation intentionally blocked')
    series,provenance=load_split(root,'validation')
    candidates=[]
    for cfg in chosen:
        per_symbol={s:{
            'baseline':_replay_summary(series[s],cfg['entry_rule'],cfg['tp_pct'],cfg['sl_pct'],BASELINE_COST),
            'stress':_replay_summary(series[s],cfg['entry_rule'],cfg['tp_pct'],cfg['sl_pct'],STRESS_COST),
        } for s in SYMBOLS}
        candidates.append({**cfg,'by_symbol':per_symbol})
    return {'schema':SCHEMA,'stage':'validation','plan':_plan_metadata(),
            'train_report_sha256':train_sha256,'selected_config_ids':t['selected_config_ids'],
            'data_provenance':provenance,'candidate_results':candidates,
            'controls':_fixed_baselines(series),
            'holdout_unseen':True,'notes':['Validation is one prespecified out-of-sample check.',
                'Do NOT select a new configuration on validation results.',
                'Do not run final holdout without a separately preregistered final selection.']}


def main(argv=None):
    p=argparse.ArgumentParser(description='Offline preregistered SPOT long-only TP/SL study; NO HOLDOUT')
    p.add_argument('--stage',choices=['train','validation'],required=True)
    p.add_argument('--data-root',type=Path,required=True)
    p.add_argument('--train-report',type=Path,help='Required for validation')
    p.add_argument('--out',type=Path,required=True)
    a=p.parse_args(argv)
    if a.out.exists():
        raise FileExistsError('refuse to overwrite research output')
    if not a.out.parent.is_dir():
        raise ValueError('output directory must exist')
    if a.stage=='train':
        if a.train_report:
            p.error('train-report is only for validation')
        report=train(a.data_root)
    else:
        if not a.train_report:
            p.error('validation requires --train-report')
        raw=a.train_report.read_bytes()
        report=validate(a.data_root,json.loads(raw),_sha256_bytes(raw))
    data=(json.dumps(report,ensure_ascii=False,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()
    if len(data)>MAX_REPORT_OUTPUT:
        raise ValueError('report size limit exceeded')
    with a.out.open('xb') as f:
        f.write(data)
    print(json.dumps({'stage':report['stage'],'output':str(a.out),
                      'sha256':_sha256_bytes(data),'selected':report.get('selected_config_ids'),
                      'symbols':list(SYMBOLS),'holdout_unseen':True},sort_keys=True))

if __name__=='__main__':
    main()
