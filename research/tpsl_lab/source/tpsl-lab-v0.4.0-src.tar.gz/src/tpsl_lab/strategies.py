"""Streaming strategies: no future bars are visible to the decision process."""
import random
from .model import Candle


class NeverEntry:
    def on_close(self, candle: Candle) -> int:
        return 0


class RandomEntry:
    def __init__(self, seed: int = 7, probability: float = 0.02):
        if not 0 <= probability <= 1:
            raise ValueError("probability outside [0, 1]")
        self.rng = random.Random(seed)
        self.probability = probability

    def on_close(self, candle: Candle) -> int:
        if self.rng.random() >= self.probability:
            return 0
        return 1 if self.rng.random() < 0.5 else -1


class EmaTrend:
    """Warm up with EMA of first close; enter in trend after slow-period bars."""
    def __init__(self, fast: int = 50, slow: int = 200):
        if not 1 <= fast < slow:
            raise ValueError("require 1 <= fast < slow")
        self.fast_alpha = 2.0 / (fast + 1)
        self.slow_alpha = 2.0 / (slow + 1)
        self.slow_period = slow
        self.fast_value = None
        self.slow_value = None
        self.count = 0

    def on_close(self, candle: Candle) -> int:
        self.count += 1
        self.fast_value = (candle.close if self.fast_value is None else
                           self.fast_alpha * candle.close + (1 - self.fast_alpha) * self.fast_value)
        self.slow_value = (candle.close if self.slow_value is None else
                           self.slow_alpha * candle.close + (1 - self.slow_alpha) * self.slow_value)
        if self.count < self.slow_period:
            return 0
        if candle.close > self.fast_value > self.slow_value:
            return 1
        if candle.close < self.fast_value < self.slow_value:
            return -1
        return 0
