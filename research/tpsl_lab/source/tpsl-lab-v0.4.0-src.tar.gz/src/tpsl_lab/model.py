"""Validated immutable market data and trade records."""
from dataclasses import dataclass
from math import isfinite


@dataclass(frozen=True)
class Candle:
    ts: int  # UTC open time, seconds since Unix epoch
    open: float
    high: float
    low: float
    close: float
    volume: float = 0.0

    def __post_init__(self):
        prices = (self.open, self.high, self.low, self.close)
        if type(self.ts) is not int or self.ts < 0:
            raise ValueError("timestamp must be nonnegative integer UTC seconds")
        if any(not isfinite(x) or x <= 0 for x in prices):
            raise ValueError("prices must be finite and positive")
        if self.high < max(self.open, self.close, self.low):
            raise ValueError("high smaller than candle prices")
        if self.low > min(self.open, self.close, self.high):
            raise ValueError("low greater than candle prices")
        if not isfinite(self.volume) or self.volume < 0:
            raise ValueError("volume must be finite and nonnegative")


@dataclass(frozen=True)
class Costs:
    taker_fee: float = 0.0005  # each side; scenario assumption, not an account quote
    slippage: float = 0.0001  # each side, adverse; scenario assumption

    def __post_init__(self):
        if any(not isfinite(x) or not 0 <= x < 0.1 for x in (self.taker_fee, self.slippage)):
            raise ValueError("invalid cost assumptions")


@dataclass(frozen=True)
class Settings:
    starting_equity: float = 1000.0
    notional: float = 100.0
    tp_pct: float = 0.01
    sl_pct: float = 0.005
    bar_seconds: int = 60

    def __post_init__(self):
        if any(not isfinite(x) or x <= 0 for x in (self.starting_equity, self.notional, self.tp_pct, self.sl_pct)):
            raise ValueError("settings must be finite positive")
        if not 0 < self.tp_pct < 1 or not 0 < self.sl_pct < 1:
            raise ValueError("TP and SL must be price fractions less than 1")
        if type(self.bar_seconds) is not int or self.bar_seconds < 1:
            raise ValueError("bar_seconds must be positive integer")


@dataclass(frozen=True)
class Trade:
    entry_ts: int
    exit_ts: int
    direction: int  # long +1 / short -1
    quantity: float
    entry_price: float
    exit_price: float
    entry_fee: float
    exit_fee: float
    gross_pnl: float
    net_pnl: float
    exit_reason: str
    ambiguous: bool


@dataclass
class Position:
    entry_ts: int
    direction: int
    quantity: float
    entry_price: float
    entry_fee: float
    stop: float
    target: float
