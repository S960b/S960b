"""Deterministic reference replay; NOT a futures liquidation or order-book simulator.

A signal is generated only on a completed candle, and may fill at the NEXT
candle open. Adverse slippage applies to both entry and exit. If a candle
hits stop and target, STOP has priority; count these as ambiguous. The stop
may fill worse when the candle opens beyond it. No live exchange API exists.
"""
from dataclasses import asdict
from .model import Candle, Costs, Position, Settings, Trade


def _fill(reference: float, direction: int, slip: float) -> float:
    """direction +1 buy, -1 sell; slippage must be against the trader."""
    return reference * (1 + direction * slip)


def _exit_check(bar: Candle, pos: Position, slip: float):
    """Return (execution price, reason, ambiguous) or None."""
    if pos.direction == 1:
        if bar.open <= pos.stop:
            return _fill(bar.open, -1, slip), "stop_gap", False
        if bar.open >= pos.target:
            return _fill(pos.target, -1, slip), "target_gap", False
        stop_hit, target_hit = bar.low <= pos.stop, bar.high >= pos.target
        if stop_hit:
            return _fill(pos.stop, -1, slip), "stop", target_hit
        if target_hit:
            return _fill(pos.target, -1, slip), "target", False
    else:
        if bar.open >= pos.stop:
            return _fill(bar.open, +1, slip), "stop_gap", False
        if bar.open <= pos.target:
            return _fill(pos.target, +1, slip), "target_gap", False
        stop_hit, target_hit = bar.high >= pos.stop, bar.low <= pos.target
        if stop_hit:
            return _fill(pos.stop, +1, slip), "stop", target_hit
        if target_hit:
            return _fill(pos.target, +1, slip), "target", False
    return None


def replay(bars: list[Candle], strategy, settings: Settings = Settings(), costs: Costs = Costs()) -> dict:
    """Run OFFLINE. No leverage, funding, liquidation, maker orders or network.

    A fresh strategy instance is required for each run (its state is mutable).
    Missing time intervals fail closed; no order is synthesized across gaps.
    """
    if len(bars) < 2:
        raise ValueError("need at least two candles")
    for i, bar in enumerate(bars):
        if bar.ts % settings.bar_seconds:
            raise ValueError(f"misaligned candle: {i}")
        if i and bar.ts - bars[i-1].ts != settings.bar_seconds:
            raise ValueError(f"missing, duplicated or unordered candle at index {i}")

    equity = settings.starting_equity
    highest_equity = equity
    max_drawdown = 0.0
    pos = None
    pending = 0
    trades: list[Trade] = []
    fees = 0.0
    max_open_risk = 0.0

    for bar in bars:
        # First execute last bar's signal at this bar's OPEN; never at signal close.
        if pos is None and pending:
            entry_price = _fill(bar.open, pending, costs.slippage)
            # One unlevered position only: no borrowed notional or margin claims.
            if settings.notional * (1 + costs.taker_fee) <= equity:
                qty = settings.notional / entry_price
                entry_fee = qty * entry_price * costs.taker_fee
                equity -= entry_fee
                fees += entry_fee
                target = entry_price * (1 + pending * settings.tp_pct)
                stop = entry_price * (1 - pending * settings.sl_pct)
                pos = Position(bar.ts, pending, qty, entry_price, entry_fee, stop, target)
                max_open_risk = max(max_open_risk, settings.notional * (settings.sl_pct + costs.taker_fee * 2 + costs.slippage * 2))
        pending = 0

        if pos is not None:
            exit_event = _exit_check(bar, pos, costs.slippage)
            if exit_event is not None:
                exit_price, reason, ambiguous = exit_event
                exit_fee = pos.quantity * exit_price * costs.taker_fee
                gross = pos.direction * pos.quantity * (exit_price - pos.entry_price)
                equity += gross - exit_fee
                fees += exit_fee
                trades.append(Trade(pos.entry_ts, bar.ts, pos.direction, pos.quantity,
                                    pos.entry_price, exit_price, pos.entry_fee, exit_fee,
                                    gross, gross - pos.entry_fee - exit_fee, reason, ambiguous))
                pos = None

        # Conservative marked equity at close, including expected exit fee.
        marked_equity = equity
        if pos is not None:
            marked_equity += pos.direction * pos.quantity * (bar.close - pos.entry_price)
            marked_equity -= pos.quantity * bar.close * costs.taker_fee
        highest_equity = max(highest_equity, marked_equity)
        max_drawdown = max(max_drawdown, (highest_equity - marked_equity) / highest_equity)

        signal = strategy.on_close(bar)
        if type(signal) is not int or signal not in (-1, 0, 1):
            raise ValueError("strategy signal must be -1, 0 or +1")
        if pos is None:
            pending = signal

    net_pnl = sum(t.net_pnl for t in trades)
    return {
        "schema": "tpsl-lab/v0.1", "mode": "offline_unlevered_reference_only",
        "limitations": ["NO_FUNDING", "NO_LIQUIDATION", "NO_ORDERBOOK", "NO_REAL_ORDERS"],
        "bars": len(bars), "first_ts": bars[0].ts, "last_ts": bars[-1].ts,
        "starting_equity": settings.starting_equity, "closed_equity": equity,
        "marked_equity": marked_equity, "open_position": asdict(pos) if pos else None,
        "closed_trades": len(trades), "winning_trades": sum(t.net_pnl > 0 for t in trades),
        "win_rate": sum(t.net_pnl > 0 for t in trades) / len(trades) if trades else None,
        "net_pnl_closed": net_pnl, "total_fees": fees,
        "max_mark_to_market_drawdown": max_drawdown,
        "ambiguous_bars_closed_at_stop": sum(t.ambiguous for t in trades),
        "nominal_stop_risk_estimate_not_guaranteed": max_open_risk,
        "trades": [asdict(t) for t in trades],
    }
