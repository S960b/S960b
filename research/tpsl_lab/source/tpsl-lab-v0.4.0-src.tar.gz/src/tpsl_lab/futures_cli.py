"""Explicitly offline futures risk PROXY. Cannot connect to Binance or place orders."""
import argparse
import json
from pathlib import Path
from .futures import FuturesSettings, replay_futures
from .futures_io import read_binance_funding, read_tiers
from .io import read_csv
from .model import Costs
from .strategies import EmaTrend, NeverEntry, RandomEntry


def main(argv=None):
    p = argparse.ArgumentParser(description='OFFLINE / NO-ORDERS / futures risk proxy; not production-ready')
    p.add_argument('--price-csv', required=True, type=Path)
    p.add_argument('--mark-csv', required=True, type=Path)
    p.add_argument('--binance', action='store_true', help='both inputs use Binance 12-column klines')
    p.add_argument('--funding-json', required=True, type=Path)
    p.add_argument('--symbol', choices=['BTCUSDT', 'ETHUSDT'], help='validate funding JSON symbol, if provided')
    p.add_argument('--tiers-json', required=True, type=Path, help='explicit margin tier scenario, NOT guaranteed Binance history')
    p.add_argument('--strategy', choices=['never','random','ema'], default='never')
    p.add_argument('--seed', type=int, default=7)
    p.add_argument('--probability', type=float, default=0.02)
    p.add_argument('--fast', type=int, default=50)
    p.add_argument('--slow', type=int, default=200)
    p.add_argument('--equity', type=float, default=1000.0)
    p.add_argument('--notional', type=float, default=100.0)
    p.add_argument('--leverage', type=float, default=2.0)
    p.add_argument('--tp', type=float, default=0.01)
    p.add_argument('--sl', type=float, default=0.005)
    p.add_argument('--fee', type=float, default=0.0005)
    p.add_argument('--slippage', type=float, default=0.0001)
    p.add_argument('--liquidation-reserve', type=float, default=0.005)
    p.add_argument('--bar-seconds', type=int, default=60)
    p.add_argument('--out', type=Path)
    a = p.parse_args(argv)
    bars = read_csv(a.price_csv, a.binance)
    marks = read_csv(a.mark_csv, a.binance)
    if not bars:
        p.error('empty price data')
    tape = read_binance_funding(a.funding_json, bars[0].ts, bars[-1].ts+a.bar_seconds, a.symbol)
    strategy = (NeverEntry() if a.strategy=='never' else
                RandomEntry(a.seed,a.probability) if a.strategy=='random' else
                EmaTrend(a.fast,a.slow))
    result = replay_futures(bars, marks, strategy, tape, read_tiers(a.tiers_json),
                   FuturesSettings(a.equity,a.notional,a.leverage,a.tp,a.sl,a.bar_seconds,a.liquidation_reserve),
                   Costs(a.fee,a.slippage))
    output = json.dumps(result, indent=2, ensure_ascii=False, allow_nan=False)
    if a.out:
        a.out.parent.mkdir(parents=True,exist_ok=True)
        a.out.write_text(output+'\n',encoding='utf-8')
    else:
        print(output)
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
