"""Independent synthetic invariants for the TRAIN-only signal-information audit."""
from pathlib import Path
import pytest
from tpsl_lab import entry_edge as e
from tpsl_lab.model import Candle


def series(n=3200, price_fn=lambda i:100.0, start=0):
    r=[]
    for i in range(n):
        v=price_fn(i)
        r.append(Candle(start+60*i,v,v,v,v,1.0))
    return r


def test_plan_frozen_train_and_holdout_sealed():
    p=e.plan()
    assert p['source_train_months']==['2024-04','2024-05','2024-06']
    assert p['validation_unseen'] and p['holdout_sealed'] and p['no_orders']
    assert set(p['rules'])=={'ema_cross','donchian_first'}
    assert p['holding_horizons_minutes']==[60,240,1440]


def test_future_window_exact_next_open():
    b=series(1600,lambda i:100+i*.1)
    assert e.gross_return(b,1,60)==pytest.approx(b[61].open/b[1].open-1)


def test_forward_returns_do_not_use_intrabar_high_low():
    b=series(1600)
    b[61]=Candle(b[61].ts,100,150,50,120,1)
    assert e.gross_return(b,1,60)==0


def test_future_window_at_end_rejected():
    b=series()
    with pytest.raises(ValueError,match='no complete'):e.gross_return(b,3200-60,60)


def test_invalid_horizon_rejected():
    with pytest.raises(ValueError,match='outside fixed'):e.gross_return(series(),1,20)


def test_net_return_includes_both_sides():
    assert e._net_return(0,.0005,.0001)==pytest.approx((1-.0006)/(1+.0006)-1)
    assert e._net_return(.02,.0005,.0001)>0


def test_costs_are_never_a_revenue_source():
    assert e._net_return(0,.001,.0003)<e._net_return(0,.0005,.0001)<0


def test_same_day_matching_and_reproducible_report():
    b=series(4*1440,lambda i:100+i*.001)
    a=e.diagnose(b,'donchian_first',1,60,'BTCUSDT')
    c=e.diagnose(b,'donchian_first',1,60,'BTCUSDT')
    assert a==c
    assert a['no_orders'] and a['controls_per_event']==32


def test_no_bars_zero_event_output():
    b=series(2000)
    r=e.diagnose(b,'ema_cross',15,240,'ETHUSDT')
    assert r['event_entries_eligible']==0
    assert r['status']=='INSUFFICIENT_EVENTS'


def test_no_future_modification_changes_previous_signals():
    b=series(3200,lambda i:100+min(i,1900)*.001)
    a=e.event_entry_indices(b,'donchian_first',15)
    edited=b[:]
    for j in range(3000,3200):
        edited[j]=Candle(b[j].ts,b[j].open*1.2,b[j].high*1.2,b[j].low*1.2,b[j].close*1.2,1.0)
    c=e.event_entry_indices(edited,'donchian_first',15)
    assert [j for j in a if j<3000]==[j for j in c if j<3000]


def test_15m_event_entry_timeframe_alignment():
    b=series(3200,lambda i:100+(i//15)*.005)
    r=e.event_entry_indices(b,'donchian_first',15)
    assert all(b[j].ts%(15*60)==0 for j in r)


def test_unaligned_source_rejected():
    with pytest.raises(ValueError,match='UTC day boundary'):
        e.event_entry_indices(series(start=60),'ema_cross',1)


def test_gaps_rejected():
    b=series()
    b[100]=Candle(b[100].ts+60,100,100,100,100,1)
    with pytest.raises(ValueError,match='duplicate 1m'):
        e.event_entry_indices(b,'ema_cross',1)


def test_wrong_symbol_and_rules_rejected():
    with pytest.raises(ValueError,match='outside frozen'):
        e.diagnose(series(),'donchian_first',1,60,'ADAUSDT')
    with pytest.raises(ValueError,match='not preregistered'):
        e.event_entry_indices(series(),'infinite_profit',1)


def test_bootstrap_requires_five_weeks():
    xs=[(60*i,float(i)) for i in range(5)]
    assert e._week_bootstrap_mean_ci(xs,0,1)==(None,None,1)


def test_bootstrap_deterministic_finite():
    xs=[(604800*i+60, float((-1)**i)) for i in range(13)]
    a=e._week_bootstrap_mean_ci(xs,0,777)
    assert a==e._week_bootstrap_mean_ci(xs,0,777)
    assert a[0]<=a[1] and a[2]==13


def test_invalid_cli_stage_rejected_without_input(tmp_path):
    with pytest.raises(SystemExit):
        e.main(['--stage','validation','--data-root',str(tmp_path),'--out',str(tmp_path/'o.json')])


def test_existing_out_refuses_without_reading(tmp_path):
    p=tmp_path/'out.json';p.write_text('DO NOT MODIFY')
    with pytest.raises(FileExistsError):
        e.main(['--stage','train','--data-root',str(tmp_path),'--out',str(p)])
    assert p.read_text()=='DO NOT MODIFY'


def test_exact_report_grid_size():
    p=e.plan()
    assert len(p['symbols'])*len(p['rules'])*len(p['signal_timeframes_minutes'])*len(p['holding_horizons_minutes'])==24


def test_event_with_insufficient_future_is_censored():
    b=series(1600,lambda i:100+((i-1000)%200)*.01)
    rows=e.diagnose(b,'donchian_first',1,1440,'BTCUSDT')
    assert rows['event_entries_total']>=rows['event_entries_eligible']


def test_holdout_not_in_any_allowed_split():
    assert 'holdout' not in e.plan()['source_train_months']
    assert '2026-07' not in e.plan()['source_train_months']
