"""CSV loader for normalized data and 12-column Binance kline archives."""
import csv
from datetime import datetime, timezone
from pathlib import Path
from .model import Candle


def _timestamp(value: str) -> int:
    raw = str(value).strip()
    if raw.isdecimal():
        number = int(raw)
        # Binance archives may use milliseconds or microseconds.
        if number >= 10**14:
            number //= 1_000_000
        elif number >= 10**11:
            number //= 1_000
        return number
    dt = datetime.fromisoformat(raw.replace("Z", "+00:00"))
    if dt.tzinfo is None or dt.utcoffset().total_seconds() != 0:
        raise ValueError("timestamp must be explicitly UTC")
    return int(dt.timestamp())


def read_csv(path: str | Path, binance: bool = False) -> list[Candle]:
    """Read a local uncompressed CSV. Binance: open_time,open,high,low,close,volume,..."""
    result = []
    with open(path, "r", newline="", encoding="utf-8") as f:
        if binance:
            reader = csv.reader(f)
            for row in reader:
                if not row or row[0].lower() == "open_time":
                    continue
                if len(row) < 6:
                    raise ValueError("truncated Binance kline row")
                result.append(Candle(_timestamp(row[0]), *(float(v) for v in row[1:6])))
        else:
            reader = csv.DictReader(f)
            required = {"timestamp", "open", "high", "low", "close", "volume"}
            if not required.issubset(reader.fieldnames or []):
                raise ValueError("CSV requires timestamp,open,high,low,close,volume")
            for row in reader:
                result.append(Candle(_timestamp(row["timestamp"]),
                                     *(float(row[k]) for k in ("open", "high", "low", "close", "volume"))))
    return result
