"""Offline stream/DataFrame signal parity verification (NO Freqtrade needed)."""
import argparse
import hashlib
import json
from pathlib import Path
from .entry_signals import stream_signals, dataframe_signals
from .io import read_csv


def compare(bars, *, kind: str, fast: int = 50, slow: int = 200, lookback: int = 20):
    import pandas as pd
    if not bars:
        raise ValueError('no candles')
    if any(b.ts != bars[0].ts + 60*i for i,b in enumerate(bars)):
        raise ValueError('not contiguous 1m bars')
    kw = dict(fast=fast, slow=slow, lookback=lookback)
    stream = stream_signals(bars, kind, **kw)
    frame = pd.DataFrame([dict(open=b.open,high=b.high,low=b.low,
                    close=b.close,volume=b.volume) for b in bars])
    vector = dataframe_signals(frame, kind, **kw)
    mismatches = [dict(index=i,ts=bars[i].ts,stream=stream[i],vector=vector[i])
                  for i in range(len(bars)) if stream[i]!=vector[i]]
    return dict(schema='tpsl-lab/signal-parity-v1',only_complete_bar_data=True,
                no_orders=True,kind=kind,bars=len(bars),matches=len(bars)-len(mismatches),
                mismatch_count=len(mismatches),mismatch_sample=mismatches[:20],
                long_count=stream.count(1),short_count=stream.count(-1),
                first_bar_ts=bars[0].ts,last_bar_ts=bars[-1].ts)


def main(argv=None):
    p=argparse.ArgumentParser(description='Offline Freqtrade-compatible signal parity; no orders')
    p.add_argument('--csv',required=True,type=Path)
    p.add_argument('--binance',action='store_true')
    p.add_argument('--strategy',choices=['ema','donchian','never'],required=True)
    p.add_argument('--fast',type=int,default=50)
    p.add_argument('--slow',type=int,default=200)
    p.add_argument('--lookback',type=int,default=20)
    p.add_argument('--out',type=Path)
    a=p.parse_args(argv)
    bars=read_csv(a.csv,a.binance)
    result=compare(bars,kind=a.strategy,fast=a.fast,slow=a.slow,lookback=a.lookback)
    result['input_sha256']=hashlib.sha256(a.csv.read_bytes()).hexdigest()
    doc=json.dumps(result,sort_keys=True,indent=2,allow_nan=False)+'\n'
    if a.out:
        with a.out.open('x',encoding='utf-8') as f: f.write(doc)
    else:
        print(doc)
    return 0 if not result['mismatch_count'] else 2

if __name__=='__main__':
    raise SystemExit(main())
