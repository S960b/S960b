"""Black-box funding timestamp tests, including MT's historical +1ms observation."""
import json
import pytest
from tpsl_lab.futures import FundingEvent, FundingTape, MarginTier, FuturesSettings, replay_futures
from tpsl_lab.futures_io import read_binance_funding
from tpsl_lab.model import Candle, Costs
from tpsl_lab.strategies import NeverEntry


class Entry:
    def __init__(self, direction=1):
        self.direction=direction
        self.calls=0
    def on_close(self, candle):
        self.calls+=1
        return self.direction if self.calls==1 else 0


def c(t,op=100,hi=None,lo=None):
    return Candle(t,op,op if hi is None else hi,op if lo is None else lo,op)


def run(bars, events=(), direction=1, marks=None):
    return replay_futures(bars,marks or bars,Entry(direction),
        FundingTape(tuple(events),bars[0].ts,bars[-1].ts+60,'test-fixture'),
        (MarginTier(0,1000000,.005,0,20),),
        FuturesSettings(position_notional=100,leverage=2,tp_pct=.02,
                        sl_pct=.01,liquidation_fee_reserve_rate=0),Costs(0,0))


def test_loader_preserves_real_binance_ms_and_excludes_end_api_inclusive(tmp_path):
    start=1717200000; end=start+86400
    t=1717257600001 # 2024-06-01 16:00:00.001
    rows=[{'symbol':'BTCUSDT','fundingTime':t,'fundingRate':'0.00010250','markPrice':'67722.94709929'},
          {'symbol':'BTCUSDT','fundingTime':end*1000,'fundingRate':'0.0001','markPrice':'67799.3'}]
    path=tmp_path/'f.json';path.write_text(json.dumps(rows))
    got=read_binance_funding(path,start,end,expected_symbol='BTCUSDT')
    assert len(got.events)==1
    assert got.events[0].ts==1717257600
    assert got.events[0].exact_ms==t
    assert 'end_boundary_excluded=1' in got.source
    assert got.events[0].rate==pytest.approx(.0001025)


def test_loader_reject_wrong_symbol(tmp_path):
    p=tmp_path/'f.json'
    p.write_text(json.dumps([{'symbol':'ETHUSDT','fundingTime':120001,'fundingRate':'0.001','markPrice':'100'}]))
    with pytest.raises(ValueError,match='symbol'):
        read_binance_funding(p,0,180,expected_symbol='BTCUSDT')


def test_loader_reject_unexpected_range_and_bad_timestamp(tmp_path):
    p=tmp_path/'f.json'
    for t in (1000.5, True, '-1000', 'not-a-date'):
        p.write_text(json.dumps([{'fundingTime':t,'fundingRate':'.001','markPrice':'100'}]))
        with pytest.raises(ValueError,match='fundingTime'):
            read_binance_funding(p,0,180)
    p.write_text(json.dumps([{'fundingTime':200000,'fundingRate':'.001','markPrice':'100'}]))
    with pytest.raises(ValueError,match='outside'):
        read_binance_funding(p,0,180)


def test_delayed_funding_applies_when_position_stays_open():
    bars=[c(0),c(60),c(120),c(180)]
    e=FundingEvent(120,.001,100,ts_ms=120001)
    r=run(bars,(e,))
    assert r['funding_cashflow']==pytest.approx(-.1)
    assert r['funding_timestamps_ms']==[120001]
    f=[x for x in r['events'] if x['kind']=='funding'][0]
    assert f['funding_ts_ms']==120001 and f['offset_ms']==1


def test_delayed_funding_no_charge_if_stop_at_open_before_event():
    bars=[c(0),c(60),c(120,op=98),c(180,op=98)]
    e=FundingEvent(120,.001,100,ts_ms=120001)
    r=run(bars,(e,))
    assert r['funding_cashflow']==0
    assert r['trades'][0]['reason']=='stop_gap'
    assert any(x['kind']=='funding_excluded_after_open_exit' for x in r['events'])


def test_delayed_funding_credit_with_intra_bar_exit_suppressed():
    # Short gets positive funding, but could hit stop before funding at +1ms.
    bars=[c(0),c(60),c(120,op=100,hi=102,lo=100),c(180)]
    e=FundingEvent(120,.001,100,ts_ms=120001)
    r=run(bars,(e,),direction=-1)
    assert r['funding_cashflow']==0
    assert any(x.get('boundary_credit_suppressed') for x in r['events'])


def test_delayed_funding_debit_with_intra_bar_exit_applied_worst_case():
    bars=[c(0),c(60),c(120,op=100,hi=100,lo=99),c(180)]
    e=FundingEvent(120,.001,100,ts_ms=120001)
    r=run(bars,(e,),direction=1)
    assert r['funding_cashflow']==pytest.approx(-.1)
    assert r['trades'][0]['reason']=='stop'


def test_delayed_funding_entry_can_receive_credit_only_if_held():
    bars=[c(0),c(60),c(120)]
    e=FundingEvent(60,.001,100,ts_ms=60001)
    r=run(bars,(e,),direction=-1)
    assert r['funding_cashflow']==pytest.approx(.1)


def test_delayed_funding_entry_credit_suppressed_if_intrabar_stop_possible():
    bars=[c(0),c(60,op=100,hi=101.5,lo=100),c(120)]
    e=FundingEvent(60,.001,100,ts_ms=60001)
    r=run(bars,(e,),direction=-1)
    assert r['funding_cashflow']==0
    assert r['trades'][0]['reason']=='stop'


def test_exact_second_entry_credit_still_suppressed():
    bars=[c(0),c(60),c(120)]
    assert run(bars,(FundingEvent(60,.001,100),),direction=-1)['funding_cashflow']==0


def test_intrabar_funding_outside_first_second_fails_closed():
    bars=[c(0),c(60),c(120)]
    with pytest.raises(ValueError,match='intrabar funding'):
        run(bars,(FundingEvent(61,.001,100,ts_ms=61000),))


def test_duplicate_same_bar_fails_closed():
    bars=[c(0),c(60),c(120)]
    with pytest.raises(ValueError,match='multiple funding'):
        run(bars,(FundingEvent(60,.001,100,ts_ms=60000),
                  FundingEvent(60,.001,100,ts_ms=60001)))


def test_replay_without_events_not_claiming_completeness():
    bars=[c(0),c(60),c(120)]
    r=replay_futures(bars,bars,NeverEntry(),FundingTape((),0,180,'synthetic'),
                   (MarginTier(0,1000000,.005,0,20),))
    assert 'FUNDING_TAPE_COMPLETENESS_NOT_AUTOMATICALLY_PROVEN' in r['limitations']
    assert r['funding_events_count']==0


def test_event_exact_ms_invariant():
    with pytest.raises(ValueError,match='invalid funding event'):
        FundingEvent(60,.001,100,ts_ms=61000)
