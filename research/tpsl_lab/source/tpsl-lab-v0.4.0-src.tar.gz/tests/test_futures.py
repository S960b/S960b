import json
import math
from pathlib import Path
import pytest

from tpsl_lab.futures import (
    FundingEvent, FundingTape, MarginTier, FuturesSettings, replay_futures)
from tpsl_lab.futures_io import read_binance_funding, read_tiers
from tpsl_lab.model import Candle, Costs
from tpsl_lab.strategies import NeverEntry


class Once:
    def __init__(self, direction=1):
        self.count=0
        self.direction=direction
    def on_close(self, bar):
        self.count+=1
        return self.direction if self.count == 1 else 0


def b(t, o, h=None, l=None, c=None):
    return Candle(t, o, h if h is not None else o,
                  l if l is not None else o, c if c is not None else o)


def setup(exec_bars, mark_bars=None, events=(), settings=None, fee=0.0,
          slip=0.0, direction=1, tiers=None):
    mark_bars = mark_bars if mark_bars is not None else exec_bars
    s = settings or FuturesSettings(position_notional=100., leverage=2.,
                                   tp_pct=.02, sl_pct=.01, liquidation_fee_reserve_rate=0.)
    tape = FundingTape(tuple(events), exec_bars[0].ts,
                       exec_bars[-1].ts + s.bar_seconds, 'synthetic fixtures')
    ts = tiers or (MarginTier(0, 1000000, .005, 0, 20),)
    return replay_futures(exec_bars, mark_bars, Once(direction), tape,
                          ts, s, Costs(fee, slip))


def test_no_trades_no_events():
    bs=[b(0,100),b(60,100)]
    r=replay_futures(bs,bs,NeverEntry(), FundingTape((),0,120,'test'),
                     (MarginTier(0,1000,.005,0,20),))
    assert r['closed_equity']==1000 and not r['trades']


def test_next_open_no_future_leak():
    bs=[b(0,100),b(60,100,102,98,100),b(120,101,103,100,102)]
    r=setup(bs)
    assert r['events'][0]['kind']=='entry' and r['events'][0]['ts']==60
    assert r['trades'][0]['reason']=='stop'


def test_long_funding_pays_at_exact_event():
    bs=[b(0,100),b(60,100),b(120,100),b(180,102,102,102,102)]
    e=FundingEvent(120,.001,100)
    r=setup(bs, events=(e,))
    assert r['funding_cashflow']==pytest.approx(-.1)
    assert r['closed_equity']==pytest.approx(1001.9)
    assert [x['kind'] for x in r['events']]==['entry','funding','exit']
    assert r['trades'][0]['net_pnl']==pytest.approx(1.9)


def test_short_positive_funding_receives():
    bs=[b(0,100),b(60,100),b(120,100),b(180,98)]
    r=setup(bs, events=(FundingEvent(120,.001,100),), direction=-1)
    assert r['funding_cashflow']==pytest.approx(.1)
    assert r['closed_equity']==pytest.approx(1002.1)


def test_funding_no_position_not_charged():
    bs=[b(0,100),b(60,100),b(120,100)]
    r=replay_futures(bs,bs,NeverEntry(), FundingTape((FundingEvent(60,.001,100),),0,180,'test'),
                     (MarginTier(0,1000,.005,0,20),))
    assert r['funding_cashflow']==0


def test_entry_at_same_boundary_conservatively_pays():
    bs=[b(0,100),b(60,100),b(120,100)]
    r=setup(bs,events=(FundingEvent(60,.001,100),))
    assert r['funding_cashflow']==pytest.approx(-.1)
    assert r['events'][1]['kind']=='funding_entry_boundary_CONSERVATIVE'


def test_entry_at_same_boundary_cannot_claim_credit():
    bs=[b(0,100),b(60,100),b(120,100)]
    r=setup(bs,events=(FundingEvent(60,-.001,100),))
    assert r['funding_cashflow']==0


def test_open_gap_exit_does_not_claim_uncertain_funding_credit():
    bs=[b(0,100),b(60,100),b(120,98)]
    r=setup(bs,events=(FundingEvent(120,-.001,100),))
    assert r['funding_cashflow']==0
    assert r['events'][1]['boundary_credit_suppressed'] is True


def test_both_target_and_stop_stop_first():
    r=setup([b(0,100),b(60,100,103,98,100)])
    assert r['trades'][0]['reason']=='stop'
    assert r['trades'][0]['ambiguous'] is True


def test_liquidation_proxy_on_mark_only_wipes_margin():
    bs=[b(0,100),b(60,100),b(120,100)]
    mk=[b(0,100),b(60,100),b(120,100,100,49,100)]
    r=setup(bs,mk)
    assert r['liquidations_proxy']==1
    assert r['closed_equity']==pytest.approx(950)
    assert r['trades'][0]['exit_price'] is None
    assert r['trades'][0]['net_pnl'] is None


def test_liquidation_priority_when_both_possible():
    bs=[b(0,100),b(60,100),b(120,100,103,98,100)]
    mk=[b(0,100),b(60,100),b(120,100,100,48,100)]
    r=setup(bs,mk)
    assert r['ambiguous_liquidations']==1
    assert r['trades'][0]['reason']=='liquidation_PROXY'


def test_gap_stop_exit_worse_price():
    bs=[b(0,100),b(60,100),b(120,90)]
    mk=[b(0,100),b(60,100),b(120,90)]
    r=setup(bs,mk)
    assert r['trades'][0]['reason']=='stop_gap'
    assert r['closed_equity']==pytest.approx(990)


def test_fee_both_sides_and_adverse_slippage():
    bs=[b(0,100),b(60,100,100,100,100),b(120,103)]
    r=setup(bs,fee=.001,slip=.001)
    t=r['trades'][0]
    assert t['entry_price']==pytest.approx(100.1)
    assert t['exit_price']==pytest.approx(100.1*1.02*(1-.001))
    assert r['total_fees']>0.19


def test_leverage_max_tier_rejects():
    bs=[b(0,100),b(60,100)]
    s=FuturesSettings(leverage=10)
    r=setup(bs,settings=s,tiers=(MarginTier(0,1e9,.01,0,5),))
    assert r['events'][0]['kind']=='rejected_entry'


def test_margin_insufficient_rejects():
    bs=[b(0,100),b(60,100)]
    s=FuturesSettings(starting_equity=10,position_notional=100,leverage=2)
    r=setup(bs,settings=s)
    assert r['events'][0]['kind']=='rejected_entry'


def test_misaligned_mark_fails_closed():
    with pytest.raises(ValueError,match='misaligned'):
        setup([b(0,100),b(60,100)],[b(0,100),b(61,100)])


def test_missing_mark_fails_closed():
    with pytest.raises(ValueError,match='aligned'):
        setup([b(0,100),b(60,100)],[b(0,100)])


def test_funding_coverage_fails_closed():
    bs=[b(0,100),b(60,100)]
    with pytest.raises(ValueError,match='coverage'):
        replay_futures(bs,bs,Once(),FundingTape((),0,60,'test'),
                       (MarginTier(0,1000,.005,0,20),))


def test_intrabar_funding_fails_closed():
    bs=[b(0,100),b(60,100)]
    with pytest.raises(ValueError,match='intrabar funding'):
        setup(bs,events=(FundingEvent(61,.001,100),))


def test_duplicate_funding_rejected():
    with pytest.raises(ValueError,match='strictly sorted'):
        FundingTape((FundingEvent(60,.1,100),FundingEvent(60,.2,100)),0,120,'test')


def test_missing_margin_tier_fails_closed():
    with pytest.raises(ValueError,match='no maintenance tier'):
        setup([b(0,100),b(60,100)],tiers=(MarginTier(0,10,.01,0,2),))


def test_tier_continuity_fails_closed():
    with pytest.raises(ValueError,match='missing or overlapping'):
        setup([b(0,100),b(60,100)],tiers=(MarginTier(0,50,.01,0,10),MarginTier(60,200,.02,0,5)))


def test_read_funding_json(tmp_path):
    p=tmp_path/'funding.json'
    p.write_text(json.dumps([{'fundingTime':120000,'fundingRate':'0.0001','markPrice':'100.00'}]))
    got=read_binance_funding(p,0,180)
    assert got.events[0]==FundingEvent(120,.0001,100,ts_ms=120000)


def test_read_tiers_reject_implicit(tmp_path):
    p=tmp_path/'tiers.json'
    p.write_text(json.dumps({'tiers':[{'floor':0}]}))
    with pytest.raises(ValueError,match='mode=scenario'):
        read_tiers(p)


def test_replay_deterministic_and_non_mutating():
    bs=[b(0,100),b(60,100,102,98,100)]
    a=setup(bs)
    c=setup(bs)
    assert a==c
    assert a['events'][0]['seq']==1
    assert a['schema']=='tpsl-lab/v0.3'
