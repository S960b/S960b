"""Exactly defined, no-lookahead signals for offline parity with Freqtrade.

These functions never execute orders. Stream logic sees a completed Candle only.
The DataFrame implementation is independent and optional (requires pandas).
"""
from __future__ import annotations
from collections import deque
from math import isfinite
from typing import Iterable
from .model import Candle
from .strategies import EmaTrend, NeverEntry, RandomEntry


class DonchianBreakout:
    """Close breaks prior N completed candle highs/lows (exclude current bar)."""
    def __init__(self, lookback: int = 20):
        if type(lookback) is not int or lookback < 2:
            raise ValueError('lookback must be integer >=2')
        self.lookback = lookback
        self.highs: deque[float] = deque(maxlen=lookback)
        self.lows: deque[float] = deque(maxlen=lookback)

    def on_close(self, candle: Candle) -> int:
        signal = 0
        if len(self.highs) == self.lookback and candle.volume > 0:
            high_before = max(self.highs)
            low_before = min(self.lows)
            if candle.close > high_before:
                signal = 1
            elif candle.close < low_before:
                signal = -1
        self.highs.append(candle.high)
        self.lows.append(candle.low)
        return signal


def strategy_factory(kind: str, *, fast: int = 50, slow: int = 200,
                     lookback: int = 20, seed: int = 7, probability: float = 0.02):
    if kind == 'never':
        return NeverEntry()
    if kind == 'random':
        return RandomEntry(seed, probability)
    if kind == 'ema':
        return EmaTrend(fast, slow)
    if kind == 'donchian':
        return DonchianBreakout(lookback)
    raise ValueError('unknown research strategy')


def stream_signals(bars: Iterable[Candle], kind: str, **kwargs) -> list[int]:
    s = strategy_factory(kind, **kwargs)
    result = []
    for bar in bars:
        direction = s.on_close(bar)
        if type(direction) is not int or direction not in (-1, 0, 1):
            raise ValueError('invalid streaming signal')
        result.append(direction)
    return result


def dataframe_signals(frame, kind: str, *, fast: int = 50,
                      slow: int = 200, lookback: int = 20):
    """Return vector of {-1, 0, +1} signals for a pandas-like DataFrame.

    Used by optional Freqtrade strategy, not by execution model. Inputs MUST
    contain complete OHLCV candles, oldest first. All operations are causal.
    """
    import pandas as pd  # optional outside core venv
    import numpy as np
    if not isinstance(frame, pd.DataFrame):
        raise TypeError('expected pandas.DataFrame')
    if not {'open','high','low','close','volume'}.issubset(frame.columns):
        raise ValueError('missing OHLCV columns')
    if kind == 'ema':
        if not (type(fast) is int and type(slow) is int and 1 <= fast < slow):
            raise ValueError('require 1 <= fast < slow')
        close = frame['close']
        a = close.ewm(span=fast, adjust=False).mean()
        b = close.ewm(span=slow, adjust=False).mean()
        ready = np.arange(len(frame)) + 1 >= slow
        longs = ready & (close > a) & (a > b)
        shorts = ready & (close < a) & (a < b)
    elif kind == 'donchian':
        if type(lookback) is not int or lookback < 2:
            raise ValueError('lookback must be integer >=2')
        hi = frame['high'].shift(1).rolling(lookback, min_periods=lookback).max()
        lo = frame['low'].shift(1).rolling(lookback, min_periods=lookback).min()
        longs = (frame['close'] > hi) & (frame['volume'] > 0)
        shorts = (frame['close'] < lo) & (frame['volume'] > 0)
    elif kind == 'never':
        return [0] * len(frame)
    else:
        raise ValueError('dataframe supports only ema/donchian/never')
    if (longs & shorts).any():
        raise ValueError('conflicting simultaneous entry signals')
    return np.select([longs.to_numpy(), shorts.to_numpy()], [1, -1], default=0).astype(int).tolist()
